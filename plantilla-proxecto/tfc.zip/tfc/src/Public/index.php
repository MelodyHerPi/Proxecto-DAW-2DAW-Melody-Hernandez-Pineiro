<?php
/**
 * Archivo enrutador y acceso principal del programa
 */

define('ROOT_PATH', dirname(__DIR__)); // apunta a src/

// Cargar configuración de la base de datos
require_once ROOT_PATH . '/config/database.php';

/**
 * Autoload de clases
 */
spl_autoload_register(function ($class) {
    // Reemplaza '\' por '/' y añade extensión
    $ruta = ROOT_PATH . '/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($ruta)) {
        require_once $ruta;
    } else {
        error_log("No se encuentra la clase: $ruta");
    }
});

/**
 * Obtener controller y acción desde la URL
 */
$controllerParam = $_REQUEST['controller'] ?? 'Error';
$action = $_REQUEST['action'] ?? 'pageNotFound';

// Sanitizar nombre del controlador (evitar duplicar 'Controller')
$controllerParam = preg_replace('/Controller$/i', '', $controllerParam);
$controllerName  = ucfirst($controllerParam) . 'Controller';

$controllerNamespace = "App\\Controller\\$controllerName";
$errorControllerClass = "App\\Controller\\ErrorController";

try {
    if (!class_exists($controllerNamespace)) {
        throw new Exception("Controlador no existe: $controllerNamespace");
    }

    $controller = new $controllerNamespace();

    if (!method_exists($controller, $action)) {
        throw new Exception("Acción no existe: $action");
    }
    $controller->$action();

} catch (\Throwable $t) {
    try {
        if ($controllerParam !== 'Error' && class_exists($errorControllerClass)) {
            $errorController = new $errorControllerClass();
            // TODO PageNotFound
            if (method_exists($errorController, 'pageNotFound')) {
                $errorController->pageNotFound();
            } else {
                echo "Error crítico: método pageNotFound no existe.";
            }
        } else {
            echo "Error crítico del sistema: " . $e->getMessage();
        }
    } catch (\Throwable $t) {
        // TODO
        echo "Error crítico irrecuperable.";
    }
}