<?php

namespace App\Controller;

use App\Core\Request;
use App\Core\Response;
use App\Model\UsuarioModel;

class UsuarioController
{
    // TODO : register, login/logout
    private UsuarioModel $model;

    public function __construct()
    {
        $this->model = new UsuarioModel();
    }

    
    // LISTAR USUARIOS
    
    public function index()
    {
        $request = new Request();
        $filtro = $request->query();

        $usuarios = $this->model->listarUsuarios($filtro);

        Response::json($usuarios, 200);
    }

    
    // VER USUARIO
    
    public function show(int $id)
    {
        $usuario = $this->model->obtenerUsuarioPorId($id);

        if (!$usuario) {
            Response::notFound();
            return;
        }

        Response::json($usuario, 200);
    }

    
    // TIPOS USUARIO
    
    public function tipos()
    {
        $tipos = $this->model->listarTiposUsuarios();
        Response::json($tipos, 200);
    }

    public function tipo(int $id)
    {
        $tipo = $this->model->obtenerTipoUsuarioPorId($id);

        if (!$tipo) {
            Response::notFound();
            return;
        }

        Response::json($tipo, 200);
    }

    
    // ESTADOS USUARIO
    
    public function estados()
    {
        $estados = $this->model->listarEstadosUsuarios();
        Response::json($estados, 200);
    }

    public function estado(int $id)
    {
        $estado = $this->model->obtenerEstadoUsuarioPorId($id);

        if (!$estado) {
            Response::notFound();
            return;
        }

        Response::json($estado, 200);
    }
}