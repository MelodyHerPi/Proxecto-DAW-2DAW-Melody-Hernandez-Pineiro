<?php

namespace App\Controller;

use App\Core\Request;
use App\Core\Response;
use App\Model\NotificacionModel;

class NotificacionController
{
    private NotificacionModel $model;

    public function __construct()
    {
        $this->model = new NotificacionModel();
    }

    
    // GET /notificaciones
    
    public function index()
    {
        $request = new Request();
        $filtro = $request->query();

        $notificaciones = $this->model->listarNotificaciones($filtro);

        Response::json($notificaciones, 200);
    }

    
    // GET /notificaciones/{id}
    
    public function show(int $id)
    {
        $notificacion = $this->model->obtenerNotificacionPorId($id);

        if (!$notificacion) {
            Response::notFound();
            return;
        }

        Response::json($notificacion, 200);
    }

    
    // PUT /notificaciones/{id}/leer
    // marcar como leída
    
    public function markAsRead(int $id)
    {
        try {
            $db = conexion();

            $stmt = $db->prepare("
                UPDATE notificaciones
                SET leida = 1
                WHERE id = :id
            ");

            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            $ok = $stmt->execute();

            if (!$ok || $stmt->rowCount() === 0) {
                Response::notFound();
                return;
            }

            Response::json([
                'mensaje' => 'Notificación marcada como leída',
                'id' => $id
            ], 200);

        } catch (\PDOException $e) {
            error_log($e->getMessage());
            Response::json(['error' => 'Error al actualizar notificación'], 500);
        }
    }

    
    // DELETE /notificaciones/{id}
    
    public function destroy(int $id)
    {
        try {
            $db = conexion();

            $stmt = $db->prepare("
                DELETE FROM notificaciones
                WHERE id = :id
            ");

            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            $ok = $stmt->execute();

            if (!$ok || $stmt->rowCount() === 0) {
                Response::notFound();
                return;
            }

            Response::json([
                'mensaje' => 'Notificación eliminada',
                'id' => $id
            ], 200);

        } catch (\PDOException $e) {
            error_log($e->getMessage());
            Response::json(['error' => 'Error al eliminar notificación'], 500);
        }
    }
}