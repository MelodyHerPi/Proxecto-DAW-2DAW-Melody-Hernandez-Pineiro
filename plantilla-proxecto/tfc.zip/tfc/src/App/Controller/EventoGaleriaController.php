<?php

namespace App\Controller;

use App\Core\Request;
use App\Core\Response;
use App\Model\EventoModel;

class EventoGaleriaController
{
    private EventoModel $model;

    public function __construct()
    {
        $this->model = new EventoModel();
    }

    
    // GET /eventos/{id_evento}/galeria
    
    public function index(int $id_evento)
    {
        $imagenes = $this->model->listarGaleriaEvento($id_evento);

        Response::json($imagenes, 200);
    }

    
    // POST /eventos/{id_evento}/galeria
    // body: { url }
    
    public function store(int $id_evento)
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['url'])) {
            Response::json(['error' => 'Falta URL de la imagen'], 400);
            return;
        }

        $id = $this->model->agregarImagenEvento($id_evento, $data['url']);

        if (!$id) {
            Response::json(['error' => 'Error al añadir imagen'], 500);
            return;
        }

        Response::json([
            'mensaje' => 'Imagen añadida correctamente',
            'id' => $id,
            'id_evento' => $id_evento,
            'url' => $data['url']
        ], 201);
    }

    
    // DELETE /galeria/{id}
    
    public function destroy(int $id)
    {
        $ok = $this->model->eliminarImagenEvento($id);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json([
            'mensaje' => 'Imagen eliminada correctamente',
            'id' => $id
        ], 200);
    }
}