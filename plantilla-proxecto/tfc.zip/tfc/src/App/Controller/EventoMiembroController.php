<?php

namespace App\Controller;

use App\Core\Request;
use App\Core\Response;
use App\Model\EventoModel;

class EventoMiembroController
{
    private EventoModel $model;

    public function __construct()
    {
        $this->model = new EventoModel();
    }

    
    // GET /eventos/{id_evento}/miembros
    
    public function index(int $id_evento)
    {
        $miembros = $this->model->listarMiembrosPorEvento($id_evento);

        Response::json($miembros, 200);
    }

    
    // POST /eventos/{id_evento}/unirse
    // body: { id_usuario }
    
    public function store(int $id_evento)
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['id_usuario'])) {
            Response::json(['error' => 'Falta id_usuario'], 400);
            return;
        }

        $id_usuario = (int)$data['id_usuario'];

        // comprobar si ya es miembro
        if ($this->model->esMiembroEvento($id_usuario, $id_evento)) {
            Response::json(['error' => 'El usuario ya está en el evento'], 409);
            return;
        }

        $ok = $this->model->agregarMiembroEvento($id_usuario, $id_evento);

        if (!$ok) {
            Response::json(['error' => 'Error al unirse al evento'], 500);
            return;
        }

        Response::json([
            'mensaje' => 'Usuario añadido al evento',
            'id_usuario' => $id_usuario,
            'id_evento' => $id_evento
        ], 201);
    }

    
    // DELETE /eventos/{id_evento}/salir/{id_usuario}
    
    public function destroy(int $id_evento, int $id_usuario)
    {
        $ok = $this->model->eliminarMiembroEvento($id_usuario, $id_evento);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json([
            'mensaje' => 'Usuario eliminado del evento',
            'id_usuario' => $id_usuario,
            'id_evento' => $id_evento
        ], 200);
    }
}