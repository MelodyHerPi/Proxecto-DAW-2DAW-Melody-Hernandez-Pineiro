<?php

namespace App\Controller;

use App\Core\Request;
use App\Core\Response;
use App\Model\ForoModel;

class ForoController
{
    private ForoModel $model;

    public function __construct()
    {
        $this->model = new ForoModel();
    }

    
    // HILOS
    

    // GET /foro/hilos
    public function index()
    {
        // TODO
    }

    // GET /foro/hilos/{id}
    public function show(int $id)
    {
        $hilo = $this->model->obtenerHiloPorId($id);

        if (!$hilo) {
            Response::notFound();
            return;
        }

        Response::json($hilo, 200);
    }

    // POST /foro/hilos
    public function store()
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['titulo']) || empty($data['contenido'])) {
            Response::json(['error' => 'Datos incompletos'], 400);
            return;
        }

        $id = $this->model->crearHilo(
            $data['titulo'],
            $data['contenido'],
            $data['categoria'] ?? null
        );

        if (!$id) {
            Response::json(['error' => 'Error al crear hilo'], 500);
            return;
        }

        Response::json([
            'mensaje' => 'Hilo creado correctamente',
            'id' => $id
        ], 201);
    }

    // PUT /foro/hilos/{id}
    public function update(int $id)
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['estado'])) {
            Response::json(['error' => 'Falta estado'], 400);
            return;
        }

        $ok = $this->model->actualizarEstadoHilo($id, $data['estado']);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json([
            'mensaje' => 'Estado del hilo actualizado',
            'id' => $id,
            'estado' => $data['estado']
        ], 200);
    }

    // DELETE /foro/hilos/{id}
    public function destroy(int $id)
    {
        $ok = $this->model->eliminarHilo($id);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json([
            'mensaje' => 'Hilo eliminado',
            'id' => $id
        ], 200);
    }

    
    // MENSAJES
    

    // GET /foro/hilos/{id_hilo}/mensajes
    public function mensajes(int $id_hilo)
    {
        $mensajes = $this->model->listarMensajesPorHilo($id_hilo);

        Response::json($mensajes, 200);
    }

    // POST /foro/hilos/{id_hilo}/mensajes
    public function storeMensaje(int $id_hilo)
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['id_usuario']) || empty($data['contenido'])) {
            Response::json(['error' => 'Datos incompletos'], 400);
            return;
        }

        $id = $this->model->crearMensaje(
            $id_hilo,
            (int)$data['id_usuario'],
            $data['contenido']
        );

        if (!$id) {
            Response::json(['error' => 'Error al crear mensaje'], 500);
            return;
        }

        Response::json([
            'mensaje' => 'Mensaje creado',
            'id' => $id
        ], 201);
    }

    // DELETE /foro/mensajes/{id}
    public function deleteMensaje(int $id)
    {
        $ok = $this->model->eliminarMensaje($id);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json([
            'mensaje' => 'Mensaje eliminado',
            'id' => $id
        ], 200);
    }
}