<?php

namespace App\Controller;

use App\Core\Request;
use App\Core\Response;
use App\Model\EventoModel;

class EventoController
{
    private EventoModel $model;

    public function __construct()
    {
        $this->model = new EventoModel();
    }

    
    // EVENTOS
    

    // GET /eventos
    public function index()
    {
        $request = new Request();
        $filtro = $request->query();

        $eventos = $this->model->listarEventos($filtro);

        Response::json($eventos, 200);
    }

    // GET /eventos/{id}
    public function show(int $id)
    {
        $evento = $this->model->obtenerEventoPorId($id);

        if (!$evento) {
            Response::notFound();
            return;
        }

        Response::json($evento, 200);
    }

    // POST /eventos
    public function store()
    {
        $request = new Request();
        $data = $request->body();

        if (
            empty($data['nombre']) ||
            empty($data['id_tipo']) ||
            empty($data['fecha_hora'])
        ) {
            Response::json(['error' => 'Datos incompletos'], 400);
            return;
        }

        $id = $this->model->crearEvento(
            $data['nombre'],
            (int)$data['id_tipo'],
            $data['fecha_hora'],
            $data['ciudad'] ?? null,
            $data['capacidad'] ?? null,
            $data['descripcion'] ?? null,
            $data['estado'] ?? 1
        );

        if (!$id) {
            Response::json(['error' => 'Error al crear evento'], 500);
            return;
        }

        Response::json([
            'mensaje' => 'Evento creado correctamente',
            'id' => $id
        ], 201);
    }

    // PUT /eventos/{id}
    public function update(int $id)
    {
        // TU MODEL NO TIENE UPDATE EVENTO
        Response::json(['error' => 'No implementado en el modelo'], 501);
    }

    // DELETE /eventos/{id}
    public function destroy(int $id)
    {
        // TU MODEL NO TIENE DELETE EVENTO
        Response::json(['error' => 'No implementado en el modelo'], 501);
    }


    
    // TIPOS EVENTO
    

    // GET /eventos/tipos
    public function tipos()
    {
        $tipos = $this->model->listarEventosTipos();
        Response::json($tipos, 200);
    }

    // GET /eventos/tipos/{id}
    public function tipo(int $id)
    {
        $tipo = $this->model->obtenerEventoTipoPorId($id);

        if (!$tipo) {
            Response::notFound();
            return;
        }

        Response::json($tipo, 200);
    }


    
    // ESTADOS EVENTO
    

    // GET /eventos/estados
    public function estados()
    {
        $estados = $this->model->listarEventosEstados();
        Response::json($estados, 200);
    }

    // GET /eventos/estados/{id}
    public function estado(int $id)
    {
        $estado = $this->model->obtenerEventoEstadoPorId($id);

        if (!$estado) {
            Response::notFound();
            return;
        }

        Response::json($estado, 200);
    }


    
    // MIEMBROS EVENTO
    

    // GET /eventos/{id}/miembros
    public function miembros(int $id_evento)
    {
        $miembros = $this->model->listarMiembrosPorEvento($id_evento);

        Response::json($miembros, 200);
    }

    // POST /eventos/{id}/unirse
    public function unirse(int $id_evento)
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['id_usuario'])) {
            Response::json(['error' => 'Falta id_usuario'], 400);
            return;
        }

        if ($this->model->esMiembroEvento($data['id_usuario'], $id_evento)) {
            Response::json(['error' => 'Ya es miembro del evento'], 409);
            return;
        }

        $ok = $this->model->agregarMiembroEvento($data['id_usuario'], $id_evento);

        if (!$ok) {
            Response::json(['error' => 'Error al unirse al evento'], 500);
            return;
        }

        Response::json(['mensaje' => 'Te has unido al evento'], 201);
    }

    // DELETE /eventos/{id}/salir/{id_usuario}
    public function salir(int $id_evento, int $id_usuario)
    {
        $ok = $this->model->eliminarMiembroEvento($id_usuario, $id_evento);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json(['mensaje' => 'Has salido del evento'], 200);
    }


    
    // GALERÍA EVENTO
    

    // GET /eventos/{id}/galeria
    public function galeria(int $id_evento)
    {
        $imagenes = $this->model->listarGaleriaEvento($id_evento);

        Response::json($imagenes, 200);
    }

    // POST /eventos/{id}/galeria
    public function addImagen(int $id_evento)
    {
        $request = new Request();
        $data = $request->body();

        if (empty($data['url'])) {
            Response::json(['error' => 'Falta URL'], 400);
            return;
        }

        $id = $this->model->agregarImagenEvento($id_evento, $data['url']);

        Response::json([
            'mensaje' => 'Imagen añadida',
            'id' => $id
        ], 201);
    }

    // DELETE /galeria/{id}
    public function deleteImagen(int $id)
    {
        $ok = $this->model->eliminarImagenEvento($id);

        if (!$ok) {
            Response::notFound();
            return;
        }

        Response::json(['mensaje' => 'Imagen eliminada'], 200);
    }
}