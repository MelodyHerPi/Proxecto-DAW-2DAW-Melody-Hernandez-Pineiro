CREATE DATABASE IF NOT EXISTS AllDanceTogether;

USE AllDanceTogether;

-- s base 

CREATE TABLE usuarios_tipos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT
);

CREATE TABLE usuarios_estados (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT
);

CREATE TABLE eventos_tipos(
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE, 
    descripcion TEXT
);

CREATE TABLE eventos_estados (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE, 
    descripcion TEXT
);

CREATE TABLE notificaciones_tipos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT
);

--  usuarios

CREATE TABLE usuarios (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    id_rol INT UNSIGNED NOT NULL DEFAULT 1,
    provincia VARCHAR(100),
    ciudad VARCHAR(100),
    telefono VARCHAR(20),
    bio TEXT,
    foto_perfil VARCHAR(255),
    id_estado INT UNSIGNED NOT NULL DEFAULT 1,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    redes_sociales JSON,
    CHECK (email REGEXP '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'),
    FOREIGN KEY (id_estado) REFERENCES estados_usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (id_rol) REFERENCES usuarios_tipos(id) ON DELETE SET NULL
);

--  eventos

CREATE TABLE eventos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    id_tipo INT UNSIGNED NOT NULL DEFAULT 1,
    fecha_hora DATETIME NOT NULL,
    ciudad VARCHAR(100),
    capacidad INT UNSIGNED,
    descripcion TEXT,
    id_estado INT UNSIGNED NOT NULL DEFAULT 1,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_tipo) REFERENCES eventos_tipos(id)
        ON DELETE CASCADE,
    FOREIGN KEY (id_estado) REFERENCES eventos_estados(id)
        ON DELETE CASCADE
);

--  notificaciones

CREATE TABLE notificaciones (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_tipo INT UNSIGNED NOT NULL,
    contenido TEXT NOT NULL,
    leida BOOLEAN DEFAULT FALSE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    id_usuario INT UNSIGNED NOT NULL,
    id_evento INT UNSIGNED NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
        ON DELETE CASCADE,
    FOREIGN KEY (id_evento) REFERENCES eventos(id)
        ON DELETE SET NULL,
    FOREIGN KEY (id_tipo) REFERENCES notificaciones_tipos(id)
        ON DELETE CASCADE
);

-- Relación evento-usuario

CREATE TABLE evento_miembros (
    id_usuario INT UNSIGNED,
    id_evento INT UNSIGNED,
    PRIMARY KEY (id_usuario, id_evento),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
        ON DELETE CASCADE,
    FOREIGN KEY (id_evento) REFERENCES eventos(id)
        ON DELETE CASCADE
);

-- Galería

CREATE TABLE evento_galeria (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_evento INT UNSIGNED NOT NULL,
    url VARCHAR(255) NOT NULL,
    FOREIGN KEY (id_evento) REFERENCES eventos(id)
        ON DELETE CASCADE
);

-- Foro

CREATE TABLE foro_hilos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    contenido TEXT NOT NULL,
    categoria VARCHAR(100),
    estado ENUM('abierto', 'cerrado') DEFAULT 'abierto',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE foro_mensajes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_hilo INT UNSIGNED NOT NULL,
    id_usuario INT UNSIGNED NOT NULL,
    contenido TEXT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reportes INT UNSIGNED DEFAULT 0,
    FOREIGN KEY (id_hilo) REFERENCES foro_hilos(id)
        ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
        ON DELETE CASCADE
);