<?php
/* Página del tablón de anuncios, será similar a la de Descubre pero con funcionalidades, botones
y cajas de búsqueda distintas. Las cards se renderizarán en js */
?>