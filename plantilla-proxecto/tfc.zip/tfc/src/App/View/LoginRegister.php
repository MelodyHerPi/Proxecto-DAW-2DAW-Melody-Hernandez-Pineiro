<?php

/* Vista de login con formulario dinámico en js (si le dan a un botón de registro se muestra ese formulario, sino
de forma predeterminada se mostrará el de login)
*/
?>