<?php
/* Página del chat del foro, en un inicio va a ser una única conversación (es decir, no serán
varios chats independientes sino un único chat) */
?>