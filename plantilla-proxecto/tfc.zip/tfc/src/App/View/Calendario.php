<?php
/*
Página de Calendario, se renderizará un calendario donde añadir asuntos. Además contará con una lista
de recordatorios recientes. 
*/
?>