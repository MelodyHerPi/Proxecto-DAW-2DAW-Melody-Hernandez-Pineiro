<?php
/* Página del apartado de descubrir con diversas cards generadas en js */

?>