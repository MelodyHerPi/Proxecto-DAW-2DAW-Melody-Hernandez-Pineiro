<?php

namespace App\Core;

class View
{
    public function render(string $viewName, array $data = []): void
    {
        $viewFile = ROOT_PATH . '/app/views/' . $viewName . '.php';

        if (!empty($data)) {
            extract($data);
        }

        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            http_response_code(404);
            echo "<h1>Vista no encontrada</h1>";
            echo "<p>No existe la vista: <strong>$viewName</strong></p>";
        }
    }
}