<?php
/* Página de inicio con el carrusel a la izquierda y las 4 opciones de pantallas de la web */
?>