<?php
/* Página que se usará para enseñar el detalle de tanto apartados concretos de Descubre.php como de
TabloAnuncios.php, se usará conjuntamente js*/

?>