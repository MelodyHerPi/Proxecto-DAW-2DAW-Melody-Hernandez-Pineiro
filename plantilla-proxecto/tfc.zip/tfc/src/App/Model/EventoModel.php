<?php
/**
 * Archivo con las acciones sobre las tablas eventos, tipos de eventos y estados de eventos
 */
namespace App\Model;
use App\Core\Model;

class EventoModel {
/**
 * Listar todos los eventos, con opción de filtro por tipo o ciudad
 *
 * @param array|null $filtro ['tipo' => int, 'ciudad' => string]
 * @return array Listado de eventos
 */
function listarEventos(?array $filtro = null): array
{
    $eventos = [];
    $sql = "SELECT * FROM eventos WHERE 1=1";

    try {
        $db = conexion();

        if (isset($filtro['tipo'])) {
            $sql .= " AND id_tipo = :tipo";
        }
        if (isset($filtro['ciudad'])) {
            $sql .= " AND ciudad LIKE :ciudad";
        }

        $stmt = $db->prepare($sql);

        if (isset($filtro['tipo'])) {
            $stmt->bindValue(':tipo', $filtro['tipo'], PDO::PARAM_INT);
        }
        if (isset($filtro['ciudad'])) {
            $stmt->bindValue(':ciudad', '%' . $filtro['ciudad'] . '%', PDO::PARAM_STR);
        }

        $stmt->execute();

        $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarEventos: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $eventos;
}

/**
 * Obtener un evento por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerEventoPorId(int $id): ?array
{
    $evento = null;
    try {
        $db = conexion();

        $stmt = $db->prepare("SELECT * FROM eventos WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerEventoPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $evento;
}

/**
 * Crear un nuevo evento
 *
 * @param string $nombre
 * @param int $id_tipo
 * @param string $fecha_hora
 * @param string|null $ciudad
 * @param int|null $capacidad
 * @param string|null $descripcion
 * @param int $estado
 * @return int|null ID del evento creado
 */
function crearEvento(
    string $nombre,
    int $id_tipo,
    string $fecha_hora,
    ?string $ciudad = null,
    ?int $capacidad = null,
    ?string $descripcion = null,
    int $estado = 1
): ?int {
    $nuevoId = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            INSERT INTO eventos (nombre, id_tipo, fecha_hora, ciudad, capacidad, descripcion, estado)
            VALUES (:nombre, :id_tipo, :fecha_hora, :ciudad, :capacidad, :descripcion, :estado)
        ");

        $stmt->bindValue(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindValue(':id_tipo', $id_tipo, PDO::PARAM_INT);
        $stmt->bindValue(':fecha_hora', $fecha_hora, PDO::PARAM_STR);
        $stmt->bindValue(':ciudad', $ciudad, PDO::PARAM_STR);
        $stmt->bindValue(':capacidad', $capacidad, PDO::PARAM_INT);
        $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->bindValue(':estado', $estado, PDO::PARAM_INT);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en crearEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}

// TIPOS DE EVENTOS

/**
 * Listar todos los tipos de eventos
 *
 * @return array
 */
function listarEventosTipos(): array
{
    $tipos = [];
    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM eventos_tipos ORDER BY nombre ASC");
        $stmt->execute();
        $tipos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en listarEventosTipos: " . $e->getMessage());
    } finally {
        $db = null;
    }
    return $tipos;
}

/**
 * Obtener un tipo de evento por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerEventoTipoPorId(int $id): ?array
{
    $tipo = null;
    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM eventos_tipos WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $tipo = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en obtenerEventoTipoPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }
    return $tipo;
}

// TODO : en principio no se van a poder crear diferentes tipos de eventos (?)

// ESTADOS EVENTOS 

/**
 * Listar todos los estados de eventos
 *
 * @return array
 */
function listarEventosEstados(): array
{
    $estados = [];
    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM eventos_estados ORDER BY nombre ASC");
        $stmt->execute();
        $estados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en listarEventosEstados: " . $e->getMessage());
    } finally {
        $db = null;
    }
    return $estados;
}

/**
 * Obtener un estado de evento por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerEventoEstadoPorId(int $id): ?array
{
    $estado = null;
    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM eventos_estados WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $estado = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en obtenerEventoEstadoPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }
    return $estado;
}

// EVENTOS MIEMBROS

/**
 * Añadir un usuario a un evento
 */
function agregarMiembroEvento(int $id_usuario, int $id_evento): bool
{
    $agregado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            INSERT INTO evento_miembros (id_usuario, id_evento)
            VALUES (:id_usuario, :id_evento)
        ");

        $stmt->bindValue(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);

        $agregado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en agregarMiembroEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $agregado;
}

/**
 * Eliminar un usuario de un evento
 */
function eliminarMiembroEvento(int $id_usuario, int $id_evento): bool
{
    $eliminado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            DELETE FROM evento_miembros
            WHERE id_usuario = :id_usuario AND id_evento = :id_evento
        ");

        $stmt->bindValue(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);

        $eliminado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en eliminarMiembroEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $eliminado;
}

/**
 * Listar miembros de un evento
 */
function listarMiembrosPorEvento(int $id_evento): array
{
    $miembros = [];

    try {
        $db = conexion();

        $stmt = $db->prepare("
            SELECT * FROM evento_miembros
            WHERE id_evento = :id_evento
        ");

        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);
        $stmt->execute();

        $miembros = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarMiembrosPorEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $miembros;
}

/**
 * Comprobar si un usuario está en un evento
 */
function esMiembroEvento(int $id_usuario, int $id_evento): bool
{
    $existe = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            SELECT COUNT(*) FROM evento_miembros
            WHERE id_usuario = :id_usuario AND id_evento = :id_evento
        ");

        $stmt->bindValue(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);

        $stmt->execute();
        $existe = $stmt->fetchColumn() > 0;

    } catch (PDOException $e) {
        error_log("Error en esMiembroEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $existe;
}


// EVENTO GALERÍA


/**
 * Añadir imagen a la galería de un evento
 */
function agregarImagenEvento(int $id_evento, string $url): ?int
{
    $nuevoId = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            INSERT INTO evento_galeria (id_evento, url)
            VALUES (:id_evento, :url)
        ");

        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);
        $stmt->bindValue(':url', $url, PDO::PARAM_STR);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en agregarImagenEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}

/**
 * Listar imágenes de un evento
 */
function listarGaleriaEvento(int $id_evento): array
{
    $imagenes = [];

    try {
        $db = conexion();

        $stmt = $db->prepare("
            SELECT * FROM evento_galeria
            WHERE id_evento = :id_evento
        ");

        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);
        $stmt->execute();

        $imagenes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarGaleriaEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $imagenes;
}

/**
 * Eliminar imagen de la galería
 */
function eliminarImagenEvento(int $id): bool
{
    $eliminado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            DELETE FROM evento_galeria
            WHERE id = :id
        ");

        $stmt->bindValue(':id', $id, PDO::PARAM_INT);

        $eliminado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en eliminarImagenEvento: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $eliminado;
}
}
