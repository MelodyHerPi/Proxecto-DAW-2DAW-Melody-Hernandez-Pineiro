<?php
/**
 * Archivo con las acciones sobre foro_hilos y foro_mensajes
 */
namespace App\Model;

use App\Core\Model;

// FORO HILOS
class ForoModel{
/**
 * Listar todos los hilos (con opción de filtro por estado o categoría)
 */
// TODO : no sé si se usará 

/**
 * Obtener un hilo por ID
 */
function obtenerHiloPorId(int $id): ?array
{
    $hilo = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("SELECT * FROM foro_hilos WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $hilo = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerHiloPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $hilo;
}

/**
 * Crear un nuevo hilo
 */
function crearHilo(string $titulo, string $contenido, ?string $categoria = null): ?int
{
    $nuevoId = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            INSERT INTO foro_hilos (titulo, contenido, categoria)
            VALUES (:titulo, :contenido, :categoria)
        ");

        $stmt->bindValue(':titulo', $titulo, PDO::PARAM_STR);
        $stmt->bindValue(':contenido', $contenido, PDO::PARAM_STR);
        $stmt->bindValue(':categoria', $categoria, PDO::PARAM_STR);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en crearHilo: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}

/**
 * Cambiar estado de un hilo (abierto/cerrado)
 */
function actualizarEstadoHilo(int $id, string $estado): bool
{
    $actualizado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            UPDATE foro_hilos
            SET estado = :estado
            WHERE id = :id
        ");

        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->bindValue(':estado', $estado, PDO::PARAM_STR);

        $actualizado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en actualizarEstadoHilo: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $actualizado;
}

/**
 * Eliminar un hilo
 */
function eliminarHilo(int $id): bool
{
    $eliminado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("DELETE FROM foro_hilos WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);

        $eliminado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en eliminarHilo: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $eliminado;
}


// FORO MENSAJES

/**
 * Listar mensajes de un hilo
 */
function listarMensajesPorHilo(int $id_hilo): array
{
    $mensajes = [];

    try {
        $db = conexion();

        $stmt = $db->prepare("
            SELECT * FROM foro_mensajes
            WHERE id_hilo = :id_hilo
            ORDER BY fecha_creacion ASC
        ");

        $stmt->bindValue(':id_hilo', $id_hilo, PDO::PARAM_INT);
        $stmt->execute();

        $mensajes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarMensajesPorHilo: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $mensajes;
}

/**
 * Crear un mensaje en un hilo
 */
function crearMensaje(int $id_hilo, int $id_usuario, string $contenido): ?int
{
    $nuevoId = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            INSERT INTO foro_mensajes (id_hilo, id_usuario, contenido)
            VALUES (:id_hilo, :id_usuario, :contenido)
        ");

        $stmt->bindValue(':id_hilo', $id_hilo, PDO::PARAM_INT);
        $stmt->bindValue(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->bindValue(':contenido', $contenido, PDO::PARAM_STR);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en crearMensaje: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}

/**
 * Obtener mensaje por ID
 */
function obtenerMensajePorId(int $id): ?array
{
    $mensaje = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            SELECT * FROM foro_mensajes WHERE id = :id
        ");

        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $mensaje = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerMensajePorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $mensaje;
}

/**
 * Eliminar mensaje
 */
function eliminarMensaje(int $id): bool
{
    $eliminado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("DELETE FROM foro_mensajes WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);

        $eliminado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en eliminarMensaje: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $eliminado;
}

/**
 * Reportar (incrementar contador de reportes)
 */
function reportarMensaje(int $id): bool
{
    $actualizado = false;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            UPDATE foro_mensajes
            SET reportes = reportes + 1
            WHERE id = :id
        ");

        $stmt->bindValue(':id', $id, PDO::PARAM_INT);

        $actualizado = $stmt->execute();

    } catch (PDOException $e) {
        error_log("Error en reportarMensaje: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $actualizado;
}
}