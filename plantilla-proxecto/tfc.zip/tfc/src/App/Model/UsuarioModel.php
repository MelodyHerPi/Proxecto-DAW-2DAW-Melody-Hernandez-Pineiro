<?php
/**
 * Archivo con las acciones sobre las tablas usuarios, usuarios_tipos y usuarios_estados
 */

namespace App\Model;
use App\Core\Model;


class UsuarioModel{
/**
 * Listar usuarios, con opción de filtro por email o nombre TODO
 *
 * @param array|null $filtro ['email' => '...', 'nombre' => '...']
 * @return array Listado de usuarios
 */
function listarUsuarios(?array $filtro = null): array
{
    $usuarios = [];
    $sql = "SELECT * FROM usuarios WHERE 1=1";

    try {
        $db = conexion(); 

        // TODO 
        // Aplicar filtros si los hay
        if (isset($filtro['email'])) {
            $sql .= " AND email LIKE :email";
        }
        if (isset($filtro['nombre'])) {
            $sql .= " AND nombre LIKE :nombre";
        }

        $stmt = $db->prepare($sql);

        if (isset($filtro['email'])) {
            $stmt->bindValue(':email', '%' . $filtro['email'] . '%', PDO::PARAM_STR);
        }
        if (isset($filtro['nombre'])) {
            $stmt->bindValue(':nombre', '%' . $filtro['nombre'] . '%', PDO::PARAM_STR);
        }

        $stmt->execute();

        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarUsuarios: " . $e->getMessage());
    } finally {
        $db = null; // cerrar conexión
    }

    return $usuarios;
}

/**
 * Obtener un usuario por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerUsuarioPorId(int $id): ?array
{
    $usuario = null;
    try {
        $db = conexion(); 

        $stmt = $db->prepare("SELECT * FROM usuarios WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerUsuarioPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $usuario;
}

// TIPOS DE USUARIOS 
function listarTiposUsuarios(): array
{
    $tipos = [];
    $sql = "SELECT * FROM usuarios_tipos ORDER BY nombre ASC";

    try {
        $db = conexion();

        $stmt = $db->prepare($sql);
        $stmt->execute();

        $tipos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarTiposUsuarios: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $tipos;
}

/**
 * Obtener un tipo de usuario por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerTipoUsuarioPorId(int $id): ?array
{
    $tipo = null;
    try {
        $db = conexion();

        $stmt = $db->prepare("SELECT * FROM usuarios_tipos WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $tipo = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerTipoUsuarioPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $tipo;
}

/**
 * Insertar un nuevo tipo de usuario
 *
 * @param string $nombre
 * @param string|null $descripcion
 * @return int|null ID del nuevo tipo insertado
 */
function crearTipoUsuario(string $nombre, ?string $descripcion = null): ?int
{
    $nuevoId = null;
    try {
        $db = conexion();

        $stmt = $db->prepare("INSERT INTO usuarios_tipos (nombre, descripcion) VALUES (:nombre, :descripcion)");
        $stmt->bindValue(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en crearTipoUsuario: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}

// ESTADOS USUARIOS
/**
 * Listar todos los estados de usuario
 *
 * @return array Listado de estados de usuario
 */
function listarEstadosUsuarios(): array
{
    $estados = [];
    $sql = "SELECT * FROM estados_usuarios ORDER BY nombre ASC";

    try {
        $db = conexion();

        $stmt = $db->prepare($sql);
        $stmt->execute();

        $estados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarEstadosUsuarios: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $estados;
}

/**
 * Obtener un estado de usuario por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerEstadoUsuarioPorId(int $id): ?array
{
    $estado = null;
    try {
        $db = conexion();

        $stmt = $db->prepare("SELECT * FROM estados_usuarios WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $estado = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerEstadoUsuarioPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $estado;
}

/**
 * Insertar un nuevo estado de usuario
 *
 * @param string $nombre
 * @param string|null $descripcion
 * @return int|null ID del nuevo estado insertado
 */
function crearEstadoUsuario(string $nombre, ?string $descripcion = null): ?int
{
    $nuevoId = null;
    try {
        $db = conexion();

        $stmt = $db->prepare("INSERT INTO estados_usuarios (nombre, descripcion) VALUES (:nombre, :descripcion)");
        $stmt->bindValue(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en crearEstadoUsuario: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}
}