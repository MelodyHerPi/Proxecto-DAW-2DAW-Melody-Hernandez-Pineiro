<?php
/**
 * Archivo con las acciones sobre las tablas notificaciones
 */
namespace App\Model;
use App\Core\Model;
class NotificacionModel{
/**
 * Listar todas las notificaciones, con opción de filtro por usuario, tipo o evento
 *
 * @param array|null $filtro ['id_usuario' => int, 'id_tipo' => int, 'id_evento' => int]
 * @return array Listado de notificaciones
 */
function listarNotificaciones(?array $filtro = null): array
{
    $notificaciones = [];
    $sql = "SELECT * FROM notificaciones WHERE 1=1";

    try {
        $db = conexion();

        if (isset($filtro['id_usuario'])) {
            $sql .= " AND id_usuario = :id_usuario";
        }
        if (isset($filtro['id_tipo'])) {
            $sql .= " AND id_tipo = :id_tipo";
        }
        if (isset($filtro['id_evento'])) {
            $sql .= " AND id_evento = :id_evento";
        }

        $stmt = $db->prepare($sql);

        if (isset($filtro['id_usuario'])) {
            $stmt->bindValue(':id_usuario', $filtro['id_usuario'], PDO::PARAM_INT);
        }
        if (isset($filtro['id_tipo'])) {
            $stmt->bindValue(':id_tipo', $filtro['id_tipo'], PDO::PARAM_INT);
        }
        if (isset($filtro['id_evento'])) {
            $stmt->bindValue(':id_evento', $filtro['id_evento'], PDO::PARAM_INT);
        }

        $stmt->execute();
        $notificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarNotificaciones: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $notificaciones;
}

/**
 * Obtener una notificación por su ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerNotificacionPorId(int $id): ?array
{
    $notificacion = null;

    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM notificaciones WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $notificacion = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerNotificacionPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $notificacion;
}

/**
 * Crear una nueva notificación
 *
 * @param int $id_usuario
 * @param int $id_tipo
 * @param string $contenido
 * @param int|null $id_evento
 * @param bool $leida
 * @return int|null ID de la notificación creada
 */
function crearNotificacion(int $id_usuario, int $id_tipo, string $contenido, ?int $id_evento = null, bool $leida = false): ?int
{
    $nuevoId = null;

    try {
        $db = conexion();

        $stmt = $db->prepare("
            INSERT INTO notificaciones (id_usuario, id_tipo, contenido, id_evento, leida)
            VALUES (:id_usuario, :id_tipo, :contenido, :id_evento, :leida)
        ");

        $stmt->bindValue(':id_usuario', $id_usuario, PDO::PARAM_INT);
        $stmt->bindValue(':id_tipo', $id_tipo, PDO::PARAM_INT);
        $stmt->bindValue(':contenido', $contenido, PDO::PARAM_STR);
        $stmt->bindValue(':id_evento', $id_evento, PDO::PARAM_INT);
        $stmt->bindValue(':leida', $leida, PDO::PARAM_BOOL);

        $stmt->execute();
        $nuevoId = (int)$db->lastInsertId();

    } catch (PDOException $e) {
        error_log("Error en crearNotificacion: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $nuevoId;
}

/**
 * Listar todos los tipos de notificación
 *
 * @return array
 */
function listarTiposNotificacion(): array
{
    $tipos = [];

    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM notificaciones_tipos");
        $stmt->execute();
        $tipos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en listarTiposNotificacion: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $tipos;
}

/**
 * Obtener un tipo de notificación por ID
 *
 * @param int $id
 * @return array|null
 */
function obtenerTipoNotificacionPorId(int $id): ?array
{
    $tipo = null;

    try {
        $db = conexion();
        $stmt = $db->prepare("SELECT * FROM notificaciones_tipos WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $tipo = $stmt->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log("Error en obtenerTipoNotificacionPorId: " . $e->getMessage());
    } finally {
        $db = null;
    }

    return $tipo;
}

}