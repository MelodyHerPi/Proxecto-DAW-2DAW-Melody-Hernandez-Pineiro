<?php
/**
 * Archivo con los endpoints de la web
 */

use App\Core\Router;

use App\Controller\UsuarioController;
use App\Controller\EventoController;
use App\Controller\NotificacionController;
use App\Controller\ForoController;
use App\Controller\EventoMiembroController;
use App\Controller\EventoGaleriaController;



// USUARIOS
$router->get('/usuarios', [UsuarioController::class, 'index']);
$router->get('/usuarios/{id}', [UsuarioController::class, 'show']);
$router->post('/usuarios', [UsuarioController::class, 'store']);
$router->put('/usuarios/{id}', [UsuarioController::class, 'update']);
$router->delete('/usuarios/{id}', [UsuarioController::class, 'destroy']);



// EVENTOS
$router->get('/eventos', [EventoController::class, 'index']);
$router->get('/eventos/{id}', [EventoController::class, 'show']);
$router->post('/eventos', [EventoController::class, 'store']);
$router->put('/eventos/{id}', [EventoController::class, 'update']);
$router->delete('/eventos/{id}', [EventoController::class, 'destroy']);



// EVENTO - MIEMBROS (N:M)
$router->get('/eventos/{id_evento}/miembros', [EventoMiembroController::class, 'index']);
$router->post('/eventos/{id_evento}/unirse', [EventoMiembroController::class, 'store']);
$router->delete('/eventos/{id_evento}/salir/{id_usuario}', [EventoMiembroController::class, 'destroy']);



// EVENTO - GALERÍA
$router->get('/eventos/{id_evento}/galeria', [EventoGaleriaController::class, 'index']);
$router->post('/eventos/{id_evento}/galeria', [EventoGaleriaController::class, 'store']);
$router->delete('/galeria/{id}', [EventoGaleriaController::class, 'destroy']);



// NOTIFICACIONES
$router->get('/notificaciones', [NotificacionController::class, 'index']);
$router->get('/notificaciones/{id}', [NotificacionController::class, 'show']);
$router->put('/notificaciones/{id}/leer', [NotificacionController::class, 'markAsRead']);
$router->delete('/notificaciones/{id}', [NotificacionController::class, 'destroy']);



// FORO - HILOS
$router->get('/foro/hilos', [ForoController::class, 'index']);
$router->get('/foro/hilos/{id}', [ForoController::class, 'show']);
$router->post('/foro/hilos', [ForoController::class, 'store']);
$router->put('/foro/hilos/{id}', [ForoController::class, 'update']);
$router->delete('/foro/hilos/{id}', [ForoController::class, 'destroy']);



// FORO - MENSAJES
$router->get('/foro/hilos/{id_hilo}/mensajes', [ForoController::class, 'mensajes']);
$router->post('/foro/hilos/{id_hilo}/mensajes', [ForoController::class, 'storeMensaje']);
$router->delete('/foro/mensajes/{id}', [ForoController::class, 'deleteMensaje']);