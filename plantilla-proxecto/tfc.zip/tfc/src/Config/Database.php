<?php
/**
 * Archivo de constantes de la base de datos
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'AllDanceTogether');
define('DB_USER', 'root');
define('DB_PASS', 'abc');
define('DB_CHARSET', 'utf8mb4');