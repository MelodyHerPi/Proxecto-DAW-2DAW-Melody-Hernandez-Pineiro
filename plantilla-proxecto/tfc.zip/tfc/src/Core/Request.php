<?php

namespace App\Core;

class Request
{
    public function uri(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        return parse_url($uri, PHP_URL_PATH);
    }

    public function method(): string
    {
        return $_SERVER['REQUEST_METHOD'] ?? 'GET';
    }

    public function body(): array
    {
        $body = file_get_contents('php://input');

        if (!$body) {
            return [];
        }

        $data = json_decode($body, true);

        return is_array($data) ? $data : [];
    }

    public function query(): array
    {
        return $_GET ?? [];
    }

    public function headers(): array
    {
        if (function_exists('getallheaders')) {
            return getallheaders();
        }

        $headers = [];

        foreach ($_SERVER as $key => $value) {
            if (str_starts_with($key, 'HTTP_')) {
                $name = str_replace('HTTP_', '', $key);
                $headers[$name] = $value;
            }
        }

        return $headers;
    }

    public function header(string $name): ?string
    {
        $headers = $this->headers();

        return $headers[$name] ?? $headers[strtoupper($name)] ?? null;
    }
}