<?php
namespace App\Core;

class Router
{
    private array $routes = [];

    public function get(string $uri, array $handler)
    {
        $this->addRoute('GET', $uri, $handler);
    }

    public function post(string $uri, array $handler)
    {
        $this->addRoute('POST', $uri, $handler);
    }

    public function put(string $uri, array $handler)
    {
        $this->addRoute('PUT', $uri, $handler);
    }

    public function delete(string $uri, array $handler)
    {
        $this->addRoute('DELETE', $uri, $handler);
    }

    private function addRoute(string $method, string $uri, array $handler)
    {
        $this->routes[] = [
            'method' => $method,
            'uri' => $uri,
            'handler' => $handler
        ];
    }

    public function dispatch()
    {
        $requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $requestMethod = $_SERVER['REQUEST_METHOD'];

        foreach ($this->routes as $route) {

            if ($route['method'] !== $requestMethod) {
                continue;
            }

            // Convertir {id} en regex
            $pattern = '#^' . preg_replace('#\{[\w]+\}#', '([\w-]+)', $route['uri']) . '$#';

            if (preg_match($pattern, $requestUri, $matches)) {
                array_shift($matches); // quitar match completo

                $controllerClass = $route['handler'][0];
                $method = $route['handler'][1];

                if (!class_exists($controllerClass)) {
                    http_response_code(500);
                    echo "Controlador no encontrado";
                    return;
                }

                $controller = new $controllerClass();

                if (!method_exists($controller, $method)) {
                    http_response_code(500);
                    echo "Método no encontrado";
                    return;
                }

                call_user_func_array([$controller, $method], $matches);
                return;
            }
        }

        // 404 si no encuentra ruta
        http_response_code(404);
        echo "404 - Ruta no encontrada";
    }
}