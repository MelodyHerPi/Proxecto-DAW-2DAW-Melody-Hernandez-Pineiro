#!/bin/bash
# Salir si algo falla
set -e

echo "🧹 Limpiando intentos anteriores..."
docker compose down --remove-orphans

echo "🚀 Descargando imágenes y construyendo contenedores..."
# --pull asegura que intente bajar la versión más reciente de internet
docker compose build --pull
docker compose up -d

echo ""
echo "✅ ¡Proyecto levantado con éxito!"
echo "--------------------------------"
echo "🌐 Web: http://localhost:8080"
echo "🛠️  DB Admin: http://localhost:8081"
echo "--------------------------------"