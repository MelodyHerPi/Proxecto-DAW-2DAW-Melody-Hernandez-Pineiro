# All Dance Together 
> En este archivo encontrarás información relevante del sistema

## Estructura del programa 
``` 
tfc/
├── apache/                 # Configuración del servidor web
│   └── default.conf
├── php/                    # Entorno de ejecución PHP
│   └── Dockerfile
├── src/  
│   ├── app/                # MVC
│   │   ├── Controller/
│   │   ├── Models/
│   │   └── Views/
│   ├── public/             # Único punto de entrada (index.php)
│   │   ├── assents/
|   │   │   ├── fonts/      # Archivos google fonts
|   │   │   └── img/        # Imágenes de decoración del sistema
│   │   ├── css/
│   │   ├── js/
│   │   ├── .htaccess
│   │   └── index.php       # Enrutador y punto de acceso principal de la aplicación
│   ├── config/             # Configuración de BD, constantes y endpoints de la web
│   ├── core/               # Conexion con la BD y archivos Router, Response y Request
│   └── vendor/             # Librerías (si usas Composer)
├── docker-compose.yml      # Orquestador
├── build.sh                # Script de despliegue/reinicio
└── install.sh              # Script de instalación inicial
``` 

## Lista de tareas que faltan por realizar
1. Las vistas y sus js y estilos correspondientes
2. build.sh que abra directamente el navegador además de levantar el servicio