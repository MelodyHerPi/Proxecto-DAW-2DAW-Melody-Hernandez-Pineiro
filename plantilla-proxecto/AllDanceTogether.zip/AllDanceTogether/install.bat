# PowerShell como Admin:
wsl --install
# Reiniciar, luego en la terminal Ubuntu:
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
sudo service docker start