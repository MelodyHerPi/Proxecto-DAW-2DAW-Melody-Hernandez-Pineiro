# Comandos hechos y para qué 

netstat -ano | findstr :80 -> ¿Quién ocupa mis puertos?

docker logs tfc_web -> ver errores
docker exec tfc_web tail -n 20 /var/log/apache2/error.log




# 19/05 ver si funciona la nueva configuración sin docker desktop
### Lista de cosas por revisar
- Los js de las páginas de Login, Registro e inicio (la ruta)
- Si el bash y batch funcionan
- Hacer que se ejecute el init.sql 
- Página de inicio, estilo y funcionalidades
- Descripciones de las cards de INICIO
- Politica de privacidad y contacto
- Validator y Wave
- Title de cada página y favicon

### Queda por hacer
- /proximamente para el contacto y para lo que necesite
- Estética más kawaii(?)
- añadir edad en registro, no dejar hacer registro si la edad es menor de 18 años, pero si es un grupo no debe marcarlo 




## Ver contenedores levantados
docker ps

## Ver logs en tiempo real
docker compose logs -f

## Parar todo
docker compose down