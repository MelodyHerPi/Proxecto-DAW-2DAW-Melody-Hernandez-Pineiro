/*
Archivo con el script de creación de la bd, sus tablas y datos estáticos
*/
DROP DATABASE IF EXISTS tfc_db;
CREATE DATABASE IF NOT EXISTS tfc_db;

USE tfc_db;

-- =========================================================
-- TIPOS DE USUARIO
-- =========================================================

CREATE TABLE IF NOT EXISTS usuario_tipos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255) NOT NULL
);

INSERT INTO usuario_tipos (nombre)
VALUES ('usuario'), ('grupo');

-- =========================================================
-- USUARIOS
-- =========================================================

CREATE TABLE IF NOT EXISTS usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre_real VARCHAR(255) NOT NULL,
    nombre_app VARCHAR(255) NOT NULL UNIQUE,
    correo_electronico VARCHAR(255) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    id_tipo_usuario INT NOT NULL,
    avatar_url VARCHAR(2048),

    CONSTRAINT fk_usuario_tipo
        FOREIGN KEY (id_tipo_usuario)
        REFERENCES usuario_tipos(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

INSERT INTO usuarios (nombre_real, nombre_app, correo_electronico, contrasena, id_tipo_usuario, avatar_url) 
VALUES ('admin', 'admin', 'admin@admin.com', '$2y$10$EYY5oeDi4/HA6.KZ5oq.u.D7ddeV1J9xMz2oSlCuQ67xwtlsnxdEG', 1, '/uploads/avatars/dd058129105a1849d4d0bec449f42978.jpeg'),
('grupo', 'grupo', 'admin@grupo.com', '$2y$10$EYY5oeDi4/HA6.KZ5oq.u.D7ddeV1J9xMz2oSlCuQ67xwtlsnxdEG', 2, '/uploads/avatars/dd058129105a1849d4d0bec449f42978.jpeg');

-- =========================================================
-- PERFILES DE USUARIO
-- =========================================================
CREATE TABLE IF NOT EXISTS perfiles (
    id                  INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario          INT NOT NULL UNIQUE,          -- 1 usuario = 1 perfil
    id_tipo_usuario     INT NOT NULL,
    descripcion         TEXT,
    miembros            JSON,                          -- solo relevante si es grupo
    foto_url            VARCHAR(2048),
    datos_extra         JSON,
    rrss                JSON,
    
    CONSTRAINT fk_perfil_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_perfil_tipo
        FOREIGN KEY (id_tipo_usuario)
        REFERENCES usuario_tipos(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);

-- =========================================================
-- TABLA UNIFICADA: PUBLICACIONES (Eventos y Noticias)
-- =========================================================
CREATE TABLE IF NOT EXISTS publicaciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_creador INT NOT NULL,
    tipo ENUM('evento', 'noticia') NOT NULL, -- Diferencia si es uno u otro
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT NOT NULL,                -- Sirve como contenido de la noticia o cuerpo del evento
    foto_url VARCHAR(2048) NULL,
    fecha DATETIME NULL,                     -- Fecha del evento (o publicación de la noticia)
    lugar VARCHAR(255) NULL,                 -- Lugar del evento (o procedencia de la noticia)
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_publicacion_creador
        FOREIGN KEY (id_creador)
        REFERENCES usuarios(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- =========================================================
-- TABLA DE COMENTARIOS (Sencilla, con una sola foránea)
-- =========================================================
CREATE TABLE IF NOT EXISTS comentarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    id_publicacion INT NOT NULL,             -- Foránea directa a la publicación comentada
    contenido TEXT NOT NULL,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_comentario_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_comentario_publicacion
        FOREIGN KEY (id_publicacion)
        REFERENCES publicaciones(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);