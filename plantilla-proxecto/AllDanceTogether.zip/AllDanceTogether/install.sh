#!/bin/bash

# ============================================================
#  AllDanceTogether — Script de instalación (Linux / macOS)
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $1"; }
ok()      { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║      AllDanceTogether — Instalador       ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── 1. Comprobar Docker ──────────────────────────────────────
info "Comprobando Docker..."
if ! command -v docker &>/dev/null; then
    error "Docker no está instalado. Instálalo con:\n  curl -fsSL https://get.docker.com | sh"
fi
ok "Docker encontrado: $(docker --version)"

# ── 2. Comprobar Docker Compose ──────────────────────────────
info "Comprobando Docker Compose..."
if docker compose version &>/dev/null 2>&1; then
    COMPOSE_CMD="docker compose"
elif command -v docker-compose &>/dev/null; then
    COMPOSE_CMD="docker-compose"
else
    error "Docker Compose no encontrado. Instala el plugin:\n  sudo apt-get install docker-compose-plugin"
fi
ok "Compose encontrado: $($COMPOSE_CMD version --short 2>/dev/null || $COMPOSE_CMD version)"

# ── 3. Comprobar que el daemon está corriendo ────────────────
info "Comprobando que el daemon de Docker está activo..."
if ! docker info &>/dev/null; then
    warn "El daemon no está corriendo. Intentando iniciarlo..."
    sudo systemctl start docker 2>/dev/null || error "No se pudo iniciar Docker. Ejecuta: sudo systemctl start docker"
fi
ok "Daemon de Docker activo."

# ── 4. Posicionarse en el directorio del proyecto ────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
info "Directorio del proyecto: $SCRIPT_DIR"

# ── 5. Parar contenedores previos si existieran ──────────────
info "Deteniendo contenedores anteriores (si existen)..."
$COMPOSE_CMD down --remove-orphans 2>/dev/null || true
ok "Limpieza previa completada."

# ── 6. Construir imágenes ────────────────────────────────────
info "Construyendo imágenes Docker (puede tardar la primera vez)..."
$COMPOSE_CMD build --no-cache
ok "Imágenes construidas."

# ── 7. Levantar servicios ────────────────────────────────────
info "Levantando servicios..."
$COMPOSE_CMD up -d
ok "Servicios levantados."

# ── 8. Esperar a que la web responda ─────────────────────────
info "Esperando a que la aplicación esté lista..."
TRIES=0
MAX=30
until curl -s -o /dev/null -w "%{http_code}" http://localhost:8085 | grep -qE "^[23]"; do
    TRIES=$((TRIES + 1))
    if [ $TRIES -ge $MAX ]; then
        warn "La app tardó más de lo esperado, pero puede que aún esté iniciando."
        break
    fi
    sleep 2
done
ok "Aplicación lista."

# ── 9. Resumen ───────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        ¡Todo listo! URLs de acceso       ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  🌐 App:        http://localhost:8085    ║${NC}"
echo -e "${GREEN}║  📋 Registro:   http://localhost:8085/login ║${NC}"
echo -e "${GREEN}║  🛢  phpMyAdmin: http://localhost:8082    ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "Para ver los logs:     ${CYAN}docker compose logs -f${NC}"
echo -e "Para parar:            ${CYAN}docker compose down${NC}"
echo ""
