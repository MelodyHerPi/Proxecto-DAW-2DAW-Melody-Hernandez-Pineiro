# Proyecto TFC - Entorno de Desarrollo Dockerizado

Este proyecto contiene un entorno completo basado en Docker para el desarrollo del TFC, utilizando **PHP 8.2**, **Apache**, **MariaDB** y **phpMyAdmin**.

## 🛠️ Requisitos Previos

Antes de empezar, asegúrate de tener instalado:
*   [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Asegúrate de que esté iniciado).
*   **WSL 2** habilitado en Windows.
*   Conexión a internet (necesaria para la primera descarga de imágenes).

---

## 🚀 Instalación y Puesta en Marcha

El proyecto incluye scripts automatizados para facilitar el despliegue según tu sistema operativo.

### En Windows (10/11)
1.  Localiza la carpeta del proyecto.
2.  Haz doble clic en el archivo `build.bat`.
    *   *Nota: Si el script falla al descargar, intenta ejecutarlo como Administrador.*

### En Linux / macOS
1.  Abre una terminal en la carpeta del proyecto.
2.  Dale permisos de ejecución al script: `chmod +x build.sh`
3.  Ejecuta el script: `./build.sh`

---

## 🌐 Acceso al Entorno

Una vez que los contenedores estén en verde (Running):

*   **Aplicación Web:** [http://localhost](http://localhost)
*   **Gestor de Base de Datos (phpMyAdmin):** [http://localhost:8082](http://localhost:8082)

### Datos de acceso a phpMyAdmin:
*   **Servidor:** `db` (Importante: NO usar `localhost`)
*   **Usuario:** `root`
*   **Contraseña:** `root`

---

## 🔧 Solución de Problemas Comunes

### 1. Error de conexión al descargar imágenes (`dial tcp...`)
Si al ejecutar el script ves errores de "Timeout" o "Connection failed", Docker está siendo bloqueado por tu red:
*   **DNS:** Cambia los DNS en Docker Desktop (Settings > Docker Engine) añadiendo `"dns": ["8.8.8.8", "8.8.4.4"]`.
*   **Redes Restringidas:** Si estás en una red de estudios/trabajo con firewall, intenta conectar el PC a los **datos móviles** solo para la primera descarga.
*   **Containerd:** En la configuración general de Docker Desktop, prueba a desactivar la opción *"Use containerd for pulling and storing images"*.

### 2. El puerto ya está ocupado
Si recibes un error tipo `port is already allocated`:
*   Asegúrate de no tener programas como **XAMPP, WampServer o Skype** abiertos, ya que suelen ocupar los puertos 80 y 3306.
*   Cierra otros proyectos de Docker que usen los mismos puertos.

### 3. Cambios en el código no se ven
Los archivos de la carpeta `./src` están vinculados a los contenedores. Si realizas cambios en PHP, solo tienes que refrescar el navegador. No es necesario reiniciar Docker a menos que modifiques el archivo `docker-compose.yml` o el `Dockerfile`.

---

## 📁 Estructura del Proyecto
*   `/src`: Código fuente de la aplicación (PHP, HTML, CSS, JS).
*   `/docker`: Archivos de configuración del servidor y base de datos.
*   `build.bat` / `build.sh`: Scripts de arranque rápido.