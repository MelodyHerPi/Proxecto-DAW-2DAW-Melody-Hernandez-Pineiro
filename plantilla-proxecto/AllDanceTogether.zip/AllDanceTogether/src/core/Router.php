<?php
// // Ejemplo de rutas que deberías tener definidas:
// $router->add('GET', '/login', [new LoginController(), 'index']);
// $router->add('POST', '/login/entrar', [new LoginController(), 'authenticate']);
// $router->add('GET', '/logout', [new LogoutController(), 'index']);

// //Elementos estáticos comunes a tocas las páginas (contacto, términos de uso,...)
// $router->add('GET', '/politicas', [new StaticController(), 'politicas']);
// $router->add('GET', '/terminos', [new StaticController(), 'terminos']);
// $router->add('GET', '/ayuda', [new StaticController(), 'ayuda']);
// $router->add('GET', '/contacto', [new StaticController(), 'contacto']);


// $router->add('GET', '/registro', [new RegistroController(), 'index']);
// $router->add('POST', '/registro/guardar', [new RegistroController(), 'store']);

// $router->add('GET', '/home', [new HomeController(), 'index']);
// $router->add('GET', '/logout', [new LoginController(), 'logout']);

// $router->add('GET', '/usuarios', [new UsuariosController(), 'index']);

// // Ruta para la página de detalle al hacer clic en una tarjeta (Pasando el ID por parámetro GET)
// $router->add('GET', '/usuarios/detalle', [new DetalleUsuarioController(), 'index']);