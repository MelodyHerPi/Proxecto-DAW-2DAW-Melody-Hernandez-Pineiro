<?php

function normalizarFotoUrl(string $foto_url): string {
    if (empty($foto_url)) return '';
    return strpos($foto_url, '/public') === 0 ? substr($foto_url, 7) : $foto_url;
}

function tieneFotoValida(string $foto_url): bool {
    return !empty($foto_url) && (
        str_ends_with($foto_url, '.jpg')  ||
        str_ends_with($foto_url, '.jpeg') ||
        str_ends_with($foto_url, '.png')  ||
        str_ends_with($foto_url, '.webp') ||
        str_ends_with($foto_url, '.gif')
    );
}

function normalizarListaFotos(array $lista): array {
    return array_map(function($item) {
        if (!empty($item['foto_url'])) {
            $item['foto_url'] = normalizarFotoUrl($item['foto_url']);
        }
        return $item;
    }, $lista);
}