<?php
// Configuración para conectar desde el contenedor PHP al de MariaDB
define('DB_HOST', 'db'); // 'db' es el nombre del servicio en docker-compose
define('DB_NAME', 'tfc_db');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_PORT', '3306');