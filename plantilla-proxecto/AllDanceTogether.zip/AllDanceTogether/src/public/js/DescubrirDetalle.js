// ── Sidebar móvil ────────────────────────────────────────────
const btnMenu        = document.getElementById('btn-menu');
const sidebarNav     = document.getElementById('sidebar-nav');
const overlaySidebar = document.getElementById('overlay-sidebar');

if (btnMenu && sidebarNav && overlaySidebar) {
    btnMenu.addEventListener('click', () => {
        sidebarNav.classList.toggle('abierto');
        overlaySidebar.classList.toggle('activo');
    });
    overlaySidebar.addEventListener('click', () => {
        sidebarNav.classList.remove('abierto');
        overlaySidebar.classList.remove('activo');
    });
}

// ── Edición inline ───────────────────────────────────────────
const btnActivar  = document.getElementById('btn-activar-edicion');
const btnCancelar = document.getElementById('btn-cancelar-edicion');
const modoLectura = document.getElementById('modo-lectura');
const modoEdicion = document.getElementById('modo-edicion');
const primerInput = document.getElementById('txt-titulo');

if (btnActivar && modoEdicion) {
    btnActivar.addEventListener('click', () => {
        modoEdicion.removeAttribute('hidden');
        modoEdicion.style.display = 'block';   // fuerza visibilidad
        if (modoLectura) modoLectura.style.display = 'none';
        btnActivar.setAttribute('aria-expanded', 'true');
        if (primerInput) primerInput.focus();
    });

    if (btnCancelar) {
        btnCancelar.addEventListener('click', () => {
            modoEdicion.setAttribute('hidden', '');
            modoEdicion.style.display = '';
            if (modoLectura) modoLectura.style.display = '';
            btnActivar.setAttribute('aria-expanded', 'false');
            btnActivar.focus();
        });
    }
} else {
    console.warn('Edición inline: btnActivar=', btnActivar, '| modoEdicion=', modoEdicion);
}

// ── Edición de comentarios ───────────────────────────────────
document.querySelectorAll('.btn-editar-comentario').forEach(btn => {
    btn.addEventListener('click', () => {
        const id    = btn.dataset.id;
        const texto = document.getElementById('texto-' + id);
        const form  = document.getElementById('form-editar-' + id);

        if (!texto || !form) {
            console.warn('No se encontró texto o form para id:', id);
            return;
        }

        texto.hidden = true;
        form.hidden  = false;
        form.querySelector('textarea').focus();
    });
});

document.querySelectorAll('.btn-cancelar-edicion-comentario').forEach(btn => {
    btn.addEventListener('click', () => {
        const id    = btn.dataset.id;
        const texto = document.getElementById('texto-' + id);
        const form  = document.getElementById('form-editar-' + id);

        if (!texto || !form) return;

        form.hidden  = true;
        texto.hidden = false;
    });
});