const btnMenu = document.getElementById('btn-menu');
const sidebar = document.getElementById('sidebar-nav');
const overlay = document.getElementById('overlay-sidebar');

function abrirSidebar() {
    sidebar.classList.add('abierto');
    overlay.classList.add('activo');
    overlay.removeAttribute('aria-hidden');
    btnMenu.setAttribute('aria-expanded', 'true');
    btnMenu.setAttribute('aria-label', 'Cerrar menú de navegación');
    sidebar.querySelector('a')?.focus();
}

function cerrarSidebar() {
    sidebar.classList.remove('abierto');
    overlay.classList.remove('activo');
    overlay.setAttribute('aria-hidden', 'true');
    btnMenu.setAttribute('aria-expanded', 'false');
    btnMenu.setAttribute('aria-label', 'Abrir menú de navegación');
    btnMenu.focus();
}

btnMenu?.addEventListener('click', () => {
    sidebar.classList.contains('abierto') ? cerrarSidebar() : abrirSidebar();
});
overlay?.addEventListener('click', cerrarSidebar);
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && sidebar.classList.contains('abierto')) cerrarSidebar();
});

sidebar?.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab' || !sidebar.classList.contains('abierto')) return;
    const focusables = [...sidebar.querySelectorAll('a, button')];
    const primero = focusables[0];
    const ultimo  = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === primero) {
        e.preventDefault(); ultimo.focus();
    } else if (!e.shiftKey && document.activeElement === ultimo) {
        e.preventDefault(); primero.focus();
    }
});

