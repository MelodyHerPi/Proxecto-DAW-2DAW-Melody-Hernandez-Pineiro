   
        // Lógica del Menu Mobile (Sidebar Hamburguesa)
        const btnMenu = document.getElementById('btn-menu');
        const sidebarNav = document.getElementById('sidebar-nav');
        const overlaySidebar = document.getElementById('overlay-sidebar');

        if(btnMenu && sidebarNav && overlaySidebar) {
            btnMenu.addEventListener('click', () => {
                const esAbierto = sidebarNav.classList.toggle('abierto');
                overlaySidebar.classList.toggle('activo');
                btnMenu.setAttribute('aria-expanded', esAbierto);
            });

            overlaySidebar.addEventListener('click', () => {
                sidebarNav.classList.remove('abierto');
                overlaySidebar.classList.remove('activo');
                btnMenu.setAttribute('aria-expanded', 'false');
            });
        }

        // Previsualización de Avatar
        function previsualizarImagen(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatar-img-preview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Manipulación dinámica de miembros del DOM
        let contadorMiembros = <?php echo count($miembros); ?>;

        function agregarMiembro() {
            const input = document.getElementById('nuevo_miembro_input');
            const nombre = input.value.trim();
            if (nombre === "") return;

            const contenedor = document.getElementById('contenedor-miembros');
            const nuevoId = 'miembro_nuevo_' + contadorMiembros++;

            const div = document.createElement('div');
            div.className = 'item-miembro';
            div.id = nuevoId;
            div.setAttribute('role', 'listitem');

            div.innerHTML = `
                <span class="item-miembro__nombre" title="${escapeHTML(nombre)}">${escapeHTML(nombre)}</span>
                <input type="hidden" name="miembros_nombres[]" value="${escapeHTML(nombre)}">
                <button type="button" class="item-miembro__eliminar" onclick="eliminarMiembro('${nuevoId}')">Eliminar</button>
            `;

            contenedor.appendChild(div);
            input.value = "";
            input.focus();
        }

        function eliminarMiembro(idElemento) {
            const elemento = document.getElementById(idElemento);
            if (elemento) elemento.remove();
        }

        function escapeHTML(str) {
            return str.replace(/[&<>'"]/g, tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag));
        }
    