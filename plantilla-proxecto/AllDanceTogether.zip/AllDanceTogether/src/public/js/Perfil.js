// ============================================================
// Perfil.js — lógica de la página de perfil
// ============================================================

// ----- Menú mobile (mismo patrón que Inicio.js) -----
const btnMenu        = document.getElementById('btn-menu');
const sidebarNav     = document.getElementById('sidebar-nav');
const overlaySidebar = document.getElementById('overlay-sidebar');

if (btnMenu && sidebarNav && overlaySidebar) {
    btnMenu.addEventListener('click', () => {
        const esAbierto = sidebarNav.classList.toggle('abierto');
        overlaySidebar.classList.toggle('activo');
        btnMenu.setAttribute('aria-expanded', esAbierto);
    });

    overlaySidebar.addEventListener('click', () => {
        sidebarNav.classList.remove('abierto');
        overlaySidebar.classList.remove('activo');
        btnMenu.setAttribute('aria-expanded', 'false');
    });
}

// ----- Previsualización de avatar -----
function previsualizarImagen(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('avatar-img-preview').src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ----- Miembros del grupo -----
let contadorMiembros = document.querySelectorAll('#contenedor-miembros .item-miembro').length;

function agregarMiembro() {
    const input  = document.getElementById('nuevo_miembro_input');
    const nombre = input.value.trim();
    if (!nombre) return;

    const contenedor = document.getElementById('contenedor-miembros');
    const nuevoId    = 'miembro_nuevo_' + contadorMiembros++;

    const div = document.createElement('div');
    div.className = 'item-miembro';
    div.id = nuevoId;
    div.setAttribute('role', 'listitem');
    div.innerHTML = `
        <span class="item-miembro__nombre" title="${escapeHTML(nombre)}">${escapeHTML(nombre)}</span>
        <input type="hidden" name="miembros_nombres[]" value="${escapeHTML(nombre)}">
        <button type="button" class="item-miembro__eliminar"
                aria-label="Eliminar miembro ${escapeHTML(nombre)}"
                onclick="eliminarMiembro('${nuevoId}')">Eliminar</button>
    `;
    contenedor.appendChild(div);
    input.value = '';
    input.focus();
}

function eliminarMiembro(idElemento) {
    const el = document.getElementById(idElemento);
    if (el) el.remove();
}

function escapeHTML(str) {
    return str.replace(/[&<>'"]/g, tag => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag
    ));
}

// ----- Toggle visibilidad de contraseña -----
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const mostrar = input.type === 'password';
    input.type = mostrar ? 'text' : 'password';
    btn.setAttribute('aria-label', mostrar ? 'Ocultar contraseña' : 'Mostrar contraseña');
}

// ----- Validación del formulario de contraseña -----
const formContrasena = document.getElementById('form-contrasena');
if (formContrasena) {
    formContrasena.addEventListener('submit', (e) => {
        const nueva      = document.getElementById('contrasena_nueva').value;
        const confirmar  = document.getElementById('contrasena_confirmar').value;
        const errorEl    = document.getElementById('error-contrasena');

        errorEl.hidden = true;
        errorEl.textContent = '';

        if (nueva.length < 8) {
            e.preventDefault();
            errorEl.textContent = 'La contraseña debe tener al menos 8 caracteres.';
            errorEl.hidden = false;
            document.getElementById('contrasena_nueva').focus();
            return;
        }

        if (nueva !== confirmar) {
            e.preventDefault();
            errorEl.textContent = 'Las contraseñas no coinciden.';
            errorEl.hidden = false;
            document.getElementById('contrasena_confirmar').focus();
        }
    });
}

// ----- Radio opciones: resalte visual al seleccionar -----
document.querySelectorAll('.radio-grupo').forEach(grupo => {
    grupo.querySelectorAll('input[type="radio"]').forEach(radio => {
        radio.addEventListener('change', () => {
            grupo.querySelectorAll('.radio-opcion').forEach(op => op.classList.remove('radio-opcion--activa'));
            if (radio.checked) radio.closest('.radio-opcion').classList.add('radio-opcion--activa');
        });
    });
});