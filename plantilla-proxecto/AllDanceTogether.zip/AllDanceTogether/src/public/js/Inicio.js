
const btnMenu = document.getElementById('btn-menu');
const sidebar = document.getElementById('sidebar-nav');
const overlay = document.getElementById('overlay-sidebar');

function abrirSidebar() {
sidebar.classList.add('abierto');
overlay.classList.add('activo');
overlay.removeAttribute('aria-hidden');
btnMenu.setAttribute('aria-expanded', 'true');
btnMenu.setAttribute('aria-label', 'Cerrar menú de navegación');
sidebar.querySelector('a').focus();
}

function cerrarSidebar() {
sidebar.classList.remove('abierto');
overlay.classList.remove('activo');
overlay.setAttribute('aria-hidden', 'true');
btnMenu.setAttribute('aria-expanded', 'false');
btnMenu.setAttribute('aria-label', 'Abrir menú de navegación');
btnMenu.focus();
}

btnMenu.addEventListener('click', () => {
sidebar.classList.contains('abierto') ? cerrarSidebar() : abrirSidebar();
});

overlay.addEventListener('click', cerrarSidebar);

document.addEventListener('keydown', (e) => {
if (e.key === 'Escape' && sidebar.classList.contains('abierto')) cerrarSidebar();
});


/* ── Carrusel ─────────────────────────────────────── */
(function () {
const pista     = document.getElementById('carrusel-pista');
const btnPrev   = document.getElementById('carrusel-anterior');
const btnNext   = document.getElementById('carrusel-siguiente');
const puntos    = document.querySelectorAll('.carrusel__punto');
const total     = puntos.length;
let actual      = 0;
let intervalo;

function irA(indice) {
    actual = (indice + total) % total;
    pista.style.transform = `translateX(-${actual * 100}%)`;
    puntos.forEach((p, i) => {
        p.classList.toggle('carrusel__punto--activo', i === actual);
        p.setAttribute('aria-selected', i === actual ? 'true' : 'false');
    });
    // Actualizar aria-label de diapositivas activas
    const diapositivas = pista.querySelectorAll('.carrusel__diapositiva');
    diapositivas.forEach((d, i) => {
        d.setAttribute('aria-hidden', i !== actual ? 'true' : 'false');
    });
}

function iniciarAuto() {
    intervalo = setInterval(() => irA(actual + 1), 5000);
}

function pararAuto() {
    clearInterval(intervalo);
}

btnPrev.addEventListener('click', () => { pararAuto(); irA(actual - 1); iniciarAuto(); });
btnNext.addEventListener('click', () => { pararAuto(); irA(actual + 1); iniciarAuto(); });

puntos.forEach((p, i) => {
    p.addEventListener('click', () => { pararAuto(); irA(i); iniciarAuto(); });
});

// Pausa al hover
pista.parentElement.addEventListener('mouseenter', pararAuto);
pista.parentElement.addEventListener('mouseleave', iniciarAuto);

// Pausa si el usuario prefiere menos movimiento
if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    iniciarAuto();
}

// Inicializar aria-hidden en diapos no activas
irA(0);
})();
sidebar.addEventListener('keydown', (e) => {
if (e.key !== 'Tab' || !sidebar.classList.contains('abierto')) return;
const focusables = [...sidebar.querySelectorAll('a, button')];
const primero = focusables[0];
const ultimo  = focusables[focusables.length - 1];
if (e.shiftKey && document.activeElement === primero) {
    e.preventDefault(); ultimo.focus();
} else if (!e.shiftKey && document.activeElement === ultimo) {
    e.preventDefault(); primero.focus();
}
});
