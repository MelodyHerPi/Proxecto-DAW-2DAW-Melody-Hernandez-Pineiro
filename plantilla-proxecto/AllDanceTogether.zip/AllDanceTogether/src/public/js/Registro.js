function validarRegistro(event) {
    const pass1 = document.getElementById('contrasena');
    const pass2 = document.getElementById('repetir_contrasena');
    const errorDiv = document.getElementById('error-contrasena');

    if (pass1.value !== pass2.value) {
        event.preventDefault();
        
        // Mostrar el error
        errorDiv.style.display = 'block';
        
        // Marcar el campo como inválido para lectores de pantalla
        pass2.setAttribute('aria-invalid', 'true');
        
        // Vincular el campo al mensaje de error dinámicamente
        pass2.setAttribute('aria-describedby', 'error-contrasena'); // Esto sobrescribe la ayuda anterior con el mensaje de error
        
        // Enfocar el campo para que el usuario pueda corregirlo rápido
        pass2.focus();
        
        return false;
    }
    
    // Si todo es correcto, limpiar atributos de error
    errorDiv.style.display = 'none';
    pass2.setAttribute('aria-invalid', 'false');
    pass2.setAttribute('aria-describedby', 'ayuda-confirmacion'); // Volver a la ayuda original
    
    return true;
}

// Función modular reutilizable para mostrar/ocultar texto de las contraseñas de forma accesible
function alternarVisibilidadContrasena(idEntrada, idBoton) {
    const entrada = document.getElementById(idEntrada);
    const boton = document.getElementById(idBoton);
    if (entrada.type === 'password') {
        entrada.type = 'text';
        boton.setAttribute('aria-pressed', 'true');
        boton.innerText = 'OCULTAR';
        boton.setAttribute('aria-label', 'Ocultar contraseña');
    } else {
        entrada.type = 'password';
        boton.setAttribute('aria-pressed', 'false');
        boton.innerText = 'VER';
        boton.setAttribute('aria-label', 'Mostrar contraseña');
    }
}