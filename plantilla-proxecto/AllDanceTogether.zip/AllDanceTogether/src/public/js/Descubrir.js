
// Lógica del Sidebar móvil
const btnMenu = document.getElementById('btn-menu');
const sidebarNav = document.getElementById('sidebar-nav');
const overlaySidebar = document.getElementById('overlay-sidebar');

if(btnMenu && sidebarNav && overlaySidebar) {
    btnMenu.addEventListener('click', () => {
        sidebarNav.classList.toggle('abierto');
        overlaySidebar.classList.toggle('activo');
    });
    overlaySidebar.addEventListener('click', () => {
        sidebarNav.classList.remove('abierto');
        overlaySidebar.classList.remove('activo');
    });
}

// Lógica de apertura/cierre de la ventana Modal
const btnAbrirModal = document.getElementById('btn-abrir-modal');
const btnCerrarModal = document.getElementById('btn-cerrar-modal');
const btnCancelarModal = document.getElementById('btn-cancelar-modal');
const modal = document.getElementById('modal-publicacion');

const abrirModal = () => modal.classList.add('activo');
const cerrarModal = () => modal.classList.remove('activo');

if (btnAbrirModal) btnAbrirModal.addEventListener('click', abrirModal);
if (btnCerrarModal) btnCerrarModal.addEventListener('click', cerrarModal);
if (btnCancelarModal) btnCancelarModal.addEventListener('click', cerrarModal);

// Comportamiento Dinámico: Ocultar o mostrar campos si es Noticia o Evento
const selectorTipo = document.getElementById('modal-tipo');
const contenedorFecha = document.getElementById('contenedor-fecha');
const inputFecha = document.getElementById('modal-fecha');

selectorTipo.addEventListener('change', function() {
    if (this.value === 'noticia') {
        // Para las noticias, fecha y lugar pueden ser opcionales
        inputFecha.required = false;
    } else {
        // Para los eventos, forzamos que pongan cuándo es
        inputFecha.required = true;
    }
});
