// ── Sidebar móvil ────────────────────────────────────────────
const btnMenu        = document.getElementById('btn-menu');
const sidebarNav     = document.getElementById('sidebar-nav');
const overlaySidebar = document.getElementById('overlay-sidebar');

if (btnMenu && sidebarNav && overlaySidebar) {
    btnMenu.addEventListener('click', () => {
        sidebarNav.classList.toggle('abierto');
        overlaySidebar.classList.toggle('activo');
    });
    overlaySidebar.addEventListener('click', () => {
        sidebarNav.classList.remove('abierto');
        overlaySidebar.classList.remove('activo');
    });
}

// ── Modal ────────────────────────────────────────────────────
const btnAbrirModal   = document.getElementById('btn-abrir-modal');
const btnCerrarModal  = document.getElementById('btn-cerrar-modal');
const btnCancelarModal= document.getElementById('btn-cancelar-modal');
const modal           = document.getElementById('modal-publicacion');

const abrirModal  = () => modal.classList.add('activo');
const cerrarModal = () => modal.classList.remove('activo');

if (btnAbrirModal)    btnAbrirModal.addEventListener('click', abrirModal);
if (btnCerrarModal)   btnCerrarModal.addEventListener('click', cerrarModal);
if (btnCancelarModal) btnCancelarModal.addEventListener('click', cerrarModal);

// ── Campos dinámicos evento/noticia ──────────────────────────
const selectorTipo    = document.getElementById('modal-tipo');
const contenedorFecha = document.getElementById('contenedor-fecha');
const inputFecha      = document.getElementById('modal-fecha');

if (selectorTipo) {
    selectorTipo.addEventListener('change', function () {
        inputFecha.required = this.value !== 'noticia';
    });
}


