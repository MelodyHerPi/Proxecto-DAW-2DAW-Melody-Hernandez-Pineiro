<?php
session_start();
require_once __DIR__ . '/../config/config.php';

$url     = $_SERVER['REQUEST_URI'];
$urlPath = parse_url($url, PHP_URL_PATH);
$urlParts = explode('/', trim($urlPath, '/'));

$controllerName = !empty($urlParts[0]) ? ucfirst($urlParts[0]) . 'Controller' : 'InicioController';

// Convertir kebab-case a camelCase para que /perfil/cambiar-contrasena
// llame al método cambiarContrasena()
$actionRaw = $urlParts[1] ?? 'index';
$action    = lcfirst(str_replace(' ', '', ucwords(str_replace('-', ' ', $actionRaw))));

try {
    $controllerPath = __DIR__ . '/../app/Controllers/' . $controllerName . '.php';

    if (file_exists($controllerPath)) {
        require_once $controllerPath;
        $controllerObject = new $controllerName();

        if (method_exists($controllerObject, $action)) {
            $controllerObject->$action();
        } else {
            throw new Exception('Acción no encontrada');
        }
    } else {
        throw new Exception('Controlador no encontrado');
    }
} catch (\Throwable $th) {
    echo '<h1>404 Not Found</h1>';
    echo 'Error: ' . $th->getMessage();
}