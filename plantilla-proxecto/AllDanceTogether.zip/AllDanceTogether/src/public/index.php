<?php
// Iniciar sesión para que esté disponible en todos los controladores
session_start();

require_once __DIR__ . '/../config/config.php';

$url = $_SERVER['REQUEST_URI'];
// Limpiamos los parámetros GET de la URL (ej: ?registro=ok) para que no rompan el explode
$urlPath = parse_url($url, PHP_URL_PATH);
$urlParts = explode('/', trim($urlPath, '/'));

$controllerName = !empty($urlParts[0]) ? ucfirst($urlParts[0]) . "Controller" : "HomeController";
$action = $urlParts[1] ?? 'index';

try {
    $controllerPath = __DIR__ . "/../app/Controllers/" . $controllerName . ".php";
    
    if (file_exists($controllerPath)) {
        require_once $controllerPath;
        $controllerObject = new $controllerName();
        
        if (method_exists($controllerObject, $action)) {
            $controllerObject->$action();
        } else {
            throw new Exception("Acción no encontrada");
        }
    } else {
        throw new Exception("Controlador no encontrado");
    }
} catch (\Throwable $th) {
    echo "<h1>404 Not Found</h1>";
    echo "Error: " . $th->getMessage();
}