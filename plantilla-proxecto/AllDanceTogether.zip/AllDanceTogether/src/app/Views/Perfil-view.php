<?php
// Extracción segura de datos pasados desde el PerfilController
$nombre_usuario  = htmlspecialchars($_SESSION['usuario']['nick'] ?? 'Usuario');
$avatar_cabecera = !empty($perfil['foto_url']) ? htmlspecialchars($perfil['foto_url'], ENT_QUOTES, 'UTF-8') : '/public/uploads/avatars/default-avatar.png';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil — All Dance Together</title>
    <meta name="description" content="Gestiona tu información pública de perfil en All Dance Together.">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <style>
        /* ── Reset y Propiedades Base (Heredadas de tu layout) ── */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --color-fondo:        #03030a;
            --color-superficie:   rgba(10, 11, 28, 0.6);
            --color-tarjeta-izq:  rgba(16, 18, 42, 0.8);
            --color-tarjeta:      rgba(20, 21, 44, 0.7);
            --color-borde:        #1e1e3f;
            --color-borde-foco:   #ec4899;
            --gradiente-neon:     linear-gradient(135deg, #ec4899 0%, #3b82f6 100%);
            --color-texto:        #ffffff;
            --color-texto-suave:  #94a3b8;
            --color-marcador:     #475569;
            --color-principal:    #7b5ef8;
            
            /* Alertas */
            --color-error-fondo:   rgba(39, 10, 17, 0.7);
            --color-error-borde:   #ef4444;
            --color-error-texto:   #fca5a5;
            --color-exito-fondo:   rgba(9, 36, 22, 0.7);
            --color-exito-borde:   #10b981;
            --color-exito-texto:   #a7f3d0;

            --radio-mediano:      10px;
            --radio-md:           14px;
            --fuente-cuerpo:      'Montserrat', sans-serif;
            --fuente-titulo:      'Poppins', sans-serif;
            --ancho-sidebar:      240px;
            --alto-cabecera:      64px;
        }

        body {
            font-family: var(--fuente-cuerpo);
            background-color: var(--color-fondo);
            background-image:
                radial-gradient(circle at 45% 50%, rgba(236, 72, 153, 0.08) 0%, transparent 50%),
                radial-gradient(circle at 55% 50%, rgba(59, 130, 246, 0.08) 0%, transparent 50%);
            color: var(--color-texto);
            min-height: 100dvh;
            display: flex;
            flex-direction: column;
        }

        /* ── Skip link ───────────────────────────────────────── */
        .saltar-contenido {
            position: absolute;
            top: -100%;
            left: 1rem;
            background: var(--color-borde-foco);
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 0 0 6px 6px;
            font-size: 0.875rem;
            font-weight: 600;
            text-decoration: none;
            z-index: 9999;
            transition: top 0.2s;
        }
        .saltar-contenido:focus { top: 0; }

        /* ── Cabecera ────────────────────────────────────────── */
        .cabecera {
            height: var(--alto-cabecera);
            padding: 0 clamp(1rem, 3vw, 2rem);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: rgba(3, 3, 10, 0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(30, 30, 63, 0.5);
            position: sticky;
            top: 0;
            z-index: 200;
            gap: 1rem;
        }

        .cabecera__marca {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: inherit;
            flex-shrink: 0;
        }

        .cabecera__nombre {
            font-family: var(--fuente-titulo);
            font-size: clamp(1.1rem, 3vw, 1.5rem);
            font-weight: 700;
            background: linear-gradient(90deg, #fff 0%, var(--color-principal) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
        }

        .cabecera__menu-btn {
            display: none;
            background: none;
            border: 1px solid var(--color-borde);
            border-radius: 6px;
            color: var(--color-texto-suave);
            cursor: pointer;
            padding: 0.45rem 0.55rem;
            line-height: 1;
            transition: color 0.2s, border-color 0.2s;
        }
        .cabecera__menu-btn:hover { color: #fff; border-color: var(--color-texto-suave); }

        .cabecera__perfil {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            background: none;
            border: none;
            color: inherit;
            font-family: inherit;
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            padding: 0.3rem 0.5rem;
            border-radius: 6px;
        }

        .cabecera__avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: var(--gradiente-neon);
            padding: 2px;
            flex-shrink: 0;
        }

        .cabecera__avatar-imagen {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            background-color: var(--color-fondo);
        }

        /* ── Layout Principal ────────────────────────────────── */
        .contenedor-principal {
            flex: 1;
            display: grid;
            grid-template-columns: var(--ancho-sidebar) 1fr;
        }

        .overlay-sidebar {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            z-index: 150;
        }
        .overlay-sidebar.activo { display: block; }

        /* ── Menú Lateral (Sidebar) ─────────────────────────── */
        .navegacion-lateral {
            background-color: rgba(5, 5, 15, 0.6);
            border-right: 1px solid rgba(30, 30, 63, 0.4);
            padding: 1.75rem 1rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 2rem;
            position: sticky;
            top: var(--alto-cabecera);
            height: calc(100dvh - var(--alto-cabecera));
            overflow-y: auto;
        }

        .navegacion-lateral__lista {
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
            list-style: none;
        }

        .navegacion-lateral__enlace {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            padding: 0.75rem 1rem;
            color: var(--color-texto-suave);
            text-decoration: none;
            border-radius: var(--radio-mediano);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.2s ease;
            border: 1px solid transparent;
        }
        .navegacion-lateral__enlace:hover {
            color: #fff;
            background-color: rgba(255,255,255,0.04);
        }
        .navegacion-lateral__enlace--activo {
            color: #fff;
            background-color: rgba(123, 94, 248, 0.15);
            border-color: rgba(123, 94, 248, 0.3);
        }

        .nav-icono {
            width: 18px;
            height: 18px;
            flex-shrink: 0;
            opacity: 0.7;
        }
        .navegacion-lateral__enlace--activo .nav-icono,
        .navegacion-lateral__enlace:hover .nav-icono { opacity: 1; }

        .navegacion-lateral__lista li:last-child .navegacion-lateral__enlace {
            color: #f87171;
            margin-top: 0.5rem;
            border-top: 1px solid rgba(30, 30, 63, 0.5);
            padding-top: 1rem;
        }

        /* ── Área de Trabajo de Perfil (Diseño Amplio) ───────── */
        .principal {
            padding: clamp(1.5rem, 4vw, 3rem) clamp(1rem, 4vw, 2.5rem);
            min-width: 0;
        }

        .contenedor-panel-perfil {
            width: 100%;
            max-width: 1050px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 2rem;
            align-items: flex-start;
        }

        /* Columna Izquierda Visual */
        .tarjeta-identidad {
            background-color: var(--color-tarjeta-izq);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-md);
            padding: 2.5rem 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            position: sticky;
            top: calc(var(--alto-cabecera) + 2rem);
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        }

        /* Columna Derecha de Datos */
        .seccion-perfil {
            background-color: var(--color-superficie);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(30, 30, 63, 0.6);
            border-radius: var(--radio-md);
            padding: clamp(1.5rem, 4vw, 2.5rem);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
        }

        .seccion-perfil__titulo {
            font-family: var(--fuente-titulo);
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .seccion-perfil__subtitulo {
            font-size: 0.9rem;
            color: var(--color-texto-suave);
            margin-bottom: 2rem;
        }

        /* ── Alertas Estilizadas ────────────────────────────────── */
        .aviso {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            animation: fadeIn 0.3s ease;
        }
        .aviso--exito {
            background-color: var(--color-exito-fondo);
            border: 1px solid var(--color-exito-borde);
            color: var(--color-exito-texto);
        }
        .aviso--error {
            background-color: var(--color-error-fondo);
            border: 1px solid var(--color-error-borde);
            color: var(--color-error-texto);
        }
        .aviso__cerrar {
            background: none;
            border: none;
            color: inherit;
            cursor: pointer;
            font-size: 1rem;
            padding-left: 0.5rem;
        }

        /* ── Componente Avatar ──────────────────────────────────── */
        .contenedor-avatar {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .avatar-preview {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #1e1e3f;
            box-shadow: 0 0 20px rgba(236, 72, 153, 0.15);
            transition: transform 0.3s ease;
        }
        .avatar-preview:hover { transform: scale(1.03); }

        .avatar-subida__etiqueta {
            font-size: 0.85rem;
            font-weight: 600;
            color: #3b82f6;
            cursor: pointer;
            transition: color 0.2s;
        }
        .avatar-subida__etiqueta:hover { color: #60a5fa; text-decoration: underline; }

        .avatar-subida__input {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0;
        }

        .badge-tipo {
            display: inline-block;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            background: var(--gradiente-neon);
            color: #fff;
            margin-bottom: 1rem;
        }

        .nick-usuario {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--color-texto);
        }

        /* ── Campos de Formulario ─────────────────────────────── */
        .campo {
            margin-bottom: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .campo__etiqueta {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--color-texto-suave);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .campo__entrada {
            width: 100%;
            background-color: rgba(3, 3, 10, 0.5);
            border: 1px solid var(--color-borde);
            border-radius: 8px;
            padding: 0.85rem 1rem;
            color: #fff;
            font-family: inherit;
            font-size: 0.95rem;
            transition: all 0.2s ease;
        }
        .campo__entrada:focus {
            outline: none;
            border-color: var(--color-borde-foco);
            box-shadow: 0 0 8px rgba(236, 72, 153, 0.15);
        }
        .campo__entrada:disabled {
            background-color: rgba(255, 255, 255, 0.02);
            color: rgba(255, 255, 255, 0.3);
            border-color: rgba(30, 30, 63, 0.4);
            cursor: not-allowed;
        }

        .textarea-perfil { resize: vertical; min-height: 120px; line-height: 1.5; }

        /* ── Bloque Integrantes ───────────────────────────────── */
        .bloque-miembros {
            border-top: 1px solid var(--color-borde);
            margin-top: 2rem;
            padding-top: 2rem;
        }

        .bloque-miembros__titulo {
            font-family: var(--fuente-titulo);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .lista-miembros {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }

        .item-miembro {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: rgba(255, 255, 255, 0.02);
            padding: 0.7rem 1rem;
            border: 1px solid var(--color-borde);
            border-radius: 8px;
            animation: fadeIn 0.25s ease;
        }

        .item-miembro__nombre {
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            padding-right: 0.5rem;
        }

        .item-miembro__eliminar {
            background: none;
            border: none;
            color: #ef4444;
            cursor: pointer;
            font-weight: 500;
            font-size: 0.8rem;
        }

        .control-agregar-miembro { display: flex; gap: 0.75rem; }

        /* ── Botón de Enviar ──────────────────────────────────── */
        .boton-entrar {
            background: var(--gradiente-neon);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 0.9rem 2rem;
            font-family: inherit;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s, transform 0.2s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .boton-entrar:hover { opacity: 0.9; transform: translateY(-1px); }

        /* ── Pie de Página (Footer Completo) ──────────────────── */
        .pie-pagina {
            padding: 1.25rem 2rem;
            background-color: rgba(3, 3, 10, 0.9);
            border-top: 1px solid rgba(30, 30, 63, 0.3);
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            gap: 0.75rem 2rem;
            margin-top: auto;
        }

        .pie-pagina__navegacion {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            list-style: none;
            flex-wrap: wrap;
        }

        .pie-pagina__enlace {
            color: var(--color-texto-suave);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        .pie-pagina__enlace:hover { color: #fff; }

        .pie-pagina__copiar {
            font-size: 0.73rem;
            color: var(--color-marcador);
            width: 100%;
            text-align: center;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(4px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ── Responsividad ───────────────────────────────────── */
        @media (max-width: 820px) {
            .contenedor-principal { grid-template-columns: 1fr; }
            .cabecera__menu-btn { display: flex; align-items: center; justify-content: center; }

            .navegacion-lateral {
                position: fixed;
                top: 0; left: 0; bottom: 0;
                width: var(--ancho-sidebar);
                height: 100dvh;
                z-index: 300;
                transform: translateX(-100%);
                transition: transform 0.28s ease;
                background-color: rgba(5, 5, 18, 0.97);
                backdrop-filter: blur(20px);
                padding-top: calc(var(--alto-cabecera) + 1rem);
            }
            .navegacion-lateral.abierto { transform: translateX(0); }
            .contenedor-panel-perfil { grid-template-columns: 1fr; }
            .tarjeta-identidad { position: relative; top: 0; padding: 1.5rem; }
        }

        @media (max-width: 480px) {
            .cabecera__perfil span:not(.cabecera__avatar) { display: none; }
        }
    </style>
</head>
<body>

    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <header class="cabecera">
        <button class="cabecera__menu-btn" id="btn-menu" aria-expanded="false" aria-controls="sidebar-nav" aria-label="Abrir menú de navegación">
            <svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect y="3"  width="20" height="2" rx="1" fill="currentColor"/>
                <rect y="9"  width="20" height="2" rx="1" fill="currentColor"/>
                <rect y="15" width="20" height="2" rx="1" fill="currentColor"/>
            </svg>
        </button>

        <a href="/inicio" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>

        <button class="cabecera__perfil" aria-haspopup="true" aria-label="Menú de usuario: <?= $nombre_usuario ?>">
            <span aria-hidden="true"><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img class="cabecera__avatar-imagen" src="<?= $avatar_cabecera ?>" alt="Foto de perfil de <?= $nombre_usuario ?>">
            </span>
        </button>
    </header>

    <div class="contenedor-principal">

        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
            <ul class="navegacion-lateral__lista">
                <li>
                    <a class="navegacion-lateral__enlace" href="/inicio">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/eventos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/favoritos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
                        </svg>
                        Favoritos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/usuarios">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/perfil" aria-current="page">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/logout" onclick="return confirm('¿Seguro que quieres cerrar sesión?')">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
                        </svg>
                        Cerrar sesión
                    </a>
                </li>
            </ul>
        </nav>

        <main id="contenido-principal" class="principal">
            <div class="contenedor-panel-perfil">
                
                <aside class="tarjeta-identidad">
                    <div class="contenedor-avatar">
                        <img src="<?= $avatar_cabecera ?>" alt="Vista previa del avatar" class="avatar-preview" id="avatar-img-preview">
                        <label class="avatar-subida__etiqueta" for="foto_perfil">Cambiar foto de perfil</label>
                    </div>
                    <span class="badge-tipo"><?= htmlspecialchars($perfil['tipo_usuario_nombre'], ENT_QUOTES, 'UTF-8'); ?></span>
                    <p class="nick-usuario">@<?= htmlspecialchars($perfil['nombre_app'], ENT_QUOTES, 'UTF-8'); ?></p>
                </aside>

                <section class="seccion-perfil" aria-labelledby="titulo-perfil">
                    <h1 id="titulo-perfil" class="seccion-perfil__titulo">Configuración del Perfil</h1>
                    <p class="seccion-perfil__subtitulo">Gestiona la información que se mostrará públicamente en la comunidad.</p>

                    <?php if (isset($_GET['status']) && $_GET['status'] === 'ok'): ?>
                        <div class="aviso aviso--exito" role="alert">
                            <span>¡Tu perfil se ha actualizado correctamente!</span>
                            <button type="button" class="aviso__cerrar" aria-label="Cerrar" onclick="this.parentElement.remove()">✕</button>
                        </div>
                    <?php elseif (isset($_GET['status']) && strpos($_GET['status'], 'error') !== false): ?>
                        <div class="aviso aviso--error" role="alert">
                            <span>Error al procesar la imagen. Asegúrate de subir un formato válido (JPG, PNG, WEBP).</span>
                            <button type="button" class="aviso__cerrar" aria-label="Cerrar" onclick="this.parentElement.remove()">✕</button>
                        </div>
                    <?php endif; ?>

                    <form action="/perfil/guardar" method="POST" enctype="multipart/form-data">
                        
                        <input type="file" id="foto_perfil" name="foto_perfil" class="avatar-subida__input" accept="image/png, image/jpeg, image/jpg, image/webp" onchange="previsualizarImagen(this)">

                        <div class="campo">
                            <label class="campo__etiqueta">Nombre completo / Agrupación</label>
                            <input class="campo__entrada" type="text" value="<?= htmlspecialchars($perfil['nombre_real'] ?? $perfil['nombre_app'], ENT_QUOTES, 'UTF-8'); ?>" disabled>
                        </div>

                        <div class="campo">
                            <label class="campo__etiqueta" for="descripcion">Biografía o Descripción</label>
                            <textarea class="campo__entrada textarea-perfil" id="descripcion" name="descripcion" placeholder="Cuéntale a la comunidad sobre tu trayectoria..."><?= htmlspecialchars($perfil['descripcion'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>

                        <?php if ($perfil['tipo_usuario_nombre'] === 'grupo' || $perfil['id_tipo_usuario'] == 2): ?>
                            <div class="bloque-miembros">
                                <h2 class="bloque-miembros__titulo">Integrantes del Grupo</h2>
                                
                                <div class="lista-miembros" id="contenedor-miembros" role="list">
                                    <?php foreach ($miembros as $index => $miembro): ?>
                                        <div class="item-miembro" id="miembro_<?php echo $index; ?>" role="listitem">
                                            <span class="item-miembro__nombre" title="<?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8'); ?>">
                                                <?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8'); ?>
                                            </span>
                                            <input type="hidden" name="miembros_nombres[]" value="<?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8'); ?>">
                                            <button type="button" class="item-miembro__eliminar" aria-label="Eliminar miembro" onclick="eliminarMiembro('miembro_<?php echo $index; ?>')">Eliminar</button>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <div class="campo">
                                    <label class="campo__etiqueta" for="nuevo_miembro_input">Agregar nuevo integrante</label>
                                    <div class="control-agregar-miembro">
                                        <input class="campo__entrada" type="text" id="nuevo_miembro_input" placeholder="Ej: Rocío Méndez (Bailarina)">
                                        <button type="button" class="boton-entrar" style="padding: 0 1.5rem;" onclick="agregarMiembro()">Añadir</button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div style="display: flex; justify-content: flex-end; margin-top: 2.5rem;">
                            <button class="boton-entrar" type="submit">Guardar todos los cambios</button>
                        </div>

                    </form>
                </section>
            </div>
        </main>
    </div>

    <footer class="pie-pagina">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/politicas">Políticas de Privacidad</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">&copy; <?= date('Y') ?> All Dance Together. Todos los derechos reservados.</p>
    </footer>

    <script>
        // Lógica del Menu Mobile (Sidebar Hamburguesa)
        const btnMenu = document.getElementById('btn-menu');
        const sidebarNav = document.getElementById('sidebar-nav');
        const overlaySidebar = document.getElementById('overlay-sidebar');

        if(btnMenu && sidebarNav && overlaySidebar) {
            btnMenu.addEventListener('click', () => {
                const esAbierto = sidebarNav.classList.toggle('abierto');
                overlaySidebar.classList.toggle('activo');
                btnMenu.setAttribute('aria-expanded', esAbierto);
            });

            overlaySidebar.addEventListener('click', () => {
                sidebarNav.classList.remove('abierto');
                overlaySidebar.classList.remove('activo');
                btnMenu.setAttribute('aria-expanded', 'false');
            });
        }

        // Previsualización de Avatar
        function previsualizarImagen(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatar-img-preview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Manipulación dinámica de miembros del DOM
        let contadorMiembros = <?php echo count($miembros); ?>;

        function agregarMiembro() {
            const input = document.getElementById('nuevo_miembro_input');
            const nombre = input.value.trim();
            if (nombre === "") return;

            const contenedor = document.getElementById('contenedor-miembros');
            const nuevoId = 'miembro_nuevo_' + contadorMiembros++;

            const div = document.createElement('div');
            div.className = 'item-miembro';
            div.id = nuevoId;
            div.setAttribute('role', 'listitem');

            div.innerHTML = `
                <span class="item-miembro__nombre" title="${escapeHTML(nombre)}">${escapeHTML(nombre)}</span>
                <input type="hidden" name="miembros_nombres[]" value="${escapeHTML(nombre)}">
                <button type="button" class="item-miembro__eliminar" onclick="eliminarMiembro('${nuevoId}')">Eliminar</button>
            `;

            contenedor.appendChild(div);
            input.value = "";
            input.focus();
        }

        function eliminarMiembro(idElemento) {
            const elemento = document.getElementById(idElemento);
            if (elemento) elemento.remove();
        }

        function escapeHTML(str) {
            return str.replace(/[&<>'"]/g, tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag));
        }
    </script>
</body>
</html>