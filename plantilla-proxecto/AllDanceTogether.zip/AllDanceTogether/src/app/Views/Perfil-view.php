<?php
/**
 * Vista de Panel de Gestión de Perfil Privado.
 * * Renderiza la interfaz de administración de cuenta del usuario autenticado,
 * permitiendo la actualización de datos personales, carga de avatar, control de listado de miembros (grupos),
 * configuración de preferencias de colaboración, cambio seguro de contraseña y baja del servicio.
 */

$nombre_usuario  = htmlspecialchars($_SESSION['usuario']['nick'] ?? 'Usuario');
// foto_url ya viene normalizada desde el modelo (sin /public)
$avatar_cabecera = !empty($perfil['foto_url'])
    ? htmlspecialchars($perfil['foto_url'], ENT_QUOTES, 'UTF-8')
    : '/uploads/avatars/default-avatar.png';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Mi Perfil — All Dance Together</title>
    <meta name="description" content="Gestiona tu información pública de perfil en All Dance Together.">
    <link rel="stylesheet" href="/css/Perfil.css">
    <link rel="stylesheet" href="/css/Global.css">
</head>
<body>

    <h1 class="sr-only">Mi perfil — All Dance Together</h1>

    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <?php include_once(__DIR__ . '/partials/header.php'); ?>

    <div class="contenedor-principal">

        <?php include_once(__DIR__ . '/partials/menu.php'); ?>

        <main id="contenido-principal" class="principal">

            <!-- Cabecera de sección -->
            <section aria-labelledby="titulo-perfil-bienvenida">
                <div class="bienvenida">
                    <h2 id="titulo-perfil-bienvenida" class="bienvenida__titulo">
                        Perfil de<span><?= $nombre_usuario ?></span>
                    </h2>
                    <p class="bienvenida__subtitulo">Gestiona la información que se mostrará públicamente en la comunidad.</p>
                </div>
            </section>

            <!-- Avisos de estado -->
            <?php if (isset($_GET['status'])): ?>
                <?php
                $status = $_GET['status'];
                $mensajes_exito = ['ok' => '¡Tu perfil se ha actualizado correctamente!', 'ok_password' => '¡Contraseña actualizada correctamente!'];
                $mensajes_error = [
                    'error_subida'              => 'No se pudo guardar la imagen. Inténtalo de nuevo.',
                    'error_extension'           => 'Formato no válido. Sube una imagen JPG, PNG o WEBP.',
                    'error_tamano'              => 'La imagen supera el tamaño máximo permitido (5 MB).',
                    'error_csrf'                => 'La sesión ha expirado. Recarga la página e inténtalo de nuevo.',
                    'error_password_vacio'      => 'Completa todos los campos de contraseña.',
                    'error_password_corta'      => 'La nueva contraseña debe tener al menos 8 caracteres.',
                    'error_password_no_coincide'=> 'Las contraseñas no coinciden.',
                    'error_password_incorrecta' => 'La contraseña actual no es correcta.',
                    'error_eliminar_vacio'      => 'Introduce tu contraseña para confirmar la eliminación.',
                    'error_eliminar_incorrecta' => 'La contraseña no es correcta. La cuenta no ha sido eliminada.',
                    'error_eliminar_fallo'      => 'No se pudo eliminar la cuenta. Inténtalo de nuevo más tarde.',
                ];
                ?>
                <?php if (isset($mensajes_exito[$status])): ?>
                    <div class="aviso aviso--exito" role="alert">
                        <span><?= htmlspecialchars($mensajes_exito[$status], ENT_QUOTES, 'UTF-8') ?></span>
                        <button type="button" class="aviso__cerrar" aria-label="Cerrar aviso" onclick="this.parentElement.remove()">✕</button>
                    </div>
                <?php elseif (isset($mensajes_error[$status])): ?>
                    <div class="aviso aviso--error" role="alert">
                        <span><?= htmlspecialchars($mensajes_error[$status], ENT_QUOTES, 'UTF-8') ?></span>
                        <button type="button" class="aviso__cerrar" aria-label="Cerrar aviso" onclick="this.parentElement.remove()">✕</button>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="contenedor-panel-perfil">

                <!-- Tarjeta de identidad lateral -->
                <aside class="tarjeta-identidad" aria-label="Identidad de usuario">
                    <div class="contenedor-avatar">
                        <img src="<?= $avatar_cabecera ?>" alt="Foto de perfil de <?= $nombre_usuario ?>" class="avatar-preview" id="avatar-img-preview">
                        <label class="avatar-subida__etiqueta" for="foto_perfil">Cambiar foto</label>
                    </div>
                    <span class="badge-tipo"><?= htmlspecialchars($perfil['tipo_usuario_nombre'], ENT_QUOTES, 'UTF-8') ?></span>
                    <p class="nick-usuario">@<?= htmlspecialchars($perfil['nombre_app'], ENT_QUOTES, 'UTF-8') ?></p>
                </aside>

                <!-- Panel principal de formularios -->
                <div class="panel-formularios">

                    <!-- ==============================
                         SECCIÓN 1: DATOS DEL PERFIL
                    ============================== -->
                    <section class="seccion-perfil" aria-labelledby="titulo-datos-perfil">
                        <h2 id="titulo-datos-perfil" class="seccion-perfil__titulo">Datos del perfil</h2>

                        <form action="/perfil/guardar" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

                            <input type="file" id="foto_perfil" name="foto_perfil" class="avatar-subida__input"
                                   accept="image/png, image/jpeg, image/jpg, image/webp"
                                   onchange="previsualizarImagen(this)">

                            <div class="campo">
                                <!-- label asociado mediante for aunque el input esté deshabilitado -->
                                <label class="campo__etiqueta" for="nombre-completo">Nombre completo / Agrupación</label>
                                <input class="campo__entrada" type="text"
                                       id="nombre-completo"
                                       value="<?= htmlspecialchars($perfil['nombre_real'] ?? $perfil['nombre_app'], ENT_QUOTES, 'UTF-8') ?>"
                                       disabled aria-disabled="true">
                            </div>

                            <div class="campo">
                                <label class="campo__etiqueta" for="descripcion">Biografía o descripción</label>
                                <textarea class="campo__entrada textarea-perfil" id="descripcion" name="descripcion"
                                          placeholder="Cuéntale a la comunidad sobre tu trayectoria..."><?= htmlspecialchars($perfil['descripcion'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                            </div>

                            <?php if ($perfil['tipo_usuario_nombre'] === 'grupo' || $perfil['id_tipo_usuario'] == 2): ?>
                                <div class="bloque-miembros">
                                    <h3 class="bloque-miembros__titulo">Integrantes del grupo</h3>

                                    <div class="lista-miembros" id="contenedor-miembros" role="list">
                                        <?php foreach ($miembros as $index => $miembro): ?>
                                            <div class="item-miembro" id="miembro_<?= $index ?>" role="listitem">
                                                <span class="item-miembro__nombre" title="<?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8') ?>
                                                </span>
                                                <input type="hidden" name="miembros_nombres[]" value="<?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8') ?>">
                                                <button type="button" class="item-miembro__eliminar"
                                                        aria-label="Eliminar miembro <?= htmlspecialchars($miembro['nombre'], ENT_QUOTES, 'UTF-8') ?>"
                                                        onclick="eliminarMiembro('miembro_<?= $index ?>')">Eliminar</button>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>

                                    <div class="campo">
                                        <label class="campo__etiqueta" for="nuevo_miembro_input">Agregar nuevo integrante</label>
                                        <div class="control-agregar-miembro">
                                            <input class="campo__entrada" type="text" id="nuevo_miembro_input"
                                                   placeholder="Ej: Rocío Méndez (Bailarina)">
                                            <button type="button" class="boton-entrar" onclick="agregarMiembro()">Añadir</button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="acciones-formulario">
                                <button class="boton-entrar" type="submit">Guardar cambios</button>
                            </div>
                        </form>
                    </section>

                    <!-- ==============================
                         SECCIÓN 2: COLABORACIONES
                    ============================== -->
                    <section class="seccion-perfil" aria-labelledby="titulo-colaboraciones">
                        <h2 id="titulo-colaboraciones" class="seccion-perfil__titulo">Colaboraciones y búsquedas</h2>
                        <p class="seccion-perfil__subtitulo">Indica a la comunidad qué tipo de colaboración buscas o aceptas.</p>

                        <form action="/perfil/colaboraciones" method="POST">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

                            <div class="campo campo--radio-group">
                                <fieldset class="radio-grupo">
                                    <legend class="campo__etiqueta">¿Aceptas colaboraciones?</legend>
                                    <div class="radio-opciones">
                                        <label class="radio-opcion <?= ($perfil['datos_extra']['acepta_colaboraciones'] ?? null) === true ? 'radio-opcion--activa' : '' ?>">
                                            <input type="radio" name="acepta_colaboraciones" value="1"
                                                <?= ($perfil['datos_extra']['acepta_colaboraciones'] ?? null) === true ? 'checked' : '' ?>>
                                            <span class="radio-opcion__icono" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <polyline points="20 6 9 17 4 12"/>
                                                </svg>
                                            </span>
                                            Sí
                                        </label>
                                        <label class="radio-opcion <?= ($perfil['datos_extra']['acepta_colaboraciones'] ?? null) === false ? 'radio-opcion--activa' : '' ?>">
                                            <input type="radio" name="acepta_colaboraciones" value="0"
                                                <?= ($perfil['datos_extra']['acepta_colaboraciones'] ?? null) === false ? 'checked' : '' ?>>
                                            <span class="radio-opcion__icono" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                                                </svg>
                                            </span>
                                            No
                                        </label>
                                    </div>
                                </fieldset>
                            </div>

                            <div class="campo campo--radio-group">
                                <fieldset class="radio-grupo">
                                    <legend class="campo__etiqueta">¿Buscas integrantes?</legend>
                                    <div class="radio-opciones">
                                        <label class="radio-opcion <?= ($perfil['datos_extra']['busca_integrantes'] ?? null) === true ? 'radio-opcion--activa' : '' ?>">
                                            <input type="radio" name="busca_integrantes" value="1"
                                                <?= ($perfil['datos_extra']['busca_integrantes'] ?? null) === true ? 'checked' : '' ?>>
                                            <span class="radio-opcion__icono" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <polyline points="20 6 9 17 4 12"/>
                                                </svg>
                                            </span>
                                            Sí
                                        </label>
                                        <label class="radio-opcion <?= ($perfil['datos_extra']['busca_integrantes'] ?? null) === false ? 'radio-opcion--activa' : '' ?>">
                                            <input type="radio" name="busca_integrantes" value="0"
                                                <?= ($perfil['datos_extra']['busca_integrantes'] ?? null) === false ? 'checked' : '' ?>>
                                            <span class="radio-opcion__icono" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                                                </svg>
                                            </span>
                                            No
                                        </label>
                                    </div>
                                </fieldset>
                            </div>

                            <div class="campo campo--radio-group">
                                <fieldset class="radio-grupo">
                                    <legend class="campo__etiqueta">¿Buscas staff?</legend>
                                    <div class="radio-opciones">
                                        <label class="radio-opcion <?= ($perfil['datos_extra']['busca_staff'] ?? null) === true ? 'radio-opcion--activa' : '' ?>">
                                            <input type="radio" name="busca_staff" value="1"
                                                <?= ($perfil['datos_extra']['busca_staff'] ?? null) === true ? 'checked' : '' ?>>
                                            <span class="radio-opcion__icono" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <polyline points="20 6 9 17 4 12"/>
                                                </svg>
                                            </span>
                                            Sí
                                        </label>
                                        <label class="radio-opcion <?= ($perfil['datos_extra']['busca_staff'] ?? null) === false ? 'radio-opcion--activa' : '' ?>">
                                            <input type="radio" name="busca_staff" value="0"
                                                <?= ($perfil['datos_extra']['busca_staff'] ?? null) === false ? 'checked' : '' ?>>
                                            <span class="radio-opcion__icono" aria-hidden="true">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                                                </svg>
                                            </span>
                                            No
                                        </label>
                                    </div>
                                </fieldset>
                            </div>

                            <div class="acciones-formulario">
                                <button class="boton-entrar" type="submit">Guardar preferencias</button>
                            </div>
                        </form>
                    </section>

                    <!-- ==============================
                         SECCIÓN 3: CAMBIAR CONTRASEÑA
                    ============================== -->
                    <section class="seccion-perfil" aria-labelledby="titulo-contrasena">
                        <h2 id="titulo-contrasena" class="seccion-perfil__titulo">Cambiar contraseña</h2>
                        <p class="seccion-perfil__subtitulo">Por seguridad, introduce tu contraseña actual antes de establecer una nueva.</p>

                        <form action="/perfil/cambiar-contrasena" method="POST" id="form-contrasena" novalidate>
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

                            <div class="campo">
                                <label class="campo__etiqueta" for="contrasena_actual">Contraseña actual</label>
                                <div class="campo-password">
                                    <input class="campo__entrada" type="password" id="contrasena_actual"
                                           name="contrasena_actual" autocomplete="current-password" required>
                                    <button type="button" class="btn-ver-password" aria-label="Mostrar u ocultar contraseña actual"
                                            onclick="togglePassword('contrasena_actual', this)">
                                        <svg class="icono-ojo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <div class="campo">
                                <label class="campo__etiqueta" for="contrasena_nueva">Nueva contraseña</label>
                                <div class="campo-password">
                                    <input class="campo__entrada" type="password" id="contrasena_nueva"
                                           name="contrasena_nueva" autocomplete="new-password" required
                                           aria-describedby="hint-contrasena">
                                    <button type="button" class="btn-ver-password" aria-label="Mostrar u ocultar nueva contraseña"
                                            onclick="togglePassword('contrasena_nueva', this)">
                                        <svg class="icono-ojo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </button>
                                </div>
                                <p class="campo__ayuda" id="hint-contrasena">Mínimo 8 caracteres.</p>
                            </div>

                            <div class="campo">
                                <label class="campo__etiqueta" for="contrasena_confirmar">Confirmar nueva contraseña</label>
                                <div class="campo-password">
                                    <input class="campo__entrada" type="password" id="contrasena_confirmar"
                                           name="contrasena_confirmar" autocomplete="new-password" required>
                                    <button type="button" class="btn-ver-password" aria-label="Mostrar u ocultar confirmación de contraseña"
                                            onclick="togglePassword('contrasena_confirmar', this)">
                                        <svg class="icono-ojo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </button>
                                </div>
                                <p class="campo__error" id="error-contrasena" role="alert" aria-live="polite" hidden></p>
                            </div>

                            <div class="acciones-formulario">
                                <button class="boton-entrar" type="submit">Actualizar contraseña</button>
                            </div>
                        </form>
                    </section>

                    <!-- ==============================
                         SECCIÓN 4: ELIMINAR CUENTA
                    ============================== -->
                    <section class="seccion-perfil seccion-perfil--peligro" aria-labelledby="titulo-eliminar-cuenta">
                        <h2 id="titulo-eliminar-cuenta" class="seccion-perfil__titulo seccion-perfil__titulo--peligro">Eliminar cuenta</h2>
                        <p class="seccion-perfil__subtitulo">
                            Esta acción es <strong>permanente e irreversible</strong>. Se eliminarán tu perfil,
                            todas tus publicaciones y todos tus comentarios. No hay forma de recuperarlos.
                        </p>

                        <form action="/perfil/eliminar-cuenta" method="POST" id="form-eliminar-cuenta"
                              onsubmit="return confirm('¿Estás completamente seguro? Esta acción no se puede deshacer y perderás todos tus datos.')">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

                            <div class="campo">
                                <label class="campo__etiqueta" for="contrasena_eliminar">Confirma tu contraseña para continuar</label>
                                <div class="campo-password">
                                    <input class="campo__entrada" type="password" id="contrasena_eliminar"
                                           name="contrasena_eliminar" autocomplete="current-password" required>
                                    <button type="button" class="btn-ver-password" aria-label="Mostrar u ocultar contraseña"
                                            onclick="togglePassword('contrasena_eliminar', this)">
                                        <svg class="icono-ojo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <div class="acciones-formulario">
                                <button class="boton-peligro" type="submit">Eliminar mi cuenta definitivamente</button>
                            </div>
                        </form>
                    </section>

                </div><!-- /panel-formularios -->
            </div><!-- /contenedor-panel-perfil -->

        </main>
    </div>

    <?php include_once(__DIR__ . '/partials/footer.php'); ?>

    <script src="/js/Perfil.js"></script>
</body>
</html>