<?php
/**
 * Header de las páginas después de logearse
 */
require_once __DIR__ . '/../../../core/Helper.php';

$nick_cabecera    = htmlspecialchars($_SESSION['usuario']['nick']   ?? '', ENT_QUOTES, 'UTF-8');
$nombre_cabecera  = htmlspecialchars($_SESSION['usuario']['nombre'] ?? '', ENT_QUOTES, 'UTF-8');
$inicial_cabecera = htmlspecialchars(mb_strtoupper(mb_substr($_SESSION['usuario']['nick'] ?? '?', 0, 1, 'UTF-8'), 'UTF-8'));

$foto_cruda       = $_SESSION['usuario']['foto_url'] ?? '';
$foto_normalizada = !empty($foto_cruda)
    ? (strpos($foto_cruda, '/public') === 0 ? substr($foto_cruda, 7) : $foto_cruda)
    : '';

$tiene_avatar_cabecera = tieneFotoValida($foto_normalizada);
?>
<header class="cabecera" role="banner">
    <button class="cabecera__menu-btn"
            id="btn-menu"
            aria-expanded="false"
            aria-controls="sidebar-nav"
            aria-label="Abrir menú de navegación">
        <svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect y="3"  width="20" height="2" rx="1" fill="currentColor"/>
            <rect y="9"  width="20" height="2" rx="1" fill="currentColor"/>
            <rect y="15" width="20" height="2" rx="1" fill="currentColor"/>
        </svg>
    </button>

    <a href="/inicio" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
        <span class="cabecera__nombre">All Dance Together</span>
    </a>

    <button class="cabecera__perfil"
            aria-haspopup="true"
            aria-label="Menú de usuario: <?= $nombre_cabecera ?>">
        <span aria-hidden="true"><?= $nick_cabecera ?></span>
        <span class="cabecera__avatar <?= $tiene_avatar_cabecera ? 'cabecera__avatar--borde' : '' ?>">
            <?php if ($tiene_avatar_cabecera): ?>
                <img class="cabecera__avatar-imagen"
                     src="<?= htmlspecialchars($foto_normalizada, ENT_QUOTES, 'UTF-8') ?>"
                     alt="<?= $inicial_cabecera ?>">
            <?php else: ?>
                <div style="width:36px;height:36px;border-radius:50%;background:#e91e8c;font-weight:700;font-size:1rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <?= $inicial_cabecera ?>
                </div>
            <?php endif; ?>
        </span>
    </button>
</header>