<!-- Header de las páginas Login y Registro -->
    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir a la página de inicio de All Dance Together">
            <p class="cabecera__nombre">All Dance Together</p>
        </a>
    </header>