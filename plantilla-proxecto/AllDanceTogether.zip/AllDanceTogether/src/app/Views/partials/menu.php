<?php
/**
 * Renderizado del menú 
 */
// para marcar la opción de menú en la que se encuentra el usuario
$enlaces = [
    'inicio'    => [
        'href'  => '/inicio',
        'label' => 'Inicio',
        'icono' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9.75L12 3l9 6.75V21a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9.75z"/><path d="M9 22V12h6v10"/></svg>',
    ],
    'descubrir' => [
        'href'  => '/descubrir',
        'label' => 'Descubrir',
        'icono' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
    ],
    'eventos'   => [
        'href'  => '/eventos',
        'label' => 'Próximos eventos',
        'icono' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
    ],
    'usuarios'  => [
        'href'  => '/usuarios',
        'label' => 'Usuarios',
        'icono' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><path d="M16 3.13a4 4 0 0 1 0 7.75M21 21v-2a4 4 0 0 0-3-3.87"/></svg>',
    ],
    'perfil'    => [
        'href'  => '/perfil',
        'label' => 'Mi perfil',
        'icono' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>',
    ],
    'logout'    => [
        'href'  => '/logout',
        'label' => 'Cerrar sesión',
        'icono' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    ],
];
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
    <ul class="navegacion-lateral__lista">
        <?php foreach ($enlaces as $clave => $enlace): ?>
            <?php $activo = ($_SESSION['pagina_actual'] === $clave); ?>
            <li>
                <a class="navegacion-lateral__enlace <?= $activo ? 'navegacion-lateral__enlace--activo' : '' ?>"
                   href="<?= $enlace['href'] ?>"
                   <?= $activo ? 'aria-current="page"' : '' ?>>
                    <?= $enlace['icono'] ?>
                    <?= $enlace['label'] ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</nav>