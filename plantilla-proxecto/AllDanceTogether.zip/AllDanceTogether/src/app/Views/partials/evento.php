<?php
/**
 * Componente / Helper de Tarjeta de Evento.
 * * Renderiza el bloque HTML de un evento formateando su fecha al español,
 * controlando la existencia de imágenes con fallback e inyectando los datos de forma segura.
 */
function renderCardEvento(array $evento): void
{
    $tiene_foto = tieneFotoValida($evento['foto_url'] ?? '');

    $fecha_formateada = '';
    $fecha_hora       = '';
    if (!empty($evento['fecha'])) {
        $dt = new DateTime($evento['fecha']);

        $dias_es  = ['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
        $meses_es = ['enero','febrero','marzo','abril','mayo','junio',
                     'julio','agosto','septiembre','octubre','noviembre','diciembre'];

        $fecha_formateada = $dias_es[(int)$dt->format('w')] . ', ' .
                            (int)$dt->format('j') . ' de ' .
                            $meses_es[(int)$dt->format('n') - 1] . ' de ' .
                            $dt->format('Y');
        $fecha_hora = $dt->format('H:i');
    }

    $titulo_escapado      = htmlspecialchars($evento['titulo']      ?? '', ENT_QUOTES, 'UTF-8');
    $lugar_escapado       = htmlspecialchars($evento['lugar']       ?? '', ENT_QUOTES, 'UTF-8');
    $fecha_escapada       = htmlspecialchars($evento['fecha']       ?? '', ENT_QUOTES, 'UTF-8');
    $descripcion_truncada = mb_strimwidth(htmlspecialchars($evento['descripcion'] ?? '', ENT_QUOTES, 'UTF-8'), 0, 130, '…');
    $evento_id            = (int)($evento['id'] ?? 0);
    $inicial              = htmlspecialchars(mb_strtoupper(mb_substr($evento['titulo'] ?? '?', 0, 1, 'UTF-8'), 'UTF-8'));
    ?>
    <article class="card-evento" aria-label="Evento: <?= $titulo_escapado ?>">
        <div class="card-evento__imagen-wrapper">
            <?php if ($tiene_foto): ?>
                <img class="card-evento__img"
                     src="<?= htmlspecialchars($evento['foto_url'], ENT_QUOTES, 'UTF-8') ?>"
                     alt="Imagen del evento: <?= $titulo_escapado ?>"
                     loading="lazy" width="220" height="160">
            <?php else: ?>
                <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,rgba(123,94,248,0.2) 0%,rgba(236,72,153,0.15) 100%);font-size:3rem;font-weight:700;color:rgba(255,255,255,0.6);" aria-hidden="true">
                    <?= $inicial ?>
                </div>
            <?php endif; ?>
            <span class="badge-tipo-item badge-tipo-item--evento" aria-hidden="true">Evento</span>
        </div>

        <div class="card-evento__contenido">
            <h4 class="card-evento__titulo"><?= $titulo_escapado ?></h4>

            <?php if ($fecha_formateada): ?>
                <p class="card-evento__fecha">
                    <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M19 4h-1V2h-2v2H8V2H6v2H5C3.9 4 3 4.9 3 6v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11zM7 11h5v5H7z"/>
                    </svg>
                    <time datetime="<?= $fecha_escapada ?>">
                        <?= ucfirst($fecha_formateada) ?>
                        <?php if ($fecha_hora !== '00:00'): ?>
                            &nbsp;·&nbsp;<?= $fecha_hora ?>h
                        <?php endif; ?>
                    </time>
                </p>
            <?php endif; ?>

            <?php if (!empty($evento['lugar'])): ?>
                <p class="card-evento__lugar">
                    <svg class="svg-icon svg-icon--rosa" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                    </svg>
                    <?= $lugar_escapado ?>
                </p>
            <?php endif; ?>

            <p class="card-evento__descripcion"><?= $descripcion_truncada ?></p>

            <div class="card-evento__footer">
                <a href="/descubrir/ver?id=<?= $evento_id ?>"
                   class="card-descubrir__link"
                   aria-label="Ver detalles de <?= $titulo_escapado ?>">
                    Ver detalles →
                </a>
            </div>
        </div>
    </article>
    <?php
}