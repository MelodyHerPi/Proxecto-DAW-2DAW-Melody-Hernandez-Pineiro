<!-- Footer para las páginas login y registro -->
    <footer class="pie-pagina">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/politicas">Políticas de Privacidad</a></li>
            </ul>
        </nav>
    </footer>