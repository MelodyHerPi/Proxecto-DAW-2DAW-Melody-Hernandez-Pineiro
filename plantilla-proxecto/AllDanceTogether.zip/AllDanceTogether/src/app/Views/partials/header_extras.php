   <!-- header de las páginas extras de Ayuda, Términos,... -->
   <header class="cabecera" role="banner">
        <a href="/login" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <a href="javascript:history.back()" class="cabecera__volver" aria-label="Volver a la página anterior">
            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"/>
            </svg>
            Volver
        </a>
    </header>