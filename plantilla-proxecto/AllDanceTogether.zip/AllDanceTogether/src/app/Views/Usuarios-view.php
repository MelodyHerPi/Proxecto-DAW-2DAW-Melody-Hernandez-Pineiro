<?php
/**
 * Vista del Directorio de la Comunidad (Usuarios y Grupos).
 * * Renderiza la interfaz de búsqueda, filtrado y exploración de la comunidad de artistas,
 * desplegando una cuadrícula de perfiles (solistas/agrupaciones) y gestionando una ventana
 * modal accesible para inspeccionar en detalle las biografías y estados de colaboración.
 */
    $busqueda_texto   = $busqueda_texto   ?? '';
    $filtro_tipo      = $filtro_tipo      ?? 'todos';
    $listado_usuarios = $listado_usuarios ?? [];
    $total_resultados = $total_resultados ?? 0;

    $hay_busqueda = $busqueda_texto !== '' || $filtro_tipo !== 'todos';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Usuarios y Grupos — All Dance Together</title>
    <meta name="description" content="Busca y filtra usuarios solistas y grupos de baile en All Dance Together.">
    <link rel="stylesheet" href="/css/Usuarios.css">
    <link rel="stylesheet" href="/css/Global.css">
</head>
<body>

    <h1 class="sr-only">All Dance Together</h1>
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <?php include_once(__DIR__ . '/partials/header.php'); ?>

    <div class="contenedor-principal">

        <?php include_once(__DIR__ . '/partials/menu.php'); ?>

        <main id="contenido-principal" class="principal">

            <?php if (!empty($error_bd)): ?>
                <div class="alerta alerta--error" role="alert">
                    <?= htmlspecialchars($error_bd, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <section class="encabezado-seccion" aria-labelledby="titulo-pagina">
                <div>
                    <h2 id="titulo-pagina" class="encabezado-seccion__titulo">Comunidad de Artistas</h2>
                    <p class="encabezado-seccion__subtitulo">Encuentra, filtra e interactúa con otros usuarios solistas y agrupaciones de la plataforma.</p>
                </div>
            </section>

            <form action="/usuarios" method="GET" class="formulario-filtrado" role="search">
                <div class="formulario-filtrado__grupo">
                    <label for="buscar_texto" class="formulario-filtrado__etiqueta">Buscar por nombre o descripción</label>
                    <input type="search" id="buscar_texto" name="buscar"
                           class="formulario-filtrado__campo"
                           placeholder="Ej. ADT, Coco, Vigo..."
                           value="<?= htmlspecialchars($busqueda_texto, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="formulario-filtrado__grupo formulario-filtrado__grupo--corto">
                    <label for="filtrar_tipo" class="formulario-filtrado__etiqueta">Tipo de cuenta</label>
                    <select id="filtrar_tipo" name="tipo" class="formulario-filtrado__campo">
                        <option value="todos" <?= $filtro_tipo === 'todos' ? 'selected' : '' ?>>Todos</option>
                        <option value="1"     <?= $filtro_tipo === '1'     ? 'selected' : '' ?>>Usuarios Solistas</option>
                        <option value="2"     <?= $filtro_tipo === '2'     ? 'selected' : '' ?>>Grupos</option>
                    </select>
                </div>

                <div class="formulario-filtrado__acciones">
                    <button type="submit" class="formulario-filtrado__boton">Filtrar</button>
                    <button type="button" class="formulario-filtrado__boton formulario-filtrado__boton--borrar"
                            id="btn-limpiar-filtros" aria-label="Limpiar filtros de búsqueda">Limpiar</button>
                </div>
            </form>

            <?php if ($hay_busqueda): ?>
                <div class="oculto-visual" aria-live="polite" aria-atomic="true">
                    Se han encontrado <?= (int)$total_resultados ?> resultado<?= $total_resultados !== 1 ? 's' : '' ?> para tu búsqueda.
                </div>
            <?php endif; ?>

            <section class="seccion-eventos" aria-labelledby="titulo-listado">
                <h3 id="titulo-listado" class="seccion-eventos__titulo">
                    <span class="seccion-eventos__titulo-punto" aria-hidden="true"></span>
                    <?php if ($hay_busqueda): ?>
                        <?= (int)$total_resultados ?> resultado<?= $total_resultados !== 1 ? 's' : '' ?> encontrado<?= $total_resultados !== 1 ? 's' : '' ?>
                    <?php else: ?>
                        Todos los artistas
                    <?php endif; ?>
                </h3>

                <?php if ($total_resultados === 0): ?>
                    <div class="sin-resultados" role="status">
                        <p class="sin-resultados__titulo">No se encontraron resultados</p>
                        <p class="sin-resultados__descripcion">Prueba a modificar los filtros o a escribir palabras clave distintas.</p>
                    </div>
                <?php else: ?>
                    <div class="cuadrilla-usuarios" role="list">
                        <?php foreach ($listado_usuarios as $usuario):
                            $nombre_u     = htmlspecialchars($usuario['nombre_real'] ?? '', ENT_QUOTES, 'UTF-8');
                            $nombre_app_u = htmlspecialchars($usuario['nombre_app']  ?? '', ENT_QUOTES, 'UTF-8');
                            $tipo_legible = (strtolower($usuario['tipo_nombre'] ?? '') === 'grupo') ? 'Grupo' : 'Usuario solista';
                            $descripcion  = !empty($usuario['descripcion'])
                                ? htmlspecialchars($usuario['descripcion'], ENT_QUOTES, 'UTF-8')
                                : 'Este usuario aún no ha añadido una descripción a su perfil.';

                            $avatar_url_raw = $usuario['avatar_url'] ?? '';
                            $tiene_av_u     = tieneFotoValida($avatar_url_raw);
                            $avatar_u       = $tiene_av_u ? htmlspecialchars($avatar_url_raw, ENT_QUOTES, 'UTF-8') : '';
                            $inicial_u      = htmlspecialchars(mb_strtoupper(mb_substr($usuario['nombre_real'] ?? '?', 0, 1, 'UTF-8'), 'UTF-8'));

                            $datos_extra = json_decode($usuario['datos_extra'] ?? '{}', true) ?? [];

                            $data_popup = htmlspecialchars(json_encode([
                                'id'                    => (int)$usuario['id'],
                                'nombre'                => $usuario['nombre_real'] ?? '',
                                'nombre_app'            => $usuario['nombre_app']  ?? '',
                                'tipo'                  => $tipo_legible,
                                'descripcion'           => $usuario['descripcion'] ?? '',
                                'avatar'                => $tiene_av_u ? $avatar_url_raw : '',
                                'tiene_avatar'          => $tiene_av_u,
                                'inicial'               => mb_strtoupper(mb_substr($usuario['nombre_real'] ?? '?', 0, 1, 'UTF-8'), 'UTF-8'),
                                'busca_integrantes'     => $datos_extra['busca_integrantes']     ?? null,
                                'acepta_colaboraciones' => $datos_extra['acepta_colaboraciones'] ?? null,
                                'busca_staff'           => $datos_extra['busca_staff']           ?? null,
                            ], JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                        ?>
                            <section class="tarjeta-usuario"
                                     role="listitem"
                                     tabindex="0"
                                     data-perfil="<?= $data_popup ?>"
                                     aria-label="<?= $nombre_u ?> - <?= $tipo_legible ?>. Pulsa para ver el perfil.">

                                <div class="tarjeta-usuario__perfil">
                                    <div class="tarjeta-usuario__avatar-contenedor">
                                        <?php if ($tiene_av_u): ?>
                                            <img class="tarjeta-usuario__avatar"
                                                 src="<?= $avatar_u ?>"
                                                 alt="Avatar de <?= $nombre_u ?>">
                                        <?php else: ?>
                                            <div class="tarjeta-usuario__avatar-inicial" aria-hidden="true">
                                                <?= $inicial_u ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="tarjeta-usuario__metadatos">
                                        <h4 class="tarjeta-usuario__nombre"><?= $nombre_u ?></h4>
                                        <span class="tarjeta-usuario__etiqueta-tipo"><?= htmlspecialchars($tipo_legible) ?></span>
                                    </div>
                                </div>

                                <p class="tarjeta-usuario__descripcion"><?= $descripcion ?></p>

                                <div class="tarjeta-usuario__enlace" aria-hidden="true">
                                    <span>Ver perfil</span>
                                    <svg focusable="false" width="16" height="16" viewBox="0 0 24 24"
                                         fill="none" stroke="currentColor" stroke-width="2.5"
                                         stroke-linecap="round" stroke-linejoin="round">
                                        <line x1="5" y1="12" x2="19" y2="12"/>
                                        <polyline points="12 5 19 12 12 19"/>
                                    </svg>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </div>

    <div class="modal-perfil" id="modal-perfil" role="dialog" aria-modal="true" aria-labelledby="modal-perfil-nombre">
        <div class="modal-perfil__contenido">

            <button class="modal-perfil__cerrar" id="modal-perfil-cerrar" aria-label="Cerrar perfil">
                <svg focusable="false" width="20" height="20" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>

            <div class="modal-perfil__cabecera">
                <div class="modal-perfil__avatar-wrap" id="modal-perfil-avatar-wrap"></div>
                <div>
                    <h2 class="modal-perfil__nombre" id="modal-perfil-nombre"></h2>
                    <span class="modal-perfil__nombre-app" id="modal-perfil-nombre-app"></span>
                    <span class="tarjeta-usuario__etiqueta-tipo" id="modal-perfil-tipo"></span>
                </div>
            </div>

            <p class="modal-perfil__descripcion" id="modal-perfil-descripcion"></p>

            <div class="modal-perfil__etiquetas" id="modal-perfil-etiquetas"></div>

        </div>
    </div>
    <div class="modal-perfil__backdrop" id="modal-perfil-backdrop"></div>

    <?php include_once(__DIR__ . '/partials/footer.php'); ?>

    <script src="/js/Usuarios.js"></script>
    <script>
        const btnLimpiar = document.getElementById('btn-limpiar-filtros');
        if (btnLimpiar) {
            btnLimpiar.addEventListener('click', () => {
                window.location.href = '/usuarios';
            });
        }

        const modal     = document.getElementById('modal-perfil');
        const backdrop  = document.getElementById('modal-perfil-backdrop');
        const btnCerrar = document.getElementById('modal-perfil-cerrar');

        function abrirModal(datos) {
            const avatarWrap = document.getElementById('modal-perfil-avatar-wrap');
            if (datos.tiene_avatar && datos.avatar) {
                avatarWrap.innerHTML = `<img class="modal-perfil__avatar" src="${datos.avatar}" alt="Avatar de ${datos.nombre}">`;
            } else {
                avatarWrap.innerHTML = `<div class="modal-perfil__avatar-inicial" aria-hidden="true">${datos.inicial}</div>`;
            }

            document.getElementById('modal-perfil-nombre').textContent      = datos.nombre;
            document.getElementById('modal-perfil-nombre-app').textContent  = '@' + datos.nombre_app;
            document.getElementById('modal-perfil-tipo').textContent        = datos.tipo;
            document.getElementById('modal-perfil-descripcion').textContent = datos.descripcion || 'Este usuario aún no ha añadido una descripción.';

            const etiquetasEl = document.getElementById('modal-perfil-etiquetas');
            etiquetasEl.innerHTML = '';

            [
                { clave: 'busca_integrantes',     label: 'Busca integrantes' },
                { clave: 'acepta_colaboraciones', label: 'Acepta colaboraciones' },
                { clave: 'busca_staff',           label: 'Busca staff' },
            ].forEach(({ clave, label }) => {
                const valor = datos[clave];
                if (valor === null || valor === undefined) return;
                const badge = document.createElement('span');
                badge.className = 'modal-perfil__badge modal-perfil__badge--' + (valor ? 'si' : 'no');
                badge.textContent = (valor ? '✓ ' : '✗ ') + label;
                etiquetasEl.appendChild(badge);
            });

            modal.classList.add('visible');
            backdrop.classList.add('visible');
            document.body.classList.add('modal-abierto');
            btnCerrar.focus();
        }

        function cerrarModal() {
            modal.classList.remove('visible');
            backdrop.classList.remove('visible');
            document.body.classList.remove('modal-abierto');
        }

        document.querySelectorAll('.tarjeta-usuario').forEach(tarjeta => {
            tarjeta.addEventListener('click', () => {
                abrirModal(JSON.parse(tarjeta.dataset.perfil));
            });
            tarjeta.addEventListener('keydown', e => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    abrirModal(JSON.parse(tarjeta.dataset.perfil));
                }
            });
        });

        btnCerrar.addEventListener('click', cerrarModal);

        modal.addEventListener('keydown', e => {
            if (e.key === 'Escape') return;
            if (e.key === 'Tab') {
                const focusables = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                const first = focusables[0];
                const last  = focusables[focusables.length - 1];
                if (e.shiftKey && document.activeElement === first) {
                    e.preventDefault(); last.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                    e.preventDefault(); first.focus();
                }
            }
        });
    </script>
</body>
</html>