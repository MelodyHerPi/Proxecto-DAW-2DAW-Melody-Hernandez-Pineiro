<?php
$nombre_usuario = htmlspecialchars($_SESSION['usuario']['nombre_app'] ?? 'Usuario');
$id_usuario_sesion = $_SESSION['usuario']['id'] ?? null;

// Sanitización del avatar de cabecera
$foto_perfil_cruda = $perfil['foto_url'] ?? $_SESSION['usuario']['foto_url'] ?? '';
if (!empty($foto_perfil_cruda)) {
    $avatar_cabecera = (strpos($foto_perfil_cruda, '/public') === 0) ? substr($foto_perfil_cruda, 7) : $foto_perfil_cruda;
} else {
    $avatar_cabecera = '/uploads/avatars/default-avatar.png';
}


$nombre_usuario   = $nombre_usuario ?? 'Usuario';
$busqueda_texto   = $busqueda_texto ?? '';
$filtro_tipo      = $filtro_tipo ?? 'todos';
$listado_usuarios = $listado_usuarios ?? [];
$total_resultados = $total_resultados ?? 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios y Grupos — All Dance Together</title>
    <meta name="description" content="Busca y filtra usuarios solistas y grupos de baile en All Dance Together.">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/Usuarios.css">
</head>
<body>

    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <header class="cabecera">
        <button class="cabecera__menu-btn" id="btn-menu" aria-label="Abrir menú de navegación">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><rect y="3" width="20" height="2"/><rect y="9" width="20" height="2"/><rect y="15" width="20" height="2"/></svg>
        </button>
        <a href="/inicio" class="cabecera__marca">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <button class="cabecera__perfil" aria-label="Ver perfil de usuario">
            <span><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img class="cabecera__avatar-imagen" src="<?= $avatar_cabecera ?>" alt="">
            </span>
        </button>
    </header>

    <div class="contenedor-principal">

        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
            <ul class="navegacion-lateral__lista">
                <li>
                    <a class="navegacion-lateral__enlace" href="/inicio">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/eventos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/favoritos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
                        </svg>
                        Favoritos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/usuarios" aria-current="page">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/perfil">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
            </ul>
        </nav>

        <main id="contenido-principal" class="principal">

            <section class="seccion-encabezado" aria-labelledby="titulo-seccion">
                <h1 id="titulo-seccion" class="seccion-encabezado__titulo">
                    Comunidad de <span>Artistas</span>
                </h1>
                <p class="seccion-encabezado__descripcion">Encuentra, filtra e interactúa con otros usuarios solistas y agrupaciones de la plataforma.</p>
            </section>

            <section aria-label="Filtros de búsqueda">
                <form action="/usuarios" method="GET" class="formulario-filtrado" role="search">
                    <div class="formulario-filtrado__grupo">
                        <label for="buscar_texto" class="formulario-filtrado__etiqueta">Buscar por nombre o descripción</label>
                        <input 
                            type="search" 
                            id="buscar_texto" 
                            name="buscar" 
                            class="formulario-filtrado__campo" 
                            placeholder="Ej. ADT, Coco, Vigo..." 
                            value="<?= htmlspecialchars($busqueda_texto) ?>"
                        >
                    </div>

                    <div class="formulario-filtrado__grupo formulario-filtrado__grupo--corto">
                        <label for="filtrar_tipo" class="formulario-filtrado__etiqueta">Tipo de cuenta</label>
                        <select id="filtrar_tipo" name="tipo" class="formulario-filtrado__campo">
                            <option value="todos" <?= $filtro_tipo === 'todos' ? 'selected' : '' ?>>Todos</option>
                            <option value="1" <?= $filtro_tipo === '1' ? 'selected' : '' ?>>Usuarios Solistas</option>
                            <option value="2" <?= $filtro_tipo === '2' ? 'selected' : '' ?>>Grupos</option>
                        </select>
                    </div>

                    <button type="submit" class="formulario-filtrado__boton">
                        Aplicar filtros
                    </button>
                </form>
            </section>

            <div id="anuncio-resultados" class="oculto-visual" aria-live="polite">
                Se han encontrado <?= $total_resultados ?> resultados para tu búsqueda.
            </div>

            <section aria-labelledby="titulo-listado">
                <h2 id="titulo-listado" class="oculto-visual">Resultados de la búsqueda</h2>
                
                <?php if ($total_resultados === 0): ?>
                    <div class="sin-resultados">
                        <p class="sin-resultados__titulo">No se encontraron resultados</p>
                        <p class="sin-resultados__descripcion">Prueba a modificar los filtros o a escribir palabras clave distintas.</p>
                    </div>
                <?php else: ?>
                    <div class="cuadrilla-usuarios">
                        <?php foreach ($listado_usuarios as $usuario): 
                            // Fallback si el usuario no tiene avatar o descripción registrada en el perfil
                            $avatar = !empty($usuario['avatar_url']) ? $usuario['avatar_url'] : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80';
                            $descripcion = !empty($usuario['descripcion']) ? $usuario['descripcion'] : 'Este usuario aún no ha añadido una descripción a su perfil.';
                            // Homogeneizar la visualización de la etiqueta del tipo de usuario
                            $tipo_legible = (strtolower($usuario['tipo_nombre']) === 'grupo') ? 'Grupo' : 'Usuario solista';
                        ?>
                            <section 
                                class="tarjeta-usuario" 
                                tabindex="0" 
                                data-enlace="DetalleUsuario.php?id=<?= (int)$usuario['id'] ?>"
                                aria-label="<?= htmlspecialchars($usuario['nombre_real']) . ' - ' . $tipo_legible ?>"
                            >
                                <div class="tarjeta-usuario__perfil">
                                    <div class="tarjeta-usuario__avatar-contenedor">
                                        <img 
                                            class="tarjeta-usuario__avatar" 
                                            src="<?= htmlspecialchars($avatar) ?>" 
                                            alt="Avatar de <?= htmlspecialchars($usuario['nombre_real']) ?>"
                                        >
                                    </div>
                                    <div class="tarjeta-usuario__metadatos">
                                        <h3 class="tarjeta-usuario__nombre"><?= htmlspecialchars($usuario['nombre_real']) ?></h3>
                                        <span class="tarjeta-usuario__etiqueta-tipo"><?= htmlspecialchars($tipo_legible) ?></span>
                                    </div>
                                </div>
                                <p class="tarjeta-usuario__descripcion">
                                    <?= htmlspecialchars($descripcion) ?>
                                </p>
                                <div class="tarjeta-usuario__enlace">
                                    <span>Ver perfil detallado</span>
                                    <svg aria-hidden="true" focusable="false" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

    <script>
        // Lógica del Sidebar móvil responsivo
        const btnMenu = document.getElementById('btn-menu');
        const sidebar = document.getElementById('sidebar-nav');
        const overlay = document.getElementById('overlay-sidebar');

        function abrirSidebar() {
            sidebar.classList.add('abierto');
            overlay.classList.add('activo');
            overlay.removeAttribute('aria-hidden');
            btnMenu.setAttribute('aria-expanded', 'true');
            btnMenu.setAttribute('aria-label', 'Cerrar menú de navegación');
            sidebar.querySelector('a').focus();
        }

        function cerrarSidebar() {
            sidebar.classList.remove('abierto');
            overlay.classList.remove('activo');
            overlay.setAttribute('aria-hidden', 'true');
            btnMenu.setAttribute('aria-expanded', 'false');
            btnMenu.setAttribute('aria-label', 'Abrir menú de navegación');
            btnMenu.focus();
        }

        btnMenu.addEventListener('click', () => {
            sidebar.classList.contains('abierto') ? cerrarSidebar() : abrirSidebar();
        });

        overlay.addEventListener('click', cerrarSidebar);

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && sidebar.classList.contains('abierto')) cerrarSidebar();
        });

        // Trampa de foco (Focus Trap) para asegurar la accesibilidad móvil en el Sidebar
        sidebar.addEventListener('keydown', (e) => {
            if (e.key !== 'Tab' || !sidebar.classList.contains('abierto')) return;
            const focusables = [...sidebar.querySelectorAll('a, button')];
            const primero = focusables[0];
            const ultimo  = focusables[focusables.length - 1];
            if (e.shiftKey && document.activeElement === primero) {
                e.preventDefault(); ultimo.focus();
            } else if (!e.shiftKey && document.activeElement === ultimo) {
                e.preventDefault(); primero.focus();
            }
        });

        /* ── Redirección Accesible de las Tarjetas de Usuario ── */
        const tarjetas = document.querySelectorAll('.tarjeta-usuario');
        tarjetas.forEach(tarjeta => {
            const URLDetalle = tarjeta.getAttribute('data-enlace');
            
            // Redirección por evento click físico
            tarjeta.addEventListener('click', () => {
                window.location.href = URLDetalle;
            });

            // Redirección por teclado (Enter o barra espaciadora) cuando el elemento está enfocado
            tarjeta.addEventListener('keydown', (evento) => {
                if (evento.key === 'Enter' || evento.key === ' ') {
                    evento.preventDefault();
                    window.location.href = URLDetalle;
                }
            });
        });
    </script>
</body>
</html>