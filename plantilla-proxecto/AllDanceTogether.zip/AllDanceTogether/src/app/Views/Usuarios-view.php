<?php
$nombre_usuario   = $nombre_usuario ?? 'Usuario';
$busqueda_texto   = $busqueda_texto ?? '';
$filtro_tipo      = $filtro_tipo ?? 'todos';
$listado_usuarios = $listado_usuarios ?? [];
$total_resultados = $total_resultados ?? 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios y Grupos — All Dance Together</title>
    <meta name="description" content="Busca y filtra usuarios solistas y grupos de baile en All Dance Together.">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <style>
        /* ── Reset y Variables (Fieles a tus estilos globales) ── */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --color-fondo:        #03030a;
            --color-superficie:   rgba(10, 11, 28, 0.85);
            --color-tarjeta:      rgba(20, 21, 44, 0.7);
            --color-borde:        #1e1e3f;
            --color-borde-foco:   #ec4899;
            --gradiente-neon:     linear-gradient(135deg, #ec4899 0%, #3b82f6 100%);
            --color-texto:        #ffffff;
            --color-texto-suave:  #94a3b8;
            --color-marcador:     #475569;
            --color-principal:    #7b5ef8;
            --radio-mediano:      10px;
            --fuente-cuerpo:      'Montserrat', sans-serif;
            --fuente-titulo:      'Poppins', sans-serif;
            --ancho-sidebar:      240px;
            --alto-cabecera:      64px;
        }

        body {
            font-family: var(--fuente-cuerpo);
            background-color: var(--color-fondo);
            background-image:
                radial-gradient(circle at 45% 50%, rgba(236, 72, 153, 0.12) 0%, transparent 50%),
                radial-gradient(circle at 55% 50%, rgba(59, 130, 246, 0.12) 0%, transparent 50%);
            color: var(--color-texto);
            min-height: 100dvh;
            display: flex;
            flex-direction: column;
        }

        /* ── Enlace de salto (Accesibilidad) ─────────────────── */
        .saltar-contenido {
            position: absolute;
            top: -100%;
            left: 1rem;
            background: var(--color-borde-foco);
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 0 0 6px 6px;
            font-size: 0.875rem;
            font-weight: 600;
            text-decoration: none;
            z-index: 9999;
            transition: top 0.2s;
        }
        .saltar-contenido:focus { top: 0; }

        /* ── Cabecera ────────────────────────────────────────── */
        .cabecera {
            height: var(--alto-cabecera);
            padding: 0 clamp(1rem, 3vw, 2rem);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: rgba(3, 3, 10, 0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(30, 30, 63, 0.5);
            position: sticky;
            top: 0;
            z-index: 200;
            gap: 1rem;
        }

        .cabecera__marca {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: inherit;
            flex-shrink: 0;
        }

        .cabecera__nombre {
            font-family: var(--fuente-titulo);
            font-size: clamp(1.1rem, 3vw, 1.5rem);
            font-weight: 700;
            background: linear-gradient(90deg, #fff 0%, var(--color-principal) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
        }

        .cabecera__menu-btn {
            display: none;
            background: none;
            border: 1px solid var(--color-borde);
            border-radius: 6px;
            color: var(--color-texto-suave);
            cursor: pointer;
            padding: 0.45rem 0.55rem;
            line-height: 1;
            transition: color 0.2s, border-color 0.2s;
        }
        .cabecera__menu-btn:hover { color: #fff; border-color: var(--color-texto-suave); }
        .cabecera__menu-btn:focus-visible { outline: 2px solid var(--color-borde-foco); outline-offset: 2px; }

        .cabecera__perfil {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            background: none;
            border: none;
            color: inherit;
            font-family: inherit;
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            padding: 0.3rem 0.5rem;
            border-radius: 6px;
            transition: background 0.2s;
        }
        .cabecera__perfil:hover { background: rgba(255,255,255,0.04); }
        .cabecera__perfil:focus-visible { outline: 2px solid var(--color-borde-foco); outline-offset: 2px; }

        .cabecera__avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: var(--gradiente-neon);
            padding: 2px;
            flex-shrink: 0;
        }

        .cabecera__avatar-imagen {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            background-color: var(--color-fondo);
        }

        /* ── Layout ──────────────────────────────────────────── */
        .contenedor-principal {
            flex: 1;
            display: grid;
            grid-template-columns: var(--ancho-sidebar) 1fr;
        }

        .overlay-sidebar {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            z-index: 150;
        }
        .overlay-sidebar.activo { display: block; }

        /* ── Sidebar ─────────────────────────────────────────── */
        .navegacion-lateral {
            background-color: rgba(5, 5, 15, 0.6);
            border-right: 1px solid rgba(30, 30, 63, 0.4);
            padding: 1.75rem 1rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 2rem;
            position: sticky;
            top: var(--alto-cabecera);
            height: calc(100dvh - var(--alto-cabecera));
            overflow-y: auto;
        }

        .navegacion-lateral__lista {
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
            list-style: none;
        }

        .navegacion-lateral__enlace {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            padding: 0.75rem 1rem;
            color: var(--color-texto-suave);
            text-decoration: none;
            border-radius: var(--radio-mediano);
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.2s ease;
            border: 1px solid transparent;
        }
        .navegacion-lateral__enlace:hover {
            color: #fff;
            background-color: rgba(255,255,255,0.04);
        }
        .navegacion-lateral__enlace--activo {
            color: #fff;
            background-color: rgba(123, 94, 248, 0.15);
            border-color: rgba(123, 94, 248, 0.3);
        }
        .navegacion-lateral__enlace:focus-visible {
            outline: 2px solid var(--color-borde-foco);
            outline-offset: 2px;
        }

        .nav-icono {
            width: 18px;
            height: 18px;
            flex-shrink: 0;
            opacity: 0.7;
        }
        .navegacion-lateral__enlace--activo .nav-icono,
        .navegacion-lateral__enlace:hover .nav-icono { opacity: 1; }

        /* ── Contenido Principal (Listado) ───────────────────── */
        .principal {
            padding: clamp(2rem, 5vw, 3.5rem) clamp(1rem, 5vw, 3rem);
            display: flex;
            flex-direction: column;
            gap: 2.5rem;
            min-width: 0;
        }

        .seccion-encabezado {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .seccion-encabezado__titulo {
            font-family: var(--fuente-titulo);
            font-size: clamp(1.8rem, 5vw, 2.5rem);
            font-weight: 700;
            line-height: 1.1;
            letter-spacing: -0.5px;
        }

        .seccion-encabezado__titulo span {
            background: var(--gradiente-neon);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .seccion-encabezado__descripcion {
            font-size: clamp(0.875rem, 2vw, 1rem);
            color: var(--color-texto-suave);
            line-height: 1.5;
        }

        /* ── Formulario de Filtros Exclusivo y Accesible ─────── */
        .formulario-filtrado {
            background-color: var(--color-superficie);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-mediano);
            padding: 1.5rem;
            display: flex;
            flex-wrap: wrap;
            gap: 1.25rem;
            align-items: flex-end;
        }

        .formulario-filtrado__grupo {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            flex: 1;
            min-width: 260px;
        }

        .formulario-filtrado__grupo--corto {
            flex: 0 1 220px;
            min-width: 180px;
        }

        .formulario-filtrado__etiqueta {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--color-texto-suave);
        }

        .formulario-filtrado__campo {
            width: 100%;
            background-color: var(--color-fondo);
            border: 1px solid var(--color-borde);
            border-radius: 6px;
            color: var(--color-texto);
            padding: 0.75rem 1rem;
            font-family: var(--fuente-cuerpo);
            font-size: 0.95rem;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .formulario-filtrado__campo:focus {
            outline: none;
            border-color: var(--color-borde-foco);
            box-shadow: 0 0 0 3px rgba(236, 72, 145, 0.25);
        }

        .formulario-filtrado__boton {
            padding: 0.75rem 1.5rem;
            background: var(--gradiente-neon);
            border: none;
            border-radius: 6px;
            color: #fff;
            font-family: var(--fuente-cuerpo);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s;
            height: 44px;
        }
        .formulario-filtrado__boton:hover { opacity: 0.9; }
        .formulario-filtrado__boton:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }

        /* ── Mensaje de Sin Resultados ───────────────────────── */
        .sin-resultados {
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-mediano);
            padding: 3rem 1.5rem;
            text-align: center;
        }
        .sin-resultados__titulo {
            font-family: var(--fuente-titulo);
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }
        .sin-resultados__descripcion {
            color: var(--color-texto-suave);
            font-size: 0.95rem;
        }

        /* ── Cuadrícula de Tarjetas de Usuarios ───────────────── */
        .cuadrilla-usuarios {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        .tarjeta-usuario {
            position: relative;
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-mediano);
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
            cursor: pointer;
            transition: border-color 0.2s, transform 0.2s, background-color 0.2s;
        }

        .tarjeta-usuario::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: var(--radio-mediano);
            padding: 1px;
            background: linear-gradient(135deg, rgba(236,72,153,0.3) 0%, rgba(59,130,246,0.3) 100%);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        }

        .tarjeta-usuario:hover {
            border-color: rgba(236, 72, 153, 0.4);
            transform: translateY(-3px);
            background-color: rgba(20, 21, 44, 0.9);
        }
        .tarjeta-usuario:hover::before { opacity: 1; }
        .tarjeta-usuario:focus-visible { outline: 2px solid var(--color-borde-foco); outline-offset: 2px; }

        .tarjeta-usuario__perfil {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .tarjeta-usuario__avatar-contenedor {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--gradiente-neon);
            padding: 2px;
            flex-shrink: 0;
        }

        .tarjeta-usuario__avatar {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
            background-color: var(--color-fondo);
        }

        .tarjeta-usuario__metadatos {
            display: flex;
            flex-direction: column;
            gap: 0.15rem;
        }

        .tarjeta-usuario__nombre {
            font-family: var(--fuente-titulo);
            font-size: 1.15rem;
            font-weight: 600;
            color: var(--color-texto);
        }

        .tarjeta-usuario__etiqueta-tipo {
            display: inline-block;
            width: fit-content;
            padding: 0.15rem 0.5rem;
            background: rgba(123, 94, 248, 0.12);
            border: 1px solid rgba(123, 94, 248, 0.25);
            border-radius: 4px;
            font-size: 0.72rem;
            font-weight: 600;
            color: var(--color-principal);
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .tarjeta-usuario__descripcion {
            font-size: 0.85rem;
            color: var(--color-texto-suave);
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .tarjeta-usuario__enlace {
            margin-top: auto;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--color-borde-foco);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }

        /* ── Oculto para lectores de pantalla ────────────────── */
        .oculto-visual {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            border: 0;
        }

        /* ── Pie ─────────────────────────────────────────────── */
        .pie-pagina {
            padding: 1.25rem 2rem;
            background-color: rgba(3, 3, 10, 0.9);
            border-top: 1px solid rgba(30, 30, 63, 0.3);
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            gap: 0.75rem 2rem;
            margin-top: auto;
        }

        .pie-pagina__navegacion {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            list-style: none;
            flex-wrap: wrap;
        }

        .pie-pagina__enlace {
            color: var(--color-texto-suave);
            text-decoration: none;
            font-size: 0.82rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        .pie-pagina__enlace:hover { color: #fff; }

        .pie-pagina__copiar {
            font-size: 0.73rem;
            color: var(--color-marcador);
            width: 100%;
            text-align: center;
        }

        /* ── Responsivo ──────────────────────────────────────── */
        @media (max-width: 820px) {
            .contenedor-principal { grid-template-columns: 1fr; }

            .cabecera__menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .navegacion-lateral {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--ancho-sidebar);
                height: 100dvh;
                z-index: 300;
                transform: translateX(-100%);
                transition: transform 0.28s ease;
                border-right: 1px solid rgba(30, 30, 63, 0.6);
                padding-top: calc(var(--alto-cabecera) + 1rem);
                background-color: rgba(5, 5, 18, 0.97);
                backdrop-filter: blur(20px);
            }
            .navegacion-lateral.abierto { transform: translateX(0); }
        }

        @media (max-width: 480px) {
            .cabecera__perfil span:not(.cabecera__avatar) { display: none; }
            .formulario-filtrado { padding: 1rem; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { transition: none !important; animation: none !important; }
        }
    </style>
</head>
<body>

    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <header class="cabecera" role="banner">
        <button
            class="cabecera__menu-btn"
            id="btn-menu"
            aria-expanded="false"
            aria-controls="sidebar-nav"
            aria-label="Abrir menú de navegación"
        >
            <svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect y="3"  width="20" height="2" rx="1" fill="currentColor"/>
                <rect y="9"  width="20" height="2" rx="1" fill="currentColor"/>
                <rect y="15" width="20" height="2" rx="1" fill="currentColor"/>
            </svg>
        </button>

        <a href="/inicio" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>

        <button class="cabecera__perfil" aria-haspopup="true" aria-label="Menú de usuario: <?= $nombre_usuario ?>">
            <span aria-hidden="true"><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img
                    class="cabecera__avatar-imagen"
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&q=80"
                    alt="Foto de perfil de <?= $nombre_usuario ?>"
                >
            </span>
        </button>
    </header>

    <div class="contenedor-principal">

        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
            <ul class="navegacion-lateral__lista">
                <li>
                    <a class="navegacion-lateral__enlace" href="/inicio">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/eventos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/favoritos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
                        </svg>
                        Favoritos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/usuarios" aria-current="page">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/perfil">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
            </ul>
        </nav>

        <main id="contenido-principal" class="principal">

            <section class="seccion-encabezado" aria-labelledby="titulo-seccion">
                <h1 id="titulo-seccion" class="seccion-encabezado__titulo">
                    Comunidad de <span>Artistas</span>
                </h1>
                <p class="seccion-encabezado__descripcion">Encuentra, filtra e interactúa con otros usuarios solistas y agrupaciones de la plataforma.</p>
            </section>

            <section aria-label="Filtros de búsqueda">
                <form action="/usuarios" method="GET" class="formulario-filtrado" role="search">
                    <div class="formulario-filtrado__grupo">
                        <label for="buscar_texto" class="formulario-filtrado__etiqueta">Buscar por nombre o descripción</label>
                        <input 
                            type="search" 
                            id="buscar_texto" 
                            name="buscar" 
                            class="formulario-filtrado__campo" 
                            placeholder="Ej. ADT, Coco, Vigo..." 
                            value="<?= htmlspecialchars($busqueda_texto) ?>"
                        >
                    </div>

                    <div class="formulario-filtrado__grupo formulario-filtrado__grupo--corto">
                        <label for="filtrar_tipo" class="formulario-filtrado__etiqueta">Tipo de cuenta</label>
                        <select id="filtrar_tipo" name="tipo" class="formulario-filtrado__campo">
                            <option value="todos" <?= $filtro_tipo === 'todos' ? 'selected' : '' ?>>Todos</option>
                            <option value="1" <?= $filtro_tipo === '1' ? 'selected' : '' ?>>Usuarios Solistas</option>
                            <option value="2" <?= $filtro_tipo === '2' ? 'selected' : '' ?>>Grupos</option>
                        </select>
                    </div>

                    <button type="submit" class="formulario-filtrado__boton">
                        Aplicar filtros
                    </button>
                </form>
            </section>

            <div id="anuncio-resultados" class="oculto-visual" aria-live="polite">
                Se han encontrado <?= $total_resultados ?> resultados para tu búsqueda.
            </div>

            <section aria-labelledby="titulo-listado">
                <h2 id="titulo-listado" class="oculto-visual">Resultados de la búsqueda</h2>
                
                <?php if ($total_resultados === 0): ?>
                    <div class="sin-resultados">
                        <p class="sin-resultados__titulo">No se encontraron resultados</p>
                        <p class="sin-resultados__descripcion">Prueba a modificar los filtros o a escribir palabras clave distintas.</p>
                    </div>
                <?php else: ?>
                    <div class="cuadrilla-usuarios">
                        <?php foreach ($listado_usuarios as $usuario): 
                            // Fallback si el usuario no tiene avatar o descripción registrada en el perfil
                            $avatar = !empty($usuario['avatar_url']) ? $usuario['avatar_url'] : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80';
                            $descripcion = !empty($usuario['descripcion']) ? $usuario['descripcion'] : 'Este usuario aún no ha añadido una descripción a su perfil.';
                            // Homogeneizar la visualización de la etiqueta del tipo de usuario
                            $tipo_legible = (strtolower($usuario['tipo_nombre']) === 'grupo') ? 'Grupo' : 'Usuario solista';
                        ?>
                            <section 
                                class="tarjeta-usuario" 
                                tabindex="0" 
                                data-enlace="DetalleUsuario.php?id=<?= (int)$usuario['id'] ?>"
                                aria-label="<?= htmlspecialchars($usuario['nombre_real']) . ' - ' . $tipo_legible ?>"
                            >
                                <div class="tarjeta-usuario__perfil">
                                    <div class="tarjeta-usuario__avatar-contenedor">
                                        <img 
                                            class="tarjeta-usuario__avatar" 
                                            src="<?= htmlspecialchars($avatar) ?>" 
                                            alt="Avatar de <?= htmlspecialchars($usuario['nombre_real']) ?>"
                                        >
                                    </div>
                                    <div class="tarjeta-usuario__metadatos">
                                        <h3 class="tarjeta-usuario__nombre"><?= htmlspecialchars($usuario['nombre_real']) ?></h3>
                                        <span class="tarjeta-usuario__etiqueta-tipo"><?= htmlspecialchars($tipo_legible) ?></span>
                                    </div>
                                </div>
                                <p class="tarjeta-usuario__descripcion">
                                    <?= htmlspecialchars($descripcion) ?>
                                </p>
                                <div class="tarjeta-usuario__enlace">
                                    <span>Ver perfil detallado</span>
                                    <svg aria-hidden="true" focusable="false" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

    <script>
        // Lógica del Sidebar móvil responsivo
        const btnMenu = document.getElementById('btn-menu');
        const sidebar = document.getElementById('sidebar-nav');
        const overlay = document.getElementById('overlay-sidebar');

        function abrirSidebar() {
            sidebar.classList.add('abierto');
            overlay.classList.add('activo');
            overlay.removeAttribute('aria-hidden');
            btnMenu.setAttribute('aria-expanded', 'true');
            btnMenu.setAttribute('aria-label', 'Cerrar menú de navegación');
            sidebar.querySelector('a').focus();
        }

        function cerrarSidebar() {
            sidebar.classList.remove('abierto');
            overlay.classList.remove('activo');
            overlay.setAttribute('aria-hidden', 'true');
            btnMenu.setAttribute('aria-expanded', 'false');
            btnMenu.setAttribute('aria-label', 'Abrir menú de navegación');
            btnMenu.focus();
        }

        btnMenu.addEventListener('click', () => {
            sidebar.classList.contains('abierto') ? cerrarSidebar() : abrirSidebar();
        });

        overlay.addEventListener('click', cerrarSidebar);

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && sidebar.classList.contains('abierto')) cerrarSidebar();
        });

        // Trampa de foco (Focus Trap) para asegurar la accesibilidad móvil en el Sidebar
        sidebar.addEventListener('keydown', (e) => {
            if (e.key !== 'Tab' || !sidebar.classList.contains('abierto')) return;
            const focusables = [...sidebar.querySelectorAll('a, button')];
            const primero = focusables[0];
            const ultimo  = focusables[focusables.length - 1];
            if (e.shiftKey && document.activeElement === primero) {
                e.preventDefault(); ultimo.focus();
            } else if (!e.shiftKey && document.activeElement === ultimo) {
                e.preventDefault(); primero.focus();
            }
        });

        /* ── Redirección Accesible de las Tarjetas de Usuario ── */
        const tarjetas = document.querySelectorAll('.tarjeta-usuario');
        tarjetas.forEach(tarjeta => {
            const URLDetalle = tarjeta.getAttribute('data-enlace');
            
            // Redirección por evento click físico
            tarjeta.addEventListener('click', () => {
                window.location.href = URLDetalle;
            });

            // Redirección por teclado (Enter o barra espaciadora) cuando el elemento está enfocado
            tarjeta.addEventListener('keydown', (evento) => {
                if (evento.key === 'Enter' || evento.key === ' ') {
                    evento.preventDefault();
                    window.location.href = URLDetalle;
                }
            });
        });
    </script>
</body>
</html>