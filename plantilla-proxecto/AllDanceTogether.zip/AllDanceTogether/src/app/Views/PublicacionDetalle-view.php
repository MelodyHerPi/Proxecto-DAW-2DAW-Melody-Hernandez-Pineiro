<?php
// Extracción de datos de sesión adaptados a tu estructura estándar
$nombre_usuario = htmlspecialchars($_SESSION['usuario']['nombre_app'] ?? 'Usuario');
$id_usuario_sesion = $_SESSION['usuario']['id'] ?? null;

// Sanitización del avatar de cabecera
$foto_perfil_cruda = $_SESSION['usuario']['avatar_url'] ?? '';
if (!empty($foto_perfil_cruda)) {
    $avatar_cabecera = (strpos($foto_perfil_cruda, '/public') === 0) ? substr($foto_perfil_cruda, 7) : $foto_perfil_cruda;
} else {
    $avatar_cabecera = '/uploads/avatars/default-avatar.png';
}

// Datos de la publicación inyectados por el controlador
$titulo_pagina = isset($publicacion['titulo']) ? htmlspecialchars($publicacion['titulo']) : 'Detalle de Publicación';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo_pagina ?> — All Dance Together</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --color-fondo:        #03030a;
            --color-superficie:   rgba(10, 11, 28, 0.6);
            --color-tarjeta:      rgba(20, 21, 44, 0.7);
            --color-borde:        #1e1e3f;
            --color-borde-foco:   #ec4899;
            --gradiente-neon:     linear-gradient(135deg, #ec4899 0%, #3b82f6 100%);
            --color-texto:        #ffffff;
            --color-texto-suave:  #94a3b8;
            --color-principal:    #7b5ef8;
            
            --radio-md:           14px;
            --fuente-cuerpo:      'Montserrat', sans-serif;
            --fuente-titulo:      'Poppins', sans-serif;
            --ancho-sidebar:      240px;
            --alto-cabecera:      64px;
        }

        body {
            font-family: var(--fuente-cuerpo);
            background-color: var(--color-fondo);
            background-image:
                radial-gradient(circle at 15% 25%, rgba(236, 72, 153, 0.08) 0%, transparent 50%),
                radial-gradient(circle at 85% 75%, rgba(59, 130, 246, 0.08) 0%, transparent 50%);
            color: var(--color-texto);
            min-height: 100dvh;
            display: flex;
            flex-direction: column;
        }

        /* ── Cabecera ── */
        .cabecera {
            height: var(--alto-cabecera);
            padding: 0 clamp(1rem, 3vw, 2rem);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: rgba(3, 3, 10, 0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(30, 30, 63, 0.5);
            position: sticky; top: 0; z-index: 200; gap: 1rem;
        }
        .cabecera__marca { display: flex; align-items: center; text-decoration: none; color: inherit; }
        .cabecera__nombre {
            font-family: var(--fuente-titulo); font-size: clamp(1.1rem, 3vw, 1.5rem); font-weight: 700;
            background: linear-gradient(90deg, #fff 0%, var(--color-principal) 100%);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .cabecera__menu-btn {
            display: none; background: none; border: 1px solid var(--color-borde);
            border-radius: 6px; color: var(--color-texto-suave); cursor: pointer; padding: 0.45rem 0.55rem;
        }
        .cabecera__perfil { display: flex; align-items: center; gap: 0.6rem; background: none; border: none; color: inherit; font-weight: 600; font-size: 0.875rem; cursor: pointer; }
        .cabecera__avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--gradiente-neon); padding: 2px; }
        .cabecera__avatar-imagen { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; display: block; background-color: var(--color-fondo); }

        /* ── Layout Grid Estructura ── */
        .contenedor-principal { flex: 1; display: grid; grid-template-columns: var(--ancho-sidebar) 1fr; }
        .overlay-sidebar { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 150; }
        .overlay-sidebar.activo { display: block; }

        /* ── Sidebar ── */
        .navegacion-lateral {
            background-color: rgba(5, 5, 15, 0.6); border-right: 1px solid rgba(30, 30, 63, 0.4);
            padding: 1.75rem 1rem; display: flex; flex-direction: column; justify-content: space-between;
            position: sticky; top: var(--alto-cabecera); height: calc(100dvh - var(--alto-cabecera)); overflow-y: auto;
        }
        .navegacion-lateral__lista { display: flex; flex-direction: column; gap: 0.35rem; list-style: none; }
        .navegacion-lateral__enlace {
            display: flex; align-items: center; gap: 0.7rem; padding: 0.75rem 1rem; color: var(--color-texto-suave);
            text-decoration: none; border-radius: 10px; font-weight: 500; font-size: 0.9rem; border: 1px solid transparent; transition: all 0.2s;
        }
        .navegacion-lateral__enlace:hover { color: #fff; background-color: rgba(255,255,255,0.04); }
        .navegacion-lateral__enlace--activo { color: #fff; background-color: rgba(123, 94, 248, 0.15); border-color: rgba(123, 94, 248, 0.3); }

        /* ── Área de Trabajo ── */
        .principal { padding: clamp(1.5rem, 4vw, 3rem) clamp(1rem, 4vw, 2.5rem); min-width: 0; }

        /* Alertas */
        .alerta { padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.9rem; font-weight: 500; }
        .alerta--exito { background-color: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; color: #10b981; }
        .alerta--error { background-color: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; color: #ef4444; }

        /* Enlace de regreso */
        .enlace-volver { display: inline-flex; align-items: center; gap: 0.5rem; color: var(--color-texto-suave); text-decoration: none; font-size: 0.9rem; margin-bottom: 1.5rem; transition: color 0.2s; }
        .enlace-volver:hover { color: #fff; }

        /* ── Estructura de la Ficha (Semántica) ── */
        .seccion-detalle { background-color: var(--color-tarjeta); border: 1px solid var(--color-borde); border-radius: var(--radio-md); overflow: hidden; margin-bottom: 2.5rem; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
        .seccion-detalle__hero { width: 100%; height: clamp(200px, 40vh, 400px); background-color: #0c0d21; position: relative; margin: 0; }
        .seccion-detalle__img { width: 100%; height: 100%; object-fit: cover; }
        
        .badge-tipo { position: absolute; top: 20px; left: 20px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; padding: 0.35rem 0.8rem; border-radius: 4px; color: #fff; letter-spacing: 0.5px; }
        .badge-tipo--evento { background: #7b5ef8; }
        .badge-tipo--noticia { background: #ec4899; }

        .seccion-detalle__cuerpo { padding: clamp(1.5rem, 4vw, 2.5rem); }
        .seccion-detalle__header-acciones { display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem; }
        .seccion-detalle__titulo { font-family: var(--fuente-titulo); font-size: clamp(1.75rem, 4vw, 2.5rem); font-weight: 700; line-height: 1.2; }
        
        /* Botón Editar */
        .btn-editar-propio { background: #7b5ef8; color: #fff; border: none; border-radius: 8px; padding: 0.6rem 1.2rem; font-family: inherit; font-size: 0.85rem; font-weight: 600; text-decoration: none; cursor: pointer; transition: background 0.2s, transform 0.1s; display: inline-flex; align-items: center; gap: 0.5rem; }
        .btn-editar-propio:hover { background: #6346df; }
        .btn-editar-propio:active { transform: scale(0.98); }

        /* Metadata (Lista de descripción semántica) */
        .seccion-detalle__meta { display: flex; flex-wrap: wrap; gap: 1.5rem; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid rgba(30, 30, 63, 0.6); font-size: 0.9rem; color: var(--color-texto-suave); }
        .meta-grupo { display: inline-flex; align-items: center; gap: 0.3rem; }
        .meta-grupo dt { display: flex; align-items: center; }
        .meta-grupo dd { color: #fff; font-weight: 500; }
        .svg-icon { display: inline-block; fill: currentColor; width: 18px; height: 18px; vertical-align: middle; }

        .seccion-detalle__descripcion { font-size: 1.05rem; line-height: 1.7; color: rgba(255,255,255,0.9); white-space: pre-line; }

        /* Formulario e Inputs de Edición Inline */
        .formulario-edicion { display: flex; flex-direction: column; gap: 1.25rem; }
        .grupo-campo { display: flex; flex-direction: column; gap: 0.5rem; }
        .grupo-campo label { font-size: 0.75rem; font-weight: 600; color: var(--color-texto-suave); text-transform: uppercase; letter-spacing: 0.5px; }

        /* ── Comentarios ── */
        .seccion-comentarios { background-color: var(--color-superficie); border: 1px solid var(--color-borde); border-radius: var(--radio-md); padding: clamp(1.5rem, 4vw, 2.5rem); backdrop-filter: blur(20px); }
        .seccion-comentarios__titulo { font-family: var(--fuente-titulo); font-size: 1.5rem; font-weight: 600; margin-bottom: 1.5rem; }

        .formulario-comentario { display: flex; flex-direction: column; gap: 1rem; margin-bottom: 2.5rem; }
        .input-textarea { background-color: rgba(3, 3, 10, 0.6); border: 1px solid var(--color-borde); border-radius: 8px; padding: 1rem; color: #fff; font-family: inherit; font-size: 0.95rem; line-height: 1.5; resize: vertical; min-height: 100px; width: 100%; transition: border-color 0.2s; }
        .input-textarea:focus { outline: none; border-color: var(--color-borde-foco); }
        
        .btn-enviar-comentario { align-self: flex-end; background: var(--gradiente-neon); color: #fff; border: none; border-radius: 8px; padding: 0.75rem 1.75rem; font-family: inherit; font-weight: 600; cursor: pointer; transition: transform 0.2s; box-shadow: 0 4px 15px rgba(236, 72, 153, 0.2); }
        .btn-enviar-comentario:hover { transform: scale(1.02); }

        .lista-comentarios { display: flex; flex-direction: column; gap: 1.5rem; list-style: none; }
        .comentario-item { display: flex; gap: 1rem; background-color: rgba(255,255,255,0.02); padding: 1.25rem; border-radius: 10px; border: 1px solid rgba(30, 30, 63, 0.3); }
        .comentario-item__avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; background-color: var(--color-borde); flex-shrink: 0; }
        .comentario-item__contenido { flex: 1; }
        .comentario-item__meta { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; font-size: 0.85rem; }
        .comentario-item__autor { font-weight: 600; color: #fff; }
        .comentario-item__fecha { color: var(--color-texto-suave); }
        .comentario-item__texto { font-size: 0.95rem; line-height: 1.5; color: rgba(255,255,255,0.85); white-space: pre-line; }

        .sin-comentarios { text-align: center; color: var(--color-texto-suave); padding: 2rem 0; font-size: 0.95rem; }
        .pie-pagina { padding: 1.25rem 2rem; background-color: rgba(3, 3, 10, 0.9); border-top: 1px solid rgba(30, 30, 63, 0.3); text-align: center; font-size: 0.75rem; color: var(--color-texto-suave); margin-top: auto; }

        @media (max-width: 820px) {
            .contenedor-principal { grid-template-columns: 1fr; }
            .cabecera__menu-btn { display: block; }
            .navegacion-lateral { position: fixed; top: 0; left: 0; bottom: 0; width: var(--ancho-sidebar); transform: translateX(-100%); transition: transform 0.3s; z-index: 300; background: #050512; }
            .navegacion-lateral.abierto { transform: translateX(0); }
            .formulario-edicion .acciones-fila { flex-direction: column-reverse; }
            .formulario-edicion .acciones-fila button, .formulario-edicion .acciones-fila a { width: 100%; }
        }
    </style>
</head>
<body>

    <header class="cabecera">
        <button class="cabecera__menu-btn" id="btn-menu" aria-label="Abrir menú de navegación">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><rect y="3" width="20" height="2"/><rect y="9" width="20" height="2"/><rect y="15" width="20" height="2"/></svg>
        </button>
        <a href="/inicio" class="cabecera__marca">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <button class="cabecera__perfil" aria-label="Ver perfil de usuario">
            <span><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img class="cabecera__avatar-imagen" src="<?= $avatar_cabecera ?>" alt="">
            </span>
        </button>
    </header>

    <div class="contenedor-principal">
        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Menú principal de la aplicación">
            <ul class="navegacion-lateral__lista">
                <li><a class="navegacion-lateral__enlace" href="/inicio">Inicio</a></li>
                <li><a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/descubrir" aria-current="page">Descubrir</a></li>
                <li><a class="navegacion-lateral__enlace" href="/eventos">Próximos eventos</a></li>
                <li><a class="navegacion-lateral__enlace" href="/favoritos">Favoritos</a></li>
                <li><a class="navegacion-lateral__enlace" href="/usuarios">Usuarios</a></li>
                <li><a class="navegacion-lateral__enlace" href="/perfil">Mi perfil</a></li>
            </ul>
        </nav>

        <div class="overlay-sidebar" id="overlay-sidebar" role="presentation"></div>

        <main class="principal" id="contenido-principal">
            
            <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito" role="alert"><?= $_SESSION['msg_exito']; unset($_SESSION['msg_exito']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error" role="alert"><?= $_SESSION['msg_error']; unset($_SESSION['msg_error']); ?></div>
            <?php endif; ?>

            <a href="/descubrir" class="enlace-volver">
                <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                Volver a Descubrir
            </a>

            <?php if (!empty($publicacion)): ?>
                <?php 
                    $tipo_publicacion = $publicacion['tipo'] ?? 'evento'; 
                    $es_dueno = (isset($publicacion['id_creador']) && $id_usuario_sesion == $publicacion['id_creador']);
                ?>
                
                <article class="seccion-detalle" aria-labelledby="titulo-publicacion">
                    <figure class="seccion-detalle__hero">
                        <span class="badge-tipo badge-tipo--<?= htmlspecialchars($tipo_publicacion) ?>">
                            <?= htmlspecialchars($tipo_publicacion) ?>
                        </span>
                        <?php if (!empty($publicacion['foto_url'])): ?>
                            <img class="seccion-detalle__img" src="<?= htmlspecialchars($publicacion['foto_url']) ?>" alt="Imagen de cabecera para <?= htmlspecialchars($publicacion['titulo']) ?>">
                        <?php else: ?>
                            <img class="seccion-detalle__img" src="/uploads/default-placeholder.jpg" alt="Imagen predeterminada del ecosistema">
                        <?php endif; ?>
                    </figure>

                    <div class="seccion-detalle__cuerpo" id="modo-lectura">
                        <header class="seccion-detalle__header-acciones">
                            <h1 id="titulo-publicacion" class="seccion-detalle__titulo"><?= htmlspecialchars($publicacion['titulo']) ?></h1>
                            
                            <?php if ($es_dueno): ?>
                                <button type="button" class="btn-editar-propio" id="btn-activar-edicion" aria-expanded="false" aria-controls="modo-edicion">
                                    <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                    Editar
                                </button>
                            <?php endif; ?>
                        </header>
                        
                        <dl class="seccion-detalle__meta">
                            <?php if(!empty($publicacion['lugar'])): ?>
                                <div class="meta-grupo">
                                    <dt aria-label="Ubicación"><svg class="svg-icon" viewBox="0 0 24 24" style="color: #ec4899;" aria-hidden="true"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg></dt>
                                    <dd><?= htmlspecialchars($publicacion['lugar']) ?></dd>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($publicacion['fecha'])): ?>
                                <div class="meta-grupo">
                                    <dt aria-label="Fecha del evento"><svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/></svg></dt>
                                    <dd><time datetime="<?= htmlspecialchars($publicacion['fecha']) ?>"><?= htmlspecialchars($publicacion['fecha']) ?></time></dd>
                                </div>
                            <?php endif; ?>
                        </dl>

                        <p class="seccion-detalle__descripcion"><?= htmlspecialchars($publicacion['descripcion']) ?></p>
                    </div>

                    <?php if ($es_dueno): ?>
                        <section class="seccion-detalle__cuerpo" id="modo-edicion" style="display: none;" aria-labelledby="cabecera-edicion">
                            <h2 id="cabecera-edicion" style="font-family: var(--fuente-titulo); margin-bottom: 1.5rem; font-size: 1.5rem;">Modificar Publicación</h2>
                            
                            <form action="/descubrir/procesarEditar" method="POST" enctype="multipart/form-data" class="formulario-edicion">
                                <input type="hidden" name="id" value="<?= (int)$publicacion['id'] ?>">

                                <div class="grupo-campo">
                                    <label Lothar for="txt-titulo">Título de la publicación</label>
                                    <input type="text" id="txt-titulo" name="titulo" class="input-textarea" style="min-height: auto; padding: 0.75rem;" value="<?= htmlspecialchars($publicacion['titulo']) ?>" required>
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-lugar">Ubicación / Lugar</label>
                                    <input type="text" id="txt-lugar" name="lugar" class="input-textarea" style="min-height: auto; padding: 0.75rem;" value="<?= htmlspecialchars($publicacion['lugar'] ?? '') ?>">
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-descripcion">Descripción o Contenido</label>
                                    <textarea id="txt-descripcion" name="descripcion" class="input-textarea" rows="6" required><?= htmlspecialchars($publicacion['descripcion']) ?></textarea>
                                </div>

                                <div class="grupo-campo">
                                    <label Lothar for="file-foto">Cambiar imagen de portada</label>
                                    <input type="file" id="file-foto" name="foto" class="input-textarea" style="min-height: auto; padding: 0.5rem;" accept="image/*">
                                </div>

                                <div class="acciones-fila" style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 0.5rem;">
                                    <button type="button" id="btn-cancelar-edicion" style="background: transparent; color: var(--color-texto-suave); border: 1px solid var(--color-borde); padding: 0.6rem 1.2rem; border-radius: 8px; cursor: pointer; font-family: inherit; font-size: 0.85rem;">
                                        Cancelar
                                    </button>
                                    <button type="submit" class="btn-enviar-comentario" style="align-self: auto; padding: 0.6rem 1.5rem; font-size: 0.85rem; margin: 0;">
                                        Guardar Cambios
                                    </button>
                                </div>
                            </form>
                        </section>
                    <?php endif; ?>
                </article>

                <section class="seccion-comentarios" aria-label="Sección de comentarios">
                    <h2 class="seccion-comentarios__titulo">Comentarios de la comunidad</h2>

                    <form action="/descubrir/comentar" method="POST" class="formulario-comentario" aria-label="Deja un comentario">
                        <input type="hidden" name="publicacion_id" value="<?= (int)$publicacion['id'] ?>">
                        <label for="area-comentario" class="sr-only" style="position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); border: 0;">Escribe un comentario</label>
                        <textarea id="area-comentario" name="comentario" class="input-textarea" placeholder="Escribe un comentario respetuoso sobre esta publicación..." required></textarea>
                        <button type="submit" class="btn-enviar-comentario">Enviar Comentario</button>
                    </form>

                    <ul class="lista-comentarios">
                        <?php if (!empty($comentarios)): ?>
                            <?php foreach ($comentarios as $comentario): ?>
                                <li class="comentario-item">
                                    <img class="comentario-item__avatar" src="<?= !empty($comentario['avatar_url']) ? htmlspecialchars($comentario['avatar_url']) : '/uploads/avatars/default-avatar.png' ?>" alt="Avatar de <?= htmlspecialchars($comentario['nombre_app'] ?? 'Anónimo') ?>">
                                    <div class="comentario-item__contenido">
                                        <div class="comentario-item__meta">
                                            <span class="comentario-item__autor"><?= htmlspecialchars($comentario['nombre_app'] ?? 'Anónimo') ?></span>
                                            <span class="comentario-item__fecha"><time datetime="<?= htmlspecialchars($comentario['creado_en'] ?? '') ?>"><?= htmlspecialchars($comentario['creado_en'] ?? '') ?></time></span>
                                        </div>
                                        <p class="comentario-item__texto"><?= htmlspecialchars($comentario['contenido']) ?></p>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="sin-comentarios">
                                <p>Aún no hay comentarios en este hilo. ¡Sé el primero en aportar!</p>
                            </li>
                        <?php endif; ?>
                    </ul>
                </section>
            <?php else: ?>
                <div class="alerta alerta--error" role="alert">No se ha encontrado la publicación solicitada en el ecosistema.</div>
            <?php endif; ?>

        </main>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <p class="pie-pagina__copiar"><small>© 2026 All Dance Together. Todos los derechos reservados.</small></p>
    </footer>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const btnActivar = document.getElementById("btn-activar-edicion");
        const btnCancelar = document.getElementById("btn-cancelar-edicion");
        const bloqueLectura = document.getElementById("modo-lectura");
        const bloqueEdicion = document.getElementById("modo-edicion");
        const primerInput = document.getElementById("txt-titulo");

        if (btnActivar && btnCancelar) {
            btnActivar.addEventListener("click", function() {
                bloqueLectura.style.display = "none";
                bloqueEdicion.style.display = "block";
                btnActivar.setAttribute("aria-expanded", "true");
                
                // Envía el foco de forma automática para mejorar el flujo en lectores de pantalla
                if (primerInput) primerInput.focus();
            });

            btnCancelar.addEventListener("click", function() {
                bloqueEdicion.style.display = "none";
                bloqueLectura.style.display = "block";
                btnActivar.setAttribute("aria-expanded", "false");
                btnActivar.focus();
            });
        }
    });
    </script>
</body>
</html>