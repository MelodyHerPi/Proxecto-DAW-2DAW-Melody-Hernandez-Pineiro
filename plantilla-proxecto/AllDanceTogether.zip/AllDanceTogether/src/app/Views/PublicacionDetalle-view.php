<?php
/**
 * Vista del Detalle de Publicación y Comentarios.
 * * Renderiza la vista detallada de un evento o publicación específica de la comunidad,
 * proporcionando la interfaz para la lectura, edición inline o eliminación del post, junto con
 * un sistema interactivo de gestión de comentarios cronológicos con validaciones de autoría.
 */

$titulo_pagina     = isset($publicacion['titulo'])
    ? htmlspecialchars($publicacion['titulo'], ENT_QUOTES, 'UTF-8')
    : 'Detalle de Publicación';
$id_usuario_sesion = $_SESSION['usuario']['id'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title><?= $titulo_pagina ?> — All Dance Together</title>
    <link rel="stylesheet" href="/css/PublicacionDetalle.css">
        <link rel="stylesheet" href="/css/Global.css">
</head>
<body>

    <h1 class="sr-only">All Dance Together</h1>
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <?php include_once(__DIR__ . '/partials/header.php'); ?>

    <div class="contenedor-principal">

        <?php include_once(__DIR__ . '/partials/menu.php'); ?>

        <main class="principal" id="contenido-principal">

            <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito" role="alert">
                    <?= htmlspecialchars($_SESSION['msg_exito'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['msg_exito']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error" role="alert">
                    <?= htmlspecialchars($_SESSION['msg_error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['msg_error']); ?>
                </div>
            <?php endif; ?>

            <a href="/descubrir" class="enlace-volver">
                <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>
                </svg>
                Volver a Descubrir
            </a>

            <?php if (!empty($publicacion)):
                $tipo_publicacion = $publicacion['tipo'] ?? 'evento';
                $es_dueno = isset($publicacion['id_creador']) && $id_usuario_sesion == $publicacion['id_creador'];
            ?>

                <article class="seccion-detalle" aria-labelledby="titulo-publicacion">

                    <figure class="seccion-detalle__hero">
                        <span class="badge-tipo badge-tipo--<?= htmlspecialchars($tipo_publicacion) ?>">
                            <?= htmlspecialchars($tipo_publicacion) ?>
                        </span>
                        <?php if (!empty($publicacion['foto_url'])): ?>
                            <img class="seccion-detalle__img"
                                 src="<?= htmlspecialchars($publicacion['foto_url'], ENT_QUOTES, 'UTF-8') ?>"
                                 alt="Imagen de <?= htmlspecialchars($publicacion['titulo'], ENT_QUOTES, 'UTF-8') ?>">
                        <?php else: ?>
                            <div class="seccion-detalle__img seccion-detalle__img--placeholder" aria-hidden="true">
                                <span class="placeholder-inicial">
                                    <?= htmlspecialchars(mb_strtoupper(mb_substr($publicacion['titulo'], 0, 1, 'UTF-8'), 'UTF-8')) ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </figure>

                    <div class="seccion-detalle__cuerpo" id="modo-lectura">
                        <header class="seccion-detalle__header-acciones">
                            <h1 id="titulo-publicacion" class="seccion-detalle__titulo">
                                <?= htmlspecialchars($publicacion['titulo']) ?>
                            </h1>
                            <?php if ($es_dueno): ?>
    <div class="acciones-dueno">
        <button type="button" class="btn-editar-propio"
                id="btn-activar-edicion"
                aria-expanded="false"
                aria-controls="modo-edicion">
            <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
            </svg>
            Editar
        </button>

        <form action="/descubrir/eliminarPublicacion" method="POST" class="form-eliminar-inline">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="id" value="<?= (int)$publicacion['id'] ?>">
            <button type="submit" class="btn-eliminar"
                    onclick="return confirm('¿Eliminar esta publicación? Esta acción no se puede deshacer.')">
                <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                </svg>
                Eliminar
            </button>
        </form>
    </div>
<?php endif; ?>
                        </header>

                        <dl class="seccion-detalle__meta">
                            <?php if (!empty($publicacion['lugar'])): ?>
                                <div class="meta-grupo">
                                    <dt aria-label="Ubicación">
                                        <svg class="svg-icon svg-icon--rosa" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                        </svg>
                                    </dt>
                                    <dd><?= htmlspecialchars($publicacion['lugar']) ?></dd>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($publicacion['fecha'])): ?>
                                <div class="meta-grupo">
                                    <dt aria-label="Fecha del evento">
                                        <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>
                                        </svg>
                                    </dt>
                                    <dd>
                                        <time datetime="<?= htmlspecialchars($publicacion['fecha'], ENT_QUOTES, 'UTF-8') ?>">
                                            <?= htmlspecialchars(date('d/m/Y · H:i', strtotime($publicacion['fecha']))) ?>
                                        </time>
                                    </dd>
                                </div>
                            <?php endif; ?>
                        </dl>

                        <p class="seccion-detalle__descripcion">
                            <?= htmlspecialchars($publicacion['descripcion']) ?>
                        </p>
                    </div>

                    <?php if ($es_dueno): ?>
                        <section class="seccion-detalle__cuerpo seccion-detalle__cuerpo--edicion"
                                 id="modo-edicion"
                                 aria-labelledby="cabecera-edicion"
                                 hidden>
                            <h2 id="cabecera-edicion" class="edicion__titulo">Modificar Publicación</h2>

                            <form action="/descubrir/procesarEditar" method="POST"
                                  enctype="multipart/form-data" class="formulario-edicion">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <input type="hidden" name="id" value="<?= (int)$publicacion['id'] ?>">
                                <div class="grupo-campo">
                                    <label for="txt-titulo">Título de la publicación</label>
                                    <input type="text" id="txt-titulo" name="titulo"
                                        class="input-textarea input-textarea--linea"
                                        value="<?= htmlspecialchars($publicacion['titulo']) ?>" required>
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-lugar">Ubicación / Lugar</label>
                                    <input type="text" id="txt-lugar" name="lugar"
                                        class="input-textarea input-textarea--linea"
                                        value="<?= htmlspecialchars($publicacion['lugar'] ?? '') ?>">
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-fecha">Fecha y hora (opcional)</label>
                                    <input type="datetime-local" id="txt-fecha" name="fecha"
                                        class="input-textarea input-textarea--linea"
                                        value="<?= !empty($publicacion['fecha']) ? htmlspecialchars(date('Y-m-d\TH:i', strtotime($publicacion['fecha']))) : '' ?>">
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-descripcion">Descripción o Contenido</label>
                                    <textarea id="txt-descripcion" name="descripcion"
                                            class="input-textarea" rows="6"
                                            required><?= htmlspecialchars($publicacion['descripcion']) ?></textarea>
                                </div>

                                <div class="grupo-campo">
                                    <label for="file-foto">Cambiar imagen de portada</label>
                                    <input type="file" id="file-foto" name="foto"
                                        class="input-textarea input-textarea--linea"
                                        accept="image/*">
                                </div>

                                <div class="acciones-fila">
                                    <button type="button" id="btn-cancelar-edicion" class="btn-cancelar">
                                        Cancelar
                                    </button>
                                    <button type="submit" class="btn-enviar-comentario btn-enviar-comentario--sm">
                                        Guardar Cambios
                                    </button>
                                </div>
                            </form>
                        </section>
                    <?php endif; ?>

                </article>

                <section class="seccion-comentarios" aria-label="Comentarios">
                    <h2 class="seccion-comentarios__titulo">Comentarios de la comunidad</h2>

                    <form action="/descubrir/comentar" method="POST" class="formulario-comentario">
                        <input type="hidden" name="csrf_token"      value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="id_publicacion"  value="<?= (int)$publicacion['id'] ?>">
                        <label for="area-comentario" class="sr-only">Escribe un comentario</label>
                        <textarea id="area-comentario" name="contenido" class="input-textarea"
                                  placeholder="Escribe un comentario respetuoso..." required></textarea>
                        <button type="submit" class="btn-enviar-comentario">Enviar Comentario</button>
                    </form>

                    <ul class="lista-comentarios">
                        <?php if (!empty($comentarios)): ?>
                            <?php foreach ($comentarios as $comentario):
                                $es_autor_comentario  = (int)$comentario['id_usuario'] === (int)$id_usuario_sesion;
                                $es_dueno_publicacion = (int)$publicacion['id_creador'] === (int)$id_usuario_sesion;
                                $puede_eliminar       = $es_autor_comentario || $es_dueno_publicacion;
                            ?>
                                <li class="comentario-item" id="comentario-<?= $comentario['id'] ?>">

                            <?php
                                $nombre_comentario = $comentario['nombre_app'] ?? '';
                                $inicial_comentario = $nombre_comentario !== ''
                                    ? htmlspecialchars(mb_strtoupper(mb_substr($nombre_comentario, 0, 1, 'UTF-8'), 'UTF-8'))
                                    : '?';
                            ?>

                        <?php require_once __DIR__ . '/../../core/Helper.php'; ?>
                        <?php
                            $avatar       = $comentario['avatar_url'] ?? '';
                            $tiene_avatar = tieneFotoValida($avatar);
                        ?>
                        <?php if ($tiene_avatar): ?>
                            <img class="comentario-item__avatar"
                                src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8') ?>"
                                alt="<?= $inicial_comentario ?>">
                        <?php else: ?>
                            <div style="width:40px;height:40px;border-radius:50%;background:#e91e8c;color:#fff;font-weight:700;font-size:1.1rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;" aria-hidden="true"><?= $inicial_comentario ?></div>
                        <?php endif; ?>
                            
        <div class="comentario-item__contenido">
            <div class="comentario-item__meta">
                <span class="comentario-item__autor">
                    <?= htmlspecialchars($comentario['nombre_app'] ?? 'Anónimo') ?>
                </span>
<time class="comentario-item__fecha"
      datetime="<?= htmlspecialchars($comentario['creado_en'] ?? '') ?>">
    <?= htmlspecialchars(date('d/m/Y · H:i', strtotime($comentario['creado_en'] ?? ''))) ?>
</time>

                <div class="comentario-item__acciones">
                    <?php if ($es_autor_comentario): ?>
                        <button type="button"
                                class="btn-accion-comentario btn-editar-comentario"
                                data-id="<?= $comentario['id'] ?>"
                                aria-label="Editar comentario">
                            <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                            </svg>
                        </button>
                    <?php endif; ?>

                    <?php if ($puede_eliminar): ?>
                        <form action="/descubrir/eliminarComentario" method="POST" class="form-eliminar-inline">
                            <input type="hidden" name="csrf_token"      value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="id_comentario"   value="<?= $comentario['id'] ?>">
                            <input type="hidden" name="id_publicacion"  value="<?= (int)$publicacion['id'] ?>">
                            <button type="submit"
                                    class="btn-accion-comentario btn-eliminar-comentario"
                                    aria-label="Eliminar comentario"
                                    onclick="return confirm('¿Eliminar este comentario?')">
                                <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                                    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                                </svg>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Modo lectura del comentario -->
            <p class="comentario-item__texto" id="texto-<?= $comentario['id'] ?>">
                <?= htmlspecialchars($comentario['contenido']) ?>
            </p>

            <!-- Modo edición del comentario (oculto por defecto) -->
            <?php if ($es_autor_comentario): ?>
                <form action="/descubrir/editarComentario" method="POST"
                      class="formulario-editar-comentario"
                      id="form-editar-<?= $comentario['id'] ?>"
                      hidden>
                    <input type="hidden" name="csrf_token"     value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="id_comentario"  value="<?= $comentario['id'] ?>">
                    <input type="hidden" name="id_publicacion" value="<?= (int)$publicacion['id'] ?>">
                    <textarea name="contenido"
                              class="input-textarea input-textarea--comentario"
                              rows="3"
                              required><?= htmlspecialchars($comentario['contenido']) ?></textarea>
                    <div class="acciones-fila acciones-fila--comentario">
                        <button type="button"
                                class="btn-cancelar btn-cancelar-edicion-comentario"
                                data-id="<?= $comentario['id'] ?>">Cancelar</button>
                        <button type="submit" class="btn-enviar-comentario btn-enviar-comentario--sm">
                            Guardar
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </li>
<?php endforeach; ?>
                        <?php else: ?>
                            <li class="sin-comentarios">
                                <p>Aún no hay comentarios. ¡Sé el primero en aportar!</p>
                            </li>
                        <?php endif; ?>
                    </ul>
                </section>

            <?php else: ?>
                <div class="alerta alerta--error" role="alert">
                    No se ha encontrado la publicación solicitada.
                </div>
            <?php endif; ?>

        </main>
    </div>

    <?php include_once(__DIR__ . '/partials/footer.php'); ?>

    <script src="/js/DescubrirDetalle.js"></script>
</body>
</html>