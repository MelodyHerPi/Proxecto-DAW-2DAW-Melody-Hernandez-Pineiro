<?php
// Extracción de datos de sesión adaptados a tu estructura estándar
$nombre_usuario = htmlspecialchars($_SESSION['usuario']['nombre_app'] ?? 'Usuario');
$id_usuario_sesion = $_SESSION['usuario']['id'] ?? null;

// Sanitización del avatar de cabecera
$foto_perfil_cruda = $perfil['foto_url'] ?? $_SESSION['usuario']['foto_url'] ?? '';
if (!empty($foto_perfil_cruda)) {
    $avatar_cabecera = (strpos($foto_perfil_cruda, '/public') === 0) ? substr($foto_perfil_cruda, 7) : $foto_perfil_cruda;
} else {
    $avatar_cabecera = '/uploads/avatars/default-avatar.png';
}

// Datos de la publicación inyectados por el controlador
$titulo_pagina = isset($publicacion['titulo']) ? htmlspecialchars($publicacion['titulo']) : 'Detalle de Publicación';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $titulo_pagina ?> — All Dance Together</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/css/PublicacionDetalle.css">
</head>
<body>

    <header class="cabecera">
        <button class="cabecera__menu-btn" id="btn-menu" aria-label="Abrir menú de navegación">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><rect y="3" width="20" height="2"/><rect y="9" width="20" height="2"/><rect y="15" width="20" height="2"/></svg>
        </button>
        <a href="/inicio" class="cabecera__marca">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <button class="cabecera__perfil" aria-label="Ver perfil de usuario">
            <span><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img class="cabecera__avatar-imagen" src="<?= $avatar_cabecera ?>" alt="">
            </span>
        </button>
    </header>

    <div class="contenedor-principal">
        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
            <ul class="navegacion-lateral__lista">
                <li>
                    <a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/inicio" aria-current="page">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/eventos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/usuarios">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/perfil">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/logout"
                    onclick="return confirm('¿Seguro que quieres cerrar sesión?')">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                            <polyline points="16 17 21 12 16 7"/>
                            <line x1="21" y1="12" x2="9" y2="12"/>
                        </svg>
                        Cerrar sesión
                    </a>
                </li>
            </ul>
        </nav>

        <div class="overlay-sidebar" id="overlay-sidebar" role="presentation"></div>

        <main class="principal" id="contenido-principal">
            
            <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito" role="alert"><?= $_SESSION['msg_exito']; unset($_SESSION['msg_exito']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error" role="alert"><?= $_SESSION['msg_error']; unset($_SESSION['msg_error']); ?></div>
            <?php endif; ?>

            <a href="/descubrir" class="enlace-volver">
                <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                Volver a Descubrir
            </a>

            <?php if (!empty($publicacion)): ?>
                <?php 
                    $tipo_publicacion = $publicacion['tipo'] ?? 'evento'; 
                    $es_dueno = (isset($publicacion['id_creador']) && $id_usuario_sesion == $publicacion['id_creador']);
                ?>
                
                <article class="seccion-detalle" aria-labelledby="titulo-publicacion">
                    <figure class="seccion-detalle__hero">
                        <span class="badge-tipo badge-tipo--<?= htmlspecialchars($tipo_publicacion) ?>">
                            <?= htmlspecialchars($tipo_publicacion) ?>
                        </span>
                        <?php if (!empty($publicacion['foto_url'])): ?>
                            <img class="seccion-detalle__img" src="<?= htmlspecialchars($publicacion['foto_url']) ?>" alt="Imagen de cabecera para <?= htmlspecialchars($publicacion['titulo']) ?>">
                        <?php else: ?>
                            <img class="seccion-detalle__img" src="/uploads/default-placeholder.jpg" alt="Imagen predeterminada del ecosistema">
                        <?php endif; ?>
                    </figure>

                    <div class="seccion-detalle__cuerpo" id="modo-lectura">
                        <header class="seccion-detalle__header-acciones">
                            <h1 id="titulo-publicacion" class="seccion-detalle__titulo"><?= htmlspecialchars($publicacion['titulo']) ?></h1>
                            
                            <?php if ($es_dueno): ?>
                                <button type="button" class="btn-editar-propio" id="btn-activar-edicion" aria-expanded="false" aria-controls="modo-edicion">
                                    <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                    Editar
                                </button>
                            <?php endif; ?>
                        </header>
                        
                        <dl class="seccion-detalle__meta">
                            <?php if(!empty($publicacion['lugar'])): ?>
                                <div class="meta-grupo">
                                    <dt aria-label="Ubicación"><svg class="svg-icon" viewBox="0 0 24 24" style="color: #ec4899;" aria-hidden="true"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg></dt>
                                    <dd><?= htmlspecialchars($publicacion['lugar']) ?></dd>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($publicacion['fecha'])): ?>
                                <div class="meta-grupo">
                                    <dt aria-label="Fecha del evento"><svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/></svg></dt>
                                    <dd><time datetime="<?= htmlspecialchars($publicacion['fecha']) ?>"><?= htmlspecialchars($publicacion['fecha']) ?></time></dd>
                                </div>
                            <?php endif; ?>
                        </dl>

                        <p class="seccion-detalle__descripcion"><?= htmlspecialchars($publicacion['descripcion']) ?></p>
                    </div>

                    <?php if ($es_dueno): ?>
                        <section class="seccion-detalle__cuerpo" id="modo-edicion" style="display: none;" aria-labelledby="cabecera-edicion">
                            <h2 id="cabecera-edicion" style="font-family: var(--fuente-titulo); margin-bottom: 1.5rem; font-size: 1.5rem;">Modificar Publicación</h2>
                            
                            <form action="/descubrir/procesarEditar" method="POST" enctype="multipart/form-data" class="formulario-edicion">
                                <input type="hidden" name="id" value="<?= (int)$publicacion['id'] ?>">

                                <div class="grupo-campo">
                                    <label Lothar for="txt-titulo">Título de la publicación</label>
                                    <input type="text" id="txt-titulo" name="titulo" class="input-textarea" style="min-height: auto; padding: 0.75rem;" value="<?= htmlspecialchars($publicacion['titulo']) ?>" required>
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-lugar">Ubicación / Lugar</label>
                                    <input type="text" id="txt-lugar" name="lugar" class="input-textarea" style="min-height: auto; padding: 0.75rem;" value="<?= htmlspecialchars($publicacion['lugar'] ?? '') ?>">
                                </div>

                                <div class="grupo-campo">
                                    <label for="txt-descripcion">Descripción o Contenido</label>
                                    <textarea id="txt-descripcion" name="descripcion" class="input-textarea" rows="6" required><?= htmlspecialchars($publicacion['descripcion']) ?></textarea>
                                </div>

                                <div class="grupo-campo">
                                    <label Lothar for="file-foto">Cambiar imagen de portada</label>
                                    <input type="file" id="file-foto" name="foto" class="input-textarea" style="min-height: auto; padding: 0.5rem;" accept="image/*">
                                </div>

                                <div class="acciones-fila" style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 0.5rem;">
                                    <button type="button" id="btn-cancelar-edicion" style="background: transparent; color: var(--color-texto-suave); border: 1px solid var(--color-borde); padding: 0.6rem 1.2rem; border-radius: 8px; cursor: pointer; font-family: inherit; font-size: 0.85rem;">
                                        Cancelar
                                    </button>
                                    <button type="submit" class="btn-enviar-comentario" style="align-self: auto; padding: 0.6rem 1.5rem; font-size: 0.85rem; margin: 0;">
                                        Guardar Cambios
                                    </button>
                                </div>
                            </form>
                        </section>
                    <?php endif; ?>
                </article>

                <section class="seccion-comentarios" aria-label="Sección de comentarios">
                    <h2 class="seccion-comentarios__titulo">Comentarios de la comunidad</h2>

                    <form action="/descubrir/comentar" method="POST" class="formulario-comentario" aria-label="Deja un comentario">
                        <input type="hidden" name="publicacion_id" value="<?= (int)$publicacion['id'] ?>">
                        <label for="area-comentario" class="sr-only" style="position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); border: 0;">Escribe un comentario</label>
                        <textarea id="area-comentario" name="comentario" class="input-textarea" placeholder="Escribe un comentario respetuoso sobre esta publicación..." required></textarea>
                        <button type="submit" class="btn-enviar-comentario">Enviar Comentario</button>
                    </form>

                    <ul class="lista-comentarios">
                        <?php if (!empty($comentarios)): ?>
                            <?php foreach ($comentarios as $comentario): ?>
                                <li class="comentario-item">
                                    <img class="comentario-item__avatar" src="<?= !empty($comentario['avatar_url']) ? htmlspecialchars($comentario['avatar_url']) : '/uploads/avatars/default-avatar.png' ?>" alt="Avatar de <?= htmlspecialchars($comentario['nombre_app'] ?? 'Anónimo') ?>">
                                    <div class="comentario-item__contenido">
                                        <div class="comentario-item__meta">
                                            <span class="comentario-item__autor"><?= htmlspecialchars($comentario['nombre_app'] ?? 'Anónimo') ?></span>
                                            <span class="comentario-item__fecha"><time datetime="<?= htmlspecialchars($comentario['creado_en'] ?? '') ?>"><?= htmlspecialchars($comentario['creado_en'] ?? '') ?></time></span>
                                        </div>
                                        <p class="comentario-item__texto"><?= htmlspecialchars($comentario['contenido']) ?></p>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="sin-comentarios">
                                <p>Aún no hay comentarios en este hilo. ¡Sé el primero en aportar!</p>
                            </li>
                        <?php endif; ?>
                    </ul>
                </section>
            <?php else: ?>
                <div class="alerta alerta--error" role="alert">No se ha encontrado la publicación solicitada en el ecosistema.</div>
            <?php endif; ?>

        </main>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <p class="pie-pagina__copiar"><small>© 2026 All Dance Together. Todos los derechos reservados.</small></p>
    </footer>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const btnActivar = document.getElementById("btn-activar-edicion");
        const btnCancelar = document.getElementById("btn-cancelar-edicion");
        const bloqueLectura = document.getElementById("modo-lectura");
        const bloqueEdicion = document.getElementById("modo-edicion");
        const primerInput = document.getElementById("txt-titulo");

        if (btnActivar && btnCancelar) {
            btnActivar.addEventListener("click", function() {
                bloqueLectura.style.display = "none";
                bloqueEdicion.style.display = "block";
                btnActivar.setAttribute("aria-expanded", "true");
                
                // Envía el foco de forma automática para mejorar el flujo en lectores de pantalla
                if (primerInput) primerInput.focus();
            });

            btnCancelar.addEventListener("click", function() {
                bloqueEdicion.style.display = "none";
                bloqueLectura.style.display = "block";
                btnActivar.setAttribute("aria-expanded", "false");
                btnActivar.focus();
            });
        }
    });
    </script>
</body>
</html>