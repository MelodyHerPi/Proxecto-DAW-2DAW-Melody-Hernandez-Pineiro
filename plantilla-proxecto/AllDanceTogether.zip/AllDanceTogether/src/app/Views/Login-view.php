<?php 
/**
 * Vista del Formulario de Inicio de Sesión (Login).
 * * Renderiza la interfaz de autenticación para los usuarios de la plataforma,
 * integrando validación y manejo de errores de credenciales, protección CSRF y 
 * scripts interactivos accesibles para alternar la visibilidad de la contraseña.
 */

// evitamos tener un problema con el aria-describedby vacío si es null
$ariaDescribedBy = isset($_GET['error']) ? 'aria-describedby="error-auth"' : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Inicia sesión en All Dance Together para acceder a tu cuenta y gestionar tu perfil en la comunidad de grupos de covers de Galicia.">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>All Dance Together - Iniciar sesión</title>
    <link rel="stylesheet" href="/css/LoginRegister.css">
    <link rel="stylesheet" href="/css/Global.css">
</head>
<body>
    <h1 class="sr-only">All Dance Together</h1>

    <!-- Enlace de saltar contenido como primer elemento interactivo para cumplir con la accesibilidad web -->
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>

    <!-- header -->
    <?php include_once(__DIR__.'/partials/header_log.php'); ?>

    <!-- Pagina principal -->
    <main class="principal" id="contenido-principal">

        <section class="seccion-acceso" aria-labelledby="titulo-acceso">

            <h2 id="titulo-acceso" class="seccion-acceso__titulo">Iniciar sesión</h1>
            <p class="seccion-acceso__subtitulo">Entra en la comunidad de grupos de covers de toda Galicia.</p>

            <!-- Mensaje en caso de que pongan datos incorrectos -->
            <?php if (isset($_GET['error']) && $_GET['error'] === 'auth'): ?>
            <div class="aviso" role="alert" id="error-auth">
                <span>Tu usuario o contraseña no son correctos.</span>
                <button type="button" class="aviso__cerrar" aria-label="Cerrar aviso" onclick="this.parentElement.remove()">✕</button>
            </div>
            <?php endif; ?>

            <form class="formulario-acceso" action="/login/inicio" method="POST">
                <!-- token de seguridad -->
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>"> 

                <div class="campo">
                    <label class="campo__etiqueta" for="usuario">Correo electrónico o Usuario</label>
                    <input
                        class="campo__entrada"
                        type="text"
                        id="usuario"
                        name="usuario"
                        placeholder="Ej: mariana@email.com"
                        required
                        autocomplete="username"
                        <?php echo $ariaDescribedBy; ?>
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="contrasena">Contraseña</label>
                    <input
                        class="campo__entrada"
                        type="password"
                        id="contrasena"
                        name="password"
                        placeholder="Introduce tu contraseña"
                        required
                        autocomplete="current-password"
                    >
                    <button
                        type="button"
                        class="campo__boton-visibilidad"
                        id="btn-ver-pass"
                        aria-label="Mostrar contraseña"
                        aria-pressed="false"
                        onclick="togglePassword()"
                    >
                        VER
                    </button>
                </div>

                <button class="boton-entrar" type="submit">
                    Iniciar sesión
                </button>

                <p class="enlace-registro">
                    <a class="enlace-registro__ancla" href="/registro">
                        ¿No tienes cuenta? <strong>Regístrate</strong>
                    </a>
                </p>

            </form>

        </section>

    </main>

    <!-- footer -->
    <?php include_once(__DIR__.'/partials/footer_log.php'); ?>

    <script>
        function togglePassword() {
            const input = document.getElementById('contrasena');
            const btn = document.getElementById('btn-ver-pass');
            if (input.type === 'password') {
                input.type = 'text';
                btn.setAttribute('aria-pressed', 'true');
                btn.innerText = 'OCULTAR';
                btn.setAttribute('aria-label', 'Ocultar contraseña');
            } else {
                input.type = 'password';
                btn.setAttribute('aria-pressed', 'false');
                btn.innerText = 'VER';
                btn.setAttribute('aria-label', 'Mostrar contraseña');
            }
        }
    </script>
</body>
</html>