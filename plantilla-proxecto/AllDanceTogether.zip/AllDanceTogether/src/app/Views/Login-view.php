<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Dance Together - Iniciar sesión</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght=400;500;600&family=Poppins:wght=600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/LoginRegister.css">
</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir a la página de inicio de All Dance Together">
            <p class="cabecera__nombre">All Dance Together</p>
        </a>
    </header>

    <main class="principal" id="contenido-principal">

        <section class="seccion-acceso" aria-labelledby="titulo-acceso">

            <h1 id="titulo-acceso" class="seccion-acceso__titulo">Iniciar sesión</h1>
            <p class="seccion-acceso__subtitulo">Entra en la comunidad de grupos de covers de toda Galicia.</p>

            <?php if (isset($_GET['error']) && $_GET['error'] === 'auth'): ?>
            <div class="aviso" role="alert" id="error-auth">
                <span>Tu usuario o contraseña no son correctos.</span>
                <button type="button" class="aviso__cerrar" aria-label="Cerrar aviso" onclick="this.parentElement.remove()">✕</button>
            </div>
            <?php endif; ?>

            <form class="formulario-acceso" action="/login/inicio" method="POST">

                <div class="campo">
                    <label class="campo__etiqueta" for="usuario">Correo electrónico o Usuario</label>
                    <input
                        class="campo__entrada"
                        type="text"
                        id="usuario"
                        name="usuario"
                        placeholder="Ej: mariana@email.com"
                        required
                        autocomplete="username"
                        aria-describedby="<?php echo isset($_GET['error']) ? 'error-auth' : ''; ?>"
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="contrasena">Contraseña</label>
                    <input
                        class="campo__entrada"
                        type="password"
                        id="contrasena"
                        name="password"
                        placeholder="Introduce tu contraseña"
                        required
                        autocomplete="current-password"
                    >
                    <button
                        type="button"
                        class="campo__boton-visibilidad"
                        id="btn-ver-pass"
                        aria-label="Mostrar contraseña"
                        aria-pressed="false"
                        onclick="togglePassword()"
                    >
                        VER
                    </button>
                </div>

                <button class="boton-entrar" type="submit">
                    Iniciar sesión
                </button>

                <p class="enlace-registro">
                    <a class="enlace-registro__ancla" href="/registro">
                        ¿No tienes cuenta? <strong>Regístrate</strong>
                    </a>
                </p>

            </form>

        </section>

    </main>

    <footer class="pie-pagina">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/politicas">Políticas de Privacidad</a></li>
            </ul>
        </nav>
    </footer>

    <script>
        function togglePassword() {
            const input = document.getElementById('contrasena');
            const btn = document.getElementById('btn-ver-pass');
            if (input.type === 'password') {
                input.type = 'text';
                btn.setAttribute('aria-pressed', 'true');
                btn.innerText = 'OCULTAR';
                btn.setAttribute('aria-label', 'Ocultar contraseña');
            } else {
                input.type = 'password';
                btn.setAttribute('aria-pressed', 'false');
                btn.innerText = 'VER';
                btn.setAttribute('aria-label', 'Mostrar contraseña');
            }
        }
    </script>
</body>
</html>