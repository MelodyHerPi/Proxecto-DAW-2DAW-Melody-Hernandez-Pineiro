<?php
/**
 * Vista Comodín / Pantalla de Error y Mantenimiento.
 * * Renderiza de forma dinámica páginas de estado (como errores HTTP o secciones en desarrollo),
 * adaptando el código de estado, íconos, textos y acciones según las variables del controlador.
 */
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo ?? 'En mantenimiento') ?> – All Dance Together</title>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&family=Poppins:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="css/Comodin.css">
</head>

<body>

    <canvas id="bg-canvas" aria-hidden="true"></canvas>

    <main id="main-content">
        <div class="card" role="main">

            <span class="card__icon" aria-hidden="true">
                <i class="bi <?= htmlspecialchars($icono ?? 'bi-tools') ?>"></i>
            </span>

            <?php if (!empty($codigo)): ?>
                <span class="card__code" aria-label="Código de error <?= htmlspecialchars($codigo) ?>">
                    <?= htmlspecialchars($codigo) ?>
                </span>
            <?php endif; ?>

            <h1 class="card__title">
                <?= htmlspecialchars($titulo ?? 'En mantenimiento') ?>
            </h1>

            <div class="card__divider" role="presentation"></div>

            <p class="card__desc">
                <?= htmlspecialchars($mensaje ?? 'Estamos haciendo mejoras. Volvemos enseguida.') ?>
            </p>

            <a href="<?= htmlspecialchars($btnUrl ?? '/') ?>" class="btn-home">
                <i class="bi <?= htmlspecialchars($btnIcono ?? 'bi-house') ?>" aria-hidden="true"></i>
                <?= htmlspecialchars($btnTexto ?? 'Volver al inicio') ?>
            </a>

        </div>
    </main>

    <a href="/" class="brand" aria-label="All Dance Together">
        <img src="/assets/img/logo.png" alt="" class="brand__img" aria-hidden="true">
        <span class="brand__name">All Dance Together</span>
    </a>

    <script src="/js/EfectosLogin.js"></script>

</body>
</html>