<?php
/**
 * Vista de los Términos de Uso y Condiciones de la Plataforma.
 * * Renderiza el marco regulatorio legal y normativo del sitio bajo la legislación española,
 * detallando los compromisos del usuario, políticas de propiedad intelectual, pautas de conducta 
 * comunitaria y exenciones de responsabilidad del proyecto académico (TFC).
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Términos de Uso — All Dance Together</title>
    <meta name="description" content="Términos y condiciones de uso de la plataforma All Dance Together.">
    
    <link rel="stylesheet" href="/css/PaginasComunes.css">
</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <a href="javascript:history.back()" class="cabecera__volver" aria-label="Volver a la página anterior">
            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"/>
            </svg>
            Volver
        </a>
    </header>

    <main class="principal" id="contenido-principal">

        <div class="seccion-cabecera">
            <span class="seccion-cabecera__etiqueta">Legal</span>
            <h1 class="seccion-cabecera__titulo">
                Términos de <span>Uso</span>
            </h1>
            <p class="seccion-cabecera__fecha">Última actualización: enero de 2026</p>
        </div>

        <!-- Aviso menores -->
        <div class="aviso-destacado" role="note" aria-label="Aviso sobre acceso de menores">
            <svg class="aviso-destacado__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            <div class="aviso-destacado__cuerpo">
                <p class="aviso-destacado__titulo">Plataforma exclusiva para mayores de 18 años</p>
                <p class="aviso-destacado__texto">
                    El acceso y registro en All Dance Together está restringido a personas mayores de 18 años. Al usar la plataforma confirmas que cumples este requisito. Si eres menor de edad, abandona la plataforma y, si lo necesitas, solicita a un adulto responsable que gestione cualquier consulta en tu nombre.
                </p>
            </div>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">1. Aceptación de los términos</h2>
            <p class="bloque__texto">
                Al acceder, registrarte o utilizar All Dance Together aceptas quedar vinculado por estos Términos de Uso. Si no estás de acuerdo con alguno de ellos, no debes utilizar la plataforma. Esta plataforma es un proyecto académico (TFC) sin actividad comercial.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">2. Cuenta de usuario</h2>
            <ul class="bloque__lista">
                <li>Debes proporcionar datos verídicos durante el registro. No se permite crear cuentas con identidades falsas o suplantar a terceros.</li>
                <li>Eres responsable de mantener la confidencialidad de tu contraseña y de todas las actividades realizadas desde tu cuenta.</li>
                <li>Puedes eliminar tu cuenta en cualquier momento desde los ajustes de perfil.</li>
                <li>Nos reservamos el derecho de suspender o eliminar cuentas que incumplan estos términos.</li>
            </ul>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">3. Conducta del usuario</h2>
            <p class="bloque__texto">Al usar la plataforma te comprometes a no:</p>
            <ul class="bloque__lista">
                <li>Publicar contenido ofensivo, discriminatorio, violento, pornográfico o que incite al odio.</li>
                <li>Subir imágenes de otras personas sin su consentimiento expreso.</li>
                <li>Acosar, intimidar o amenazar a otros usuarios.</li>
                <li>Utilizar la plataforma para actividades ilegales o comerciales no autorizadas.</li>
                <li>Intentar acceder a cuentas ajenas o vulnerar la seguridad de la plataforma.</li>
                <li>Publicar spam, enlaces maliciosos o contenido publicitario no solicitado.</li>
            </ul>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">4. Contenido publicado</h2>
            <p class="bloque__texto">
                Eres el único responsable del contenido que publiques (textos, imágenes, eventos, etc.). Al publicarlo, declaras que tienes los derechos necesarios para hacerlo y que no infringe derechos de terceros.
            </p>
            <p class="bloque__texto">
                All Dance Together no se responsabiliza del contenido generado por los usuarios, pero actuará con diligencia ante cualquier reclamación, procediendo a retirar el contenido denunciado si así lo estima oportuno.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">5. Propiedad intelectual</h2>
            <p class="bloque__texto">
                El diseño, código fuente y contenidos propios de la plataforma son propiedad de All Dance Together y están protegidos por las leyes de propiedad intelectual. No está permitida su reproducción total o parcial sin autorización expresa.
            </p>
            <p class="bloque__texto">
                El contenido relacionado con artistas y grupos de K-pop (nombres, logotipos, fotografías) pertenece a sus respectivos titulares. All Dance Together no reclama ningún derecho sobre él.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">6. Disponibilidad del servicio</h2>
            <p class="bloque__texto">
                Al tratarse de un proyecto académico, la plataforma puede sufrir interrupciones por mantenimiento o actualizaciones sin previo aviso. No garantizamos disponibilidad continua del servicio.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">7. Limitación de responsabilidad</h2>
            <p class="bloque__texto">
                All Dance Together no se responsabiliza de los daños derivados del uso o la imposibilidad de uso de la plataforma, ni del contenido publicado por terceros. El uso de la plataforma es bajo la exclusiva responsabilidad del usuario.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">8. Legislación aplicable</h2>
            <p class="bloque__texto">
                Estos términos se rigen por la legislación española. Cualquier controversia se someterá a los juzgados y tribunales competentes del domicilio del usuario, salvo que la ley disponga otra cosa.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">9. Contacto</h2>
            <p class="bloque__texto">
                Para cualquier consulta relacionada con estos términos, puedes escribirnos a <a href="mailto:hola@alldancetogether.es" style="color: var(--color-principal);">hola@alldancetogether.es</a>.
            </p>
        </div>

    </main>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos" aria-current="page">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

</body>
</html>