<?php
// Extracción segura de datos pasados desde el PerfilController
$nombre_usuario = htmlspecialchars($_SESSION['usuario']['nick'] ?? 'Usuario');

// Capturamos la ruta que viene de la base de datos
$foto_perfil_cruda = $perfil['foto_url'] ?? '';

if (!empty($foto_perfil_cruda)) {
    // Si la ruta guardada incluye accidentalmente '/public', se lo removemos
    if (strpos($foto_perfil_cruda, '/public') === 0) {
        $avatar_cabecera = substr($foto_perfil_cruda, 7); // Quita '/public'
    } else {
        $avatar_cabecera = $foto_perfil_cruda; // Mantiene '/uploads/...' directo
    }
    $avatar_cabecera = htmlspecialchars($avatar_cabecera, ENT_QUOTES, 'UTF-8');
} else {
    // Si no hay foto, la ruta por defecto va sin el prefijo /public
    $avatar_cabecera = '/uploads/avatars/default-avatar.png';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio — All Dance Together</title>
    <meta name="description" content="Panel de inicio de All Dance Together. Accede a eventos, favoritos, usuarios y más.">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="/css/Menu.css">
    <link rel="stylesheet" href="/css/CabeceraPie.css"> -->
    <link rel="stylesheet" href="/css/Inicio.css">
</head>
<body>

    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <header class="cabecera" role="banner">
        <button
            class="cabecera__menu-btn"
            id="btn-menu"
            aria-expanded="false"
            aria-controls="sidebar-nav"
            aria-label="Abrir menú de navegación"
        >
            <svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect y="3"  width="20" height="2" rx="1" fill="currentColor"/>
                <rect y="9"  width="20" height="2" rx="1" fill="currentColor"/>
                <rect y="15" width="20" height="2" rx="1" fill="currentColor"/>
            </svg>
        </button>

        <a href="/inicio" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>

        <button class="cabecera__perfil" aria-haspopup="true" aria-label="Menú de usuario: <?= $nombre_usuario ?>">
            <span aria-hidden="true"><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img class="cabecera__avatar-imagen" src="<?= $avatar_cabecera ?>" alt="Foto de perfil de <?= $nombre_usuario ?>">
            </span>
        </button>
    </header>

    <div class="contenedor-principal">

        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
            <ul class="navegacion-lateral__lista">
                <li>
                    <a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/inicio" aria-current="page">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/eventos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/favoritos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
                        </svg>
                        Favoritos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/usuarios">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/perfil">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/logout"
                    onclick="return confirm('¿Seguro que quieres cerrar sesión?')">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                            <polyline points="16 17 21 12 16 7"/>
                            <line x1="21" y1="12" x2="9" y2="12"/>
                        </svg>
                        Cerrar sesión
                    </a>
                </li>
            </ul>
        </nav>

        <main id="contenido-principal" class="principal">

            <!-- Bienvenida -->
            <section aria-labelledby="titulo-bienvenida">
                <div class="bienvenida">
                    <p class="bienvenida__saludo">Panel de inicio</p>
                    <h1 id="titulo-bienvenida" class="bienvenida__titulo">
                        Bienvenido/a, <span><?= $nombre_usuario ?></span>
                    </h1>
                    <p class="bienvenida__subtitulo">¿Qué quieres explorar hoy?</p>
                </div>
            </section>


            <!-- Carrusel publicitario -->
            <section aria-label="Anuncios destacados" aria-roledescription="carrusel">
                <div class="carrusel-wrapper">
                    <div class="carrusel-cabecera">
                        <span class="carrusel-cabecera__titulo">Anuncios destacados</span>
                        <span class="sello-publicidad" aria-label="Espacio publicitario de pago">
                            <svg class="sello-publicidad__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z"/>
                            </svg>
                            Publicidad
                        </span>
                    </div>

                    <div class="carrusel" id="carrusel-principal">
                        <div class="carrusel__pista" id="carrusel-pista" aria-live="polite">

                            <div class="carrusel__diapositiva" role="group" aria-roledescription="diapositiva" aria-label="Anuncio 1 de 3">
                                <img class="carrusel__imagen" src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=1200&q=80" alt="Clase de baile con monitor y alumnos en sala">
                                <div class="carrusel__anuncio">
                                    <div class="carrusel__anuncio-cuerpo">
                                        <span class="carrusel__anuncio-tipo">
                                            Oferta de empleo
                                        </span>
                                        <p class="carrusel__anuncio-titulo">Asociación Nydia busca monitor/a de baile K-pop</p>
                                        <p class="carrusel__anuncio-descripcion">Incorporación inmediata. Clases para grupos de todas las edades en Vigo. Contrato a jornada parcial con posibilidad de ampliación.</p>
                                        <a href="/anuncios/nydia-monitor-kpop" class="carrusel__anuncio-cta">Ver oferta</a>
                                    </div>
                                </div>
                            </div>

                            <div class="carrusel__diapositiva" role="group" aria-roledescription="diapositiva" aria-label="Anuncio 2 de 3">
                                <img class="carrusel__imagen" src="https://images.unsplash.com/photo-1547153760-18fc86324498?auto=format&fit=crop&w=1200&q=80" alt="Escenario de evento cultural con jueces y participantes">
                                <div class="carrusel__anuncio">
                                    <div class="carrusel__anuncio-cuerpo">
                                        <span class="carrusel__anuncio-tipo">
                                            Convocatoria
                                        </span>
                                        <p class="carrusel__anuncio-titulo">Expotaku Galicia amplía su panel de jueces</p>
                                        <p class="carrusel__anuncio-descripcion">La mayor convención otaku de Galicia busca jueces especializados en cover dance K-pop para su edición 2026. Compensación económica incluida.</p>
                                        <a href="/anuncios/expotaku-jueces" class="carrusel__anuncio-cta">Solicitar plaza</a>
                                    </div>
                                </div>
                            </div>

                            <div class="carrusel__diapositiva" role="group" aria-roledescription="diapositiva" aria-label="Anuncio 3 de 3">
                                <img class="carrusel__imagen" src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80" alt="Sala de ensayo profesional con espejos y equipo de sonido">
                                <div class="carrusel__anuncio">
                                    <div class="carrusel__anuncio-cuerpo">
                                        <span class="carrusel__anuncio-tipo">
                                            Alquiler de espacio
                                        </span>
                                        <p class="carrusel__anuncio-titulo">Sala de ensayo en A Coruña — tarifa especial grupos K-pop</p>
                                        <p class="carrusel__anuncio-descripcion">Espejo de pared completa, equipo de sonido profesional y tarima. Desde 8 €/hora. Reserva online con descuento para grupos registrados en All Dance Together.</p>
                                        <a href="/anuncios/sala-ensayo-coruna" class="carrusel__anuncio-cta">Ver disponibilidad</a>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <button class="carrusel__btn carrusel__btn--anterior" id="carrusel-anterior" aria-label="Anuncio anterior">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <polyline points="15 18 9 12 15 6"/>
                            </svg>
                        </button>
                        <button class="carrusel__btn carrusel__btn--siguiente" id="carrusel-siguiente" aria-label="Anuncio siguiente">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <polyline points="9 18 15 12 9 6"/>
                            </svg>
                        </button>

                        <div class="carrusel__indicadores" role="tablist" aria-label="Seleccionar anuncio">
                            <button class="carrusel__punto carrusel__punto--activo" role="tab" aria-selected="true"  aria-label="Anuncio 1"></button>
                            <button class="carrusel__punto" role="tab" aria-selected="false" aria-label="Anuncio 2"></button>
                            <button class="carrusel__punto" role="tab" aria-selected="false" aria-label="Anuncio 3"></button>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Accesos rápidos -->
            <section aria-labelledby="titulo-accesos">
                <h2 id="titulo-accesos" class="accesos__titulo">Accesos rápidos</h2>
                <div class="accesos__cuadricula">

                    <a href="/descubrir" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Descubrir</span>
                        <span class="acceso__descripcion">Explora grupos y artistas de Galicia.</span>
                    </a>

                    <a href="/eventos" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Próximos eventos</span>
                            <span class="acceso__descripcion">Consulta los conciertos y eventos cercanos.</span>
              
                    </a>

                    <a href="/favoritos" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Favoritos</span>
                        <span class="acceso__descripcion">Accede a los grupos que sigues.</span>
                    </a>

                    <a href="/usuarios" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Usuarios</span>
                        <span class="acceso__descripcion">Encuentra y conecta con otros miembros.</span>
                    </a>

                </div>
            </section>

        </main>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

<script src="/js/Inicio.js"></script>

</body>
</html>