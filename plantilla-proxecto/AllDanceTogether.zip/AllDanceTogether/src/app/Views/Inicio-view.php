<?php
/**
 * Vista del Panel de Inicio (Dashboard).
 * * Renderiza la página principal del usuario autenticado, integrando un saludo 
 * personalizado, un carrusel publicitario accesible de anuncios destacados de la comunidad 
 * y una cuadrícula de accesos rápidos a las secciones clave de la plataforma.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Inicio — All Dance Together</title>
    <meta name="description" content="Panel de inicio de All Dance Together. Accede a eventos, favoritos, usuarios y más.">
    <link rel="stylesheet" href="/css/Inicio.css">
    <link rel="stylesheet" href="/css/Global.css">
</head>
<body>

    <h1 class="sr-only">All Dance Together</h1>
    
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <?php include_once(__DIR__.'/partials/header.php'); ?>


    <div class="contenedor-principal">

        <?php include_once(__DIR__.'/partials/menu.php'); ?>

        <main id="contenido-principal" class="principal">

            <!-- Bienvenida -->
            <section aria-labelledby="titulo-bienvenida">
                <div class="bienvenida">
                    <p class="bienvenida__saludo">Panel de inicio</p>
                    <h2 id="titulo-bienvenida" class="bienvenida__titulo">
                        Hola, <span><?= htmlspecialchars($_SESSION['usuario']['nick']) ?></span>
                    </h2>
                    <p class="bienvenida__subtitulo">¿Qué quieres explorar hoy?</p>
                </div>
            </section>

            <!-- Carrusel publicitario -->
            <section aria-label="Anuncios destacados" aria-roledescription="carrusel">
                <div class="carrusel-wrapper">
                    <div class="carrusel-cabecera">
                        <h2 class="carrusel-cabecera__titulo">Anuncios destacados</h2>
                        <span class="sello-publicidad" aria-label="Espacio publicitario de pago">
                            <svg class="sello-publicidad__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z"/>
                            </svg>
                            Publicidad
                        </span>
                    </div>

                    <div class="carrusel" id="carrusel-principal">
                        <div class="carrusel__pista" id="carrusel-pista">

                            <div class="carrusel__diapositiva" role="group" aria-roledescription="diapositiva" aria-label="Anuncio 1 de 3">
                                <img class="carrusel__imagen" src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=1200&q=80" alt="Clase de baile con monitor y alumnos en sala">
                                <div class="carrusel__anuncio">
                                    <div class="carrusel__anuncio-cuerpo">
                                        <span class="carrusel__anuncio-tipo">Oferta de empleo</span>
                                        <p class="carrusel__anuncio-titulo">Asociación Nydia busca monitor/a de baile K-pop</p>
                                        <p class="carrusel__anuncio-descripcion">Incorporación inmediata. Clases para grupos de todas las edades en Vigo. Contrato a jornada parcial con posibilidad de ampliación.</p>
                                        <a href="/anuncios/nydia-monitor-kpop" class="carrusel__anuncio-cta">Ver oferta</a>
                                    </div>
                                </div>
                            </div>

                            <div class="carrusel__diapositiva" role="group" aria-roledescription="diapositiva" aria-label="Anuncio 2 de 3">
                                <img class="carrusel__imagen" src="https://images.unsplash.com/photo-1547153760-18fc86324498?auto=format&fit=crop&w=1200&q=80" alt="Escenario de evento cultural con jueces y participantes">
                                <div class="carrusel__anuncio">
                                    <div class="carrusel__anuncio-cuerpo">
                                        <span class="carrusel__anuncio-tipo">Convocatoria</span>
                                        <p class="carrusel__anuncio-titulo">Expotaku Galicia amplía su panel de jueces</p>
                                        <p class="carrusel__anuncio-descripcion">La mayor convención otaku de Galicia busca jueces especializados en cover dance K-pop para su edición 2026. Compensación económica incluida.</p>
                                        <a href="/anuncios/expotaku-jueces" class="carrusel__anuncio-cta">Solicitar plaza</a>
                                    </div>
                                </div>
                            </div>

                            <div class="carrusel__diapositiva" role="group" aria-roledescription="diapositiva" aria-label="Anuncio 3 de 3">
                                <img class="carrusel__imagen" src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80" alt="Sala de ensayo profesional con espejos y equipo de sonido">
                                <div class="carrusel__anuncio">
                                    <div class="carrusel__anuncio-cuerpo">
                                        <span class="carrusel__anuncio-tipo">Alquiler de espacio</span>
                                        <p class="carrusel__anuncio-titulo">Sala de ensayo en A Coruña — tarifa especial grupos K-pop</p>
                                        <p class="carrusel__anuncio-descripcion">Espejo de pared completa, equipo de sonido profesional y tarima. Desde 8 €/hora. Reserva online con descuento para grupos registrados en All Dance Together.</p>
                                        <a href="/anuncios/sala-ensayo-coruna" class="carrusel__anuncio-cta">Ver disponibilidad</a>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <button class="carrusel__btn carrusel__btn--anterior" id="carrusel-anterior" aria-label="Anuncio anterior">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <polyline points="15 18 9 12 15 6"/>
                            </svg>
                        </button>
                        <button class="carrusel__btn carrusel__btn--siguiente" id="carrusel-siguiente" aria-label="Anuncio siguiente">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <polyline points="9 18 15 12 9 6"/>
                            </svg>
                        </button>

                        <div class="carrusel__indicadores" role="tablist" aria-label="Seleccionar anuncio">
                            <button class="carrusel__punto carrusel__punto--activo" role="tab" aria-selected="true"  aria-label="Anuncio 1"></button>
                            <button class="carrusel__punto" role="tab" aria-selected="false" aria-label="Anuncio 2"></button>
                            <button class="carrusel__punto" role="tab" aria-selected="false" aria-label="Anuncio 3"></button>
                        </div>

                        <div class="sr-only" aria-live="polite" aria-atomic="true" id="carrusel-anuncio"></div>
                    </div>
                </div>
            </section>

            <!-- Accesos rápidos -->
            <section aria-labelledby="titulo-accesos">
                <h2 id="titulo-accesos" class="accesos__titulo">Accesos rápidos</h2>
                <div class="accesos__cuadricula">

                    <a href="/descubrir" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Descubrir</span>
                        <span class="acceso__descripcion">Explora grupos y artistas de Galicia.</span>
                    </a>

                    <a href="/eventos" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Próximos eventos</span>
                        <span class="acceso__descripcion">Consulta los conciertos y eventos cercanos.</span>
                    </a>

                    <a href="/usuarios" class="acceso">
                        <span class="acceso__icono" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                            </svg>
                        </span>
                        <span class="acceso__nombre">Usuarios</span>
                        <span class="acceso__descripcion">Encuentra y conecta con otros miembros.</span>
                    </a>
                </div>
            </section>

        </main>
    </div>

    <?php include_once(__DIR__.'/partials/footer.php'); ?>

    <script src="/js/Inicio.js"></script>
</body>
</html>