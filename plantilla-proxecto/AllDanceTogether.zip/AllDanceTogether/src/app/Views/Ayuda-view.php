<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayuda — All Dance Together</title>
    <meta name="description" content="Preguntas frecuentes y ayuda sobre el uso de All Dance Together.">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/PaginasComunes.css">
    <style>
        /* ── Estilos específicos de Ayuda ── */

        .categorias {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 2.5rem;
        }

        .categoria-btn {
            padding: 0.45rem 1rem;
            background: none;
            border: 1px solid var(--color-borde);
            border-radius: 20px;
            color: var(--color-texto-suave);
            font-family: var(--fuente-cuerpo);
            font-size: 0.82rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }
        .categoria-btn:hover {
            border-color: var(--color-principal);
            color: #fff;
        }
        .categoria-btn.activo {
            background: rgba(123, 94, 248, 0.15);
            border-color: rgba(123, 94, 248, 0.5);
            color: #fff;
        }
        .categoria-btn:focus-visible {
            outline: 2px solid var(--color-borde-foco);
            outline-offset: 2px;
        }

        /* Grupo de preguntas */
        .faq-grupo {
            margin-bottom: 3rem;
        }

        .faq-grupo[hidden] { display: none; }

        .faq-grupo__etiqueta {
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: var(--color-principal);
            margin-bottom: 1rem;
            display: block;
        }

        /* Acordeón */
        .acordeon {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .acordeon__item {
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-md);
            overflow: hidden;
            transition: border-color 0.2s;
        }
        .acordeon__item:has(.acordeon__btn[aria-expanded="true"]) {
            border-color: rgba(123, 94, 248, 0.4);
        }

        .acordeon__btn {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            padding: 1rem 1.25rem;
            background: none;
            border: none;
            color: var(--color-texto);
            font-family: var(--fuente-cuerpo);
            font-size: 0.9rem;
            font-weight: 500;
            text-align: left;
            cursor: pointer;
            transition: background 0.2s;
        }
        .acordeon__btn:hover { background: rgba(255,255,255,0.03); }
        .acordeon__btn:focus-visible {
            outline: 2px solid var(--color-borde-foco);
            outline-offset: -2px;
        }

        .acordeon__icono {
            width: 18px;
            height: 18px;
            flex-shrink: 0;
            color: var(--color-principal);
            transition: transform 0.25s ease;
        }
        .acordeon__btn[aria-expanded="true"] .acordeon__icono {
            transform: rotate(180deg);
        }

        .acordeon__contenido {
            display: grid;
            grid-template-rows: 0fr;
            transition: grid-template-rows 0.25s ease;
        }
        .acordeon__contenido.abierto {
            grid-template-rows: 1fr;
        }

        .acordeon__contenido-inner {
            overflow: hidden;
        }

        .acordeon__respuesta {
            padding: 0 1.25rem 1.1rem;
            font-size: 0.875rem;
            color: var(--color-texto-suave);
            line-height: 1.75;
        }

        .acordeon__respuesta a {
            color: var(--color-principal);
            text-decoration: underline;
            text-underline-offset: 2px;
        }
        .acordeon__respuesta a:hover { color: #ec4899; }

        /* Bloque de contacto al final */
        .cta-contacto {
            margin-top: 1rem;
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-md);
            padding: 2rem 1.5rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .cta-contacto::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: var(--radio-md);
            padding: 1px;
            background: linear-gradient(135deg, rgba(236,72,153,0.3) 0%, rgba(59,130,246,0.3) 100%);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            pointer-events: none;
        }

        .cta-contacto__titulo {
            font-family: var(--fuente-titulo);
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.4rem;
        }

        .cta-contacto__texto {
            font-size: 0.875rem;
            color: var(--color-texto-suave);
            margin-bottom: 1.25rem;
        }

        .cta-contacto__boton {
            display: inline-block;
            padding: 0.65rem 1.5rem;
            background: var(--gradiente-neon);
            border: none;
            border-radius: 6px;
            color: #fff;
            font-family: var(--fuente-cuerpo);
            font-size: 0.875rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: opacity 0.2s;
        }
        .cta-contacto__boton:hover { opacity: 0.9; }
        .cta-contacto__boton:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
    </style>
</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <a href="javascript:history.back()" class="cabecera__volver" aria-label="Volver a la página anterior">
            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"/>
            </svg>
            Volver
        </a>
    </header>

    <main class="principal" id="contenido-principal">

        <div class="seccion-cabecera">
            <span class="seccion-cabecera__etiqueta">Soporte</span>
            <h1 class="seccion-cabecera__titulo">
                Preguntas <span>frecuentes</span>
            </h1>
            <p class="bloque__texto">Encuentra respuesta a las dudas más habituales sobre la plataforma.</p>
        </div>

        <!-- Filtro por categoría -->
        <nav class="categorias" aria-label="Filtrar preguntas por categoría">
            <button class="categoria-btn activo" data-cat="todas" aria-pressed="true">Todas</button>
            <button class="categoria-btn" data-cat="cuenta" aria-pressed="false">Mi cuenta</button>
            <button class="categoria-btn" data-cat="grupos" aria-pressed="false">Grupos</button>
            <button class="categoria-btn" data-cat="eventos" aria-pressed="false">Eventos</button>
            <button class="categoria-btn" data-cat="contenido" aria-pressed="false">Contenido e imágenes</button>
        </nav>

        <!-- ── CUENTA ── -->
        <section class="faq-grupo" data-cat="cuenta" aria-labelledby="cat-cuenta">
            <span class="faq-grupo__etiqueta" id="cat-cuenta">Mi cuenta</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r1">
                        ¿Cómo me registro en All Dance Together?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r1" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Haz clic en <strong>Regístrate</strong> desde la página de inicio de sesión. Necesitas un correo electrónico válido, un nombre de usuario y una contraseña. El registro está restringido a mayores de 18 años.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r2">
                        Olvidé mi contraseña, ¿cómo la recupero?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r2" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">En la pantalla de inicio de sesión encontrarás la opción <em>¿Olvidaste tu contraseña?</em>. Introduce tu correo y recibirás un enlace para restablecerla. Revisa también la carpeta de spam si no lo ves en unos minutos.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r3">
                        ¿Cómo cambio mi foto de perfil o mis datos?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r3" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Ve a <strong>Mi perfil</strong> desde el menú lateral y pulsa en <em>Editar perfil</em>. Desde ahí puedes cambiar tu nombre de usuario, foto y demás información visible.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r4">
                        ¿Cómo elimino mi cuenta?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r4" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Accede a <strong>Mi perfil</strong> y pulsa <em>Eliminar mi cuenta</em>, confirma la acción, en caso de encontrar alguna incidencia puedes solicitar la eliminación de tu cuenta escribiéndonos a <a href="mailto:hola@alldancetogether.es">hola@alldancetogether.es</a>. Tus datos se borrarán en un plazo máximo de 30 días según lo indicado en nuestra <a href="/politicas">Política de Privacidad</a>.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ── GRUPOS ── -->
        <section class="faq-grupo" data-cat="grupos" aria-labelledby="cat-grupos">
            <span class="faq-grupo__etiqueta" id="cat-grupos">Grupos</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r5">
                        ¿Cómo creo un grupo de baile?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r5" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Desde <strong>Registro</strong> encontrarás la opción <em>Crear usuario como agrupación</em>. Rellena el formulario con los datos del grupo. Una vez creado, accede a la página mediante el <strong>Login</strong>, dirigete a <em>Mi perfil</em> para añadir información extra.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r6">
                        ¿Puedo pertenecer a más de un grupo?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r6" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Si, actualmente los nombres de los integrantes se gestionan a través de listados mostrados en los perfiles de cada grupo. En próximas actualizaciones mejoraremos este aspecto.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r7">
                        ¿Cómo añado o elimino miembros de mi grupo?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r7" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Accede a la página de tu grupo y entra en <em>Gestionar miembros</em>. Solo el administrador del grupo puede añadir o eliminar miembros.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r8">
                        ¿Cómo añado a un grupo a mi lista de favoritos?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r8" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Dentro de la ficha de cualquier grupo encontrarás el icono de corazón. Pulsándolo lo añades a <strong>Favoritos</strong>, accesible desde el menú lateral.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ── EVENTOS ── -->
        <section class="faq-grupo" data-cat="eventos" aria-labelledby="cat-eventos">
            <span class="faq-grupo__etiqueta" id="cat-eventos">Eventos</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r9">
                        ¿Cómo publico un evento?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r9" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Ve a <strong>Próximos eventos</strong> y pulsa <em>Crear evento</em>. Indica nombre, fecha, lugar y una descripción clara.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r10">
                        ¿Puedo editar o eliminar un evento ya publicado?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r10" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Sí, mientras seas el creador/a del evento que lo publicó. Accede a la ficha del evento y verás las opciones <em>Editar</em> y <em>Eliminar</em> en la parte superior.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r11">
                        ¿Cómo sé si hay eventos cerca de mí?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r11" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">En la sección <strong>Próximos eventos</strong> puedes filtrar o buscar en el campo de búsqueda de texto libre la zona en la que te encuentras. Los eventos se ordenan por fecha de celebración de forma predeterminada.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ── CONTENIDO E IMÁGENES ── -->
        <section class="faq-grupo" data-cat="contenido" aria-labelledby="cat-contenido">
            <span class="faq-grupo__etiqueta" id="cat-contenido">Contenido e imágenes</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r12">
                        ¿Qué tipo de imágenes puedo subir?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r12" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Puedes subir fotos de perfil, imágenes de tu grupo y fotos de eventos. El contenido debe ser adecuado para todos los públicos y no puede mostrar personas sin su consentimiento. Consulta nuestra <a href="/politicas">Política de Privacidad</a> para más detalle.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r13">
                        Vi una imagen que no debería estar aquí, ¿cómo la reporto?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r13" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Escríbenos directamente a <a href="mailto:hola@alldancetogether.es">hola@alldancetogether.es</a> indicando la URL del contenido. Lo revisaremos y actuaremos en el menor tiempo posible.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r14">
                        ¿Puedo subir fotos de grupos o artistas de K-pop?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r14" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Puedes referenciar a artistas en la descripción de tu grupo, pero las imágenes de artistas o grupos musicales pertenecen a sus titulares de derechos. Si un titular reclama la retirada de algún contenido, lo eliminaremos de inmediato.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r15">
                        Aparezco en una foto sin mi permiso, ¿qué puedo hacer?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r15" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Escríbenos a <a href="mailto:hola@alldancetogether.es">hola@alldancetogether.es</a> con el enlace a la imagen. Tienes derecho a solicitar su retirada inmediata en virtud del RGPD. La eliminaremos en el menor tiempo posible.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- CTA contacto -->
        <div class="cta-contacto">
            <p class="cta-contacto__titulo">¿No encontraste lo que buscabas?</p>
            <p class="cta-contacto__texto">Escríbenos y te respondemos en menos de 48 horas laborables.</p>
            <a href="/contacto" class="cta-contacto__boton">Ir a Contacto</a>
        </div>

    </main>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda" aria-current="page">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

    <script>
        /* ── Acordeón ── */
        document.querySelectorAll('.acordeon__btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const expanded = btn.getAttribute('aria-expanded') === 'true';
                const contenido = document.getElementById(btn.getAttribute('aria-controls'));

                btn.setAttribute('aria-expanded', !expanded);
                contenido.classList.toggle('abierto', !expanded);
            });
        });

        /* ── Filtro por categoría ── */
        const catBtns = document.querySelectorAll('.categoria-btn');
        const grupos  = document.querySelectorAll('.faq-grupo');

        catBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const cat = btn.dataset.cat;

                catBtns.forEach(b => {
                    b.classList.remove('activo');
                    b.setAttribute('aria-pressed', 'false');
                });
                btn.classList.add('activo');
                btn.setAttribute('aria-pressed', 'true');

                grupos.forEach(g => {
                    if (cat === 'todas' || g.dataset.cat === cat) {
                        g.removeAttribute('hidden');
                    } else {
                        g.setAttribute('hidden', '');
                    }
                });
            });
        });
    </script>

</body>
</html>