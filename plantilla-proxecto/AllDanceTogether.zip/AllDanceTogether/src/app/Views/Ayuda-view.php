<?php

/** Vista de la Sección de Ayuda (FAQ).
 * * Renderiza la interfaz de preguntas frecuentes organizada por pestañas interactivas,
 * permitiendo resolver dudas de cuentas, grupos, eventos y contenidos.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Ayuda — All Dance Together</title>
    <meta name="description" content="Preguntas frecuentes y ayuda sobre el uso de All Dance Together.">
    
    <link rel="stylesheet" href="/css/PaginasComunes.css">
    <link rel="stylesheet" href="/css/Ayuda.css">

</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <div class="cabecera__acciones">
            <a href="javascript:history.back()" class="cabecera__volver" aria-label="Volver a la página anterior">
                <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="15 18 9 12 15 6"/>
                </svg>
                Volver
            </a>
            <a href="/login" class="cabecera__login">
                Iniciar sesión
            </a>
        </div>
    </header>

    <main class="principal" id="contenido-principal">

        <div class="seccion-cabecera">
            <span class="seccion-cabecera__etiqueta">Soporte</span>
            <h1 class="seccion-cabecera__titulo">
                Preguntas <span>frecuentes</span>
            </h1>
            <p class="bloque__texto">Encuentra respuesta a las dudas más habituales sobre la plataforma.</p>
        </div>

        <!-- Filtro por categoría -->
        <nav class="categorias" aria-label="Filtrar preguntas por categoría">
            <button class="categoria-btn activo" data-cat="todas" aria-pressed="true">Todas</button>
            <button class="categoria-btn" data-cat="cuenta" aria-pressed="false">Mi cuenta</button>
            <button class="categoria-btn" data-cat="grupos" aria-pressed="false">Grupos</button>
            <button class="categoria-btn" data-cat="eventos" aria-pressed="false">Eventos</button>
            <button class="categoria-btn" data-cat="contenido" aria-pressed="false">Contenido e imágenes</button>
        </nav>

        <!-- ── CUENTA ── -->
        <section class="faq-grupo" data-cat="cuenta" aria-labelledby="cat-cuenta">
            <span class="faq-grupo__etiqueta" id="cat-cuenta">Mi cuenta</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r1">
                        ¿Cómo me registro en All Dance Together?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r1" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Haz clic en <strong>Regístrate</strong> desde la página de inicio de sesión. Necesitas un correo electrónico válido, un nombre de usuario y una contraseña. El registro está restringido a mayores de 18 años.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r2">
                        Olvidé mi contraseña, ¿cómo la recupero?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r2" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">En la pantalla de inicio de sesión encontrarás la opción <em>¿Olvidaste tu contraseña?</em>. Introduce tu correo y recibirás un enlace para restablecerla. Revisa también la carpeta de spam si no lo ves en unos minutos.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r3">
                        ¿Cómo cambio mi foto de perfil o mis datos?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r3" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Ve a <strong>Mi perfil</strong> desde el menú lateral y pulsa en <em>Editar perfil</em>. Desde ahí puedes cambiar tu nombre de usuario, foto y demás información visible.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r4">
                        ¿Cómo elimino mi cuenta?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r4" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Accede a <strong>Mi perfil</strong> y pulsa <em>Eliminar mi cuenta</em>, confirma la acción, en caso de encontrar alguna incidencia puedes solicitar la eliminación de tu cuenta escribiéndonos a <a href="mailto:hola@alldancetogether.es">hola@alldancetogether.es</a>. Tus datos se borrarán en un plazo máximo de 30 días según lo indicado en nuestra <a href="/politicas">Política de Privacidad</a>.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ── GRUPOS ── -->
        <section class="faq-grupo" data-cat="grupos" aria-labelledby="cat-grupos">
            <span class="faq-grupo__etiqueta" id="cat-grupos">Grupos</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r5">
                        ¿Cómo creo un grupo de baile?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r5" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Desde <strong>Registro</strong> encontrarás la opción <em>Crear usuario como agrupación</em>. Rellena el formulario con los datos del grupo. Una vez creado, accede a la página mediante el <strong>Login</strong>, dirigete a <em>Mi perfil</em> para añadir información extra.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r6">
                        ¿Puedo pertenecer a más de un grupo?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r6" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Si, actualmente los nombres de los integrantes se gestionan a través de listados mostrados en los perfiles de cada grupo. En próximas actualizaciones mejoraremos este aspecto.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r7">
                        ¿Cómo añado o elimino miembros de mi grupo?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r7" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Accede a la página de tu grupo y entra en <em>Gestionar miembros</em>. Solo el administrador del grupo puede añadir o eliminar miembros.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r8">
                        ¿Cómo añado a un grupo a mi lista de favoritos? (Próxima Actualización)
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r8" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Dentro de la ficha de cualquier grupo encontrarás el icono de corazón. Pulsándolo lo añades a <strong>Favoritos</strong>, accesible desde el menú lateral.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ── EVENTOS ── -->
        <section class="faq-grupo" data-cat="eventos" aria-labelledby="cat-eventos">
            <span class="faq-grupo__etiqueta" id="cat-eventos">Eventos</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r9">
                        ¿Cómo publico un evento?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r9" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Ve a <strong>Próximos eventos</strong> y pulsa <em>Crear evento</em>. Indica nombre, fecha, lugar y una descripción clara.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r10">
                        ¿Puedo editar o eliminar un evento ya publicado?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r10" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Sí, mientras seas el creador/a del evento que lo publicó. Accede a la ficha del evento y verás las opciones <em>Editar</em> y <em>Eliminar</em> en la parte superior.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r11">
                        ¿Cómo sé si hay eventos cerca de mí?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r11" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">En la sección <strong>Próximos eventos</strong> puedes filtrar o buscar en el campo de búsqueda de texto libre la zona en la que te encuentras. Los eventos se ordenan por fecha de celebración de forma predeterminada.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ── CONTENIDO E IMÁGENES ── -->
        <section class="faq-grupo" data-cat="contenido" aria-labelledby="cat-contenido">
            <span class="faq-grupo__etiqueta" id="cat-contenido">Contenido e imágenes</span>
            <div class="acordeon">

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r12">
                        ¿Qué tipo de imágenes puedo subir?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r12" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Puedes subir fotos de perfil, imágenes de tu grupo y fotos de eventos. El contenido debe ser adecuado para todos los públicos y no puede mostrar personas sin su consentimiento. Consulta nuestra <a href="/politicas">Política de Privacidad</a> para más detalle.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r13">
                        Vi una imagen que no debería estar aquí, ¿cómo la reporto?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r13" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Escríbenos directamente a <a href="mailto:hola@alldancetogether.es">hola@alldancetogether.es</a> indicando la URL del contenido. Lo revisaremos y actuaremos en el menor tiempo posible.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r14">
                        ¿Puedo subir fotos de grupos o artistas de K-pop?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r14" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Puedes referenciar a artistas en la descripción de tu grupo, pero las imágenes de artistas o grupos musicales pertenecen a sus titulares de derechos. Si un titular reclama la retirada de algún contenido, lo eliminaremos de inmediato.</p>
                        </div>
                    </div>
                </div>

                <div class="acordeon__item">
                    <button class="acordeon__btn" aria-expanded="false" aria-controls="r15">
                        Aparezco en una foto sin mi permiso, ¿qué puedo hacer?
                        <svg class="acordeon__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="acordeon__contenido" id="r15" role="region">
                        <div class="acordeon__contenido-inner">
                            <p class="acordeon__respuesta">Escríbenos a <a href="mailto:hola@alldancetogether.es">hola@alldancetogether.es</a> con el enlace a la imagen. Tienes derecho a solicitar su retirada inmediata en virtud del RGPD. La eliminaremos en el menor tiempo posible.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- CTA contacto -->
        <div class="cta-contacto">
            <p class="cta-contacto__titulo">¿No encontraste lo que buscabas?</p>
            <p class="cta-contacto__texto">Escríbenos y te respondemos en menos de 48 horas laborables.</p>
            <a href="/contacto" class="cta-contacto__boton">Ir a Contacto</a>
        </div>

    </main>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda" aria-current="page">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

    <script>
        /* ── Acordeón ── */
        document.querySelectorAll('.acordeon__btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const expanded = btn.getAttribute('aria-expanded') === 'true';
                const contenido = document.getElementById(btn.getAttribute('aria-controls'));

                btn.setAttribute('aria-expanded', !expanded);
                contenido.classList.toggle('abierto', !expanded);
            });
        });

        /* ── Filtro por categoría ── */
        const catBtns = document.querySelectorAll('.categoria-btn');
        const grupos  = document.querySelectorAll('.faq-grupo');

        catBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const cat = btn.dataset.cat;

                catBtns.forEach(b => {
                    b.classList.remove('activo');
                    b.setAttribute('aria-pressed', 'false');
                });
                btn.classList.add('activo');
                btn.setAttribute('aria-pressed', 'true');

                grupos.forEach(g => {
                    if (cat === 'todas' || g.dataset.cat === cat) {
                        g.removeAttribute('hidden');
                    } else {
                        g.setAttribute('hidden', '');
                    }
                });
            });
        });
    </script>

</body>
</html>