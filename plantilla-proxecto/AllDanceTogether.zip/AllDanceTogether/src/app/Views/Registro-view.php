<?php
/**
 * Vista del Formulario de Registro de Usuarios.
 * * Renderiza la interfaz de alta para nuevos miembros de la comunidad,
 * proporcionando la captura de datos personales, validación y desglose de errores de perfil,
 * protección CSRF, diferenciación de tipo de usuario (solista/grupo) y control de visibilidad de claves.
 */

$errores = [
    'contrasena'        => 'Las contraseñas no coinciden.',
    'contrasena_debil'  => 'La contraseña debe tener al menos 8 caracteres, una mayúscula y un número.',
    'correo'            => 'El formato del correo electrónico no es válido.',
    'usuario'           => 'El nombre de usuario solo puede tener letras, números y guiones bajos (3-30 caracteres).',
    'correo_duplicado'  => 'Este correo electrónico ya está registrado.',
    'usuario_duplicado' => 'Este nombre de usuario ya está en uso.',
    'db'                => 'Ha ocurrido un error al crear la cuenta. Inténtalo de nuevo.',
];

$error_actual = $_GET['error'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Regístrate en All Dance Together y únete a la mayor comunidad de grupos de covers de toda Galicia. Crea tu perfil de solista o grupo ahora.">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>All Dance Together - Registro</title>
    
    <link rel="stylesheet" href="/css/LoginRegister.css">
    <link rel="stylesheet" href="/css/Global.css">
</head>
<body>
    <h1 class="sr-only">All Dance Together</h1>

    <!-- Enlace de saltar contenido como primer elemento interactivo para cumplir con la accesibilidad web -->
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>

    <!-- header -->
    <?php include_once(__DIR__.'/partials/header_log.php'); ?>

    <main class="principal" id="contenido-principal">

        <section class="seccion-acceso" aria-labelledby="titulo-registro">

            <h2 id="titulo-registro" class="seccion-acceso__titulo">Crea tu cuenta</h1>
            <p class="seccion-acceso__subtitulo">Únete a la comunidad de grupos de covers de toda Galicia.</p>

            <!-- Mensaje de errores -->
            <?php if ($error_actual && isset($errores[$error_actual])): ?>
                <div class="aviso aviso--error" role="alert">
                    <?php echo htmlspecialchars($errores[$error_actual]); ?>
                </div>
            <?php endif; ?>

            <form class="formulario-acceso" action="/registro/guardar" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="campo">
                    <label class="campo__etiqueta" for="nombre_real">Nombre real</label>
                    <input
                        class="campo__entrada"
                        type="text"
                        id="nombre_real"
                        name="nombre_real"
                        placeholder="Ej: Mariana García"
                        required
                        autocomplete="name"
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="nombre_usuario">Nombre de usuario</label>
                    <input
                        class="campo__entrada"
                        type="text"
                        id="nombre_usuario"
                        name="usuario"
                        placeholder="Ej: mariana_dance"
                        required
                        autocomplete="username"
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="correo_electronico">Correo electrónico</label>
                    <input
                        class="campo__entrada"
                        type="email"
                        id="correo_electronico"
                        name="correo"
                        placeholder="Ej: mariana@email.com"
                        required
                        autocomplete="email"
                    >
                </div>

            <div class="campo">
                <label class="campo__etiqueta" for="contrasena">Contraseña</label>
                
                <!-- Wrapper que agrupa input + botón -->
                <div class="campo__entrada-wrapper">
                    <input
                        class="campo__entrada"
                        type="password"
                        id="contrasena"
                        name="contrasena"
                        placeholder="Crea una contraseña segura"
                        required
                        autocomplete="new-password"
                        aria-describedby="ayuda-contrasena"
                    >
                    <button
                        type="button"
                        class="campo__boton-visibilidad"
                        id="btn-ver-contrasena"
                        aria-label="Mostrar contraseña"
                        aria-pressed="false"
                        onclick="alternarVisibilidadContrasena('contrasena', 'btn-ver-contrasena')"
                    >
                        VER
                    </button>
                </div>

                <!-- Small queda fuera del wrapper, debajo del conjunto -->
                <small id="ayuda-contrasena" class="campo__ayuda">
                    La contraseña debe tener al menos 8 caracteres, incluyendo una letra y un número.
                </small>
            </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="repetir_contrasena">Repetir contraseña</label>
                    <div class="campo__entrada-wrapper">
                        <input
                            class="campo__entrada"
                            type="password"
                            id="repetir_contrasena"
                            name="confirmar_contrasena"
                            placeholder="Confirma tu contraseña"
                            aria-describedby="ayuda-confirmacion"
                            required
                            autocomplete="new-password"
                        >

                        <button
                            type="button"
                            class="campo__boton-visibilidad"
                            id="btn-ver-contrasena-confirmar"
                            aria-label="Mostrar contraseña de confirmación"
                            aria-pressed="false"
                            onclick="alternarVisibilidadContrasena('repetir_contrasena', 'btn-ver-contrasena-confirmar')"
                        >
                            VER
                        </button>
            </div>
                    <small id="ayuda-confirmacion" class="campo__ayuda">
                        Introduce la misma contraseña que elegiste arriba.
                    </small>

                </div>

                <label class="campo campo--casilla" for="es_grupo">
                    <input 
                        type="checkbox" 
                        id="es_grupo" 
                        name="es_grupo" 
                        class="campo__casilla-entrada"
                        aria-describedby="ayuda-tipo-usuario"
                    >
                    <span class="campo__etiqueta campo__etiqueta--casilla">Regístrame como Grupo</span>
                </label>

                <small id="ayuda-tipo-usuario" class="campo__ayuda">
                    Selecciona esto si eres un grupo de covers. Las cuentas de grupo tienen opciones adicionales para gestionar miembros y repertorios.
                </small>

                <button class="boton-entrar" type="submit">
                    Registrarse
                </button>

                <p class="enlace-registro">
                    ¿Ya tienes una cuenta? <a class="enlace-registro__ancla" href="/login"><strong>Inicia sesión</strong></a>
                </p>

            </form>

        </section>

    </main>

    <!-- footer -->
    <?php include_once(__DIR__.'/partials/footer_log.php'); ?>

    <script src="/js/Registro.js"></script>
</body>
</html>