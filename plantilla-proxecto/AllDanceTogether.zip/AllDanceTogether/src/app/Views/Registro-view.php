<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Dance Together - Registro</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/LoginRegister.css">
</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir a la página de inicio de All Dance Together">
            <p class="cabecera__nombre">All Dance Together</p>
        </a>
    </header>

    <main class="principal" id="contenido-principal">

        <section class="seccion-acceso" aria-labelledby="titulo-registro">

            <h1 id="titulo-registro" class="seccion-acceso__titulo">Crea tu cuenta</h1>
            <p class="seccion-acceso__subtitulo">Únete a la comunidad de grupos de covers de toda Galicia.</p>

            <form class="formulario-acceso" action="/registro/guardar" method="POST">
                <div class="campo">
                    <label class="campo__etiqueta" for="nombre_real">Nombre real</label>
                    <input
                        class="campo__entrada"
                        type="text"
                        id="nombre_real"
                        name="nombre_real"
                        placeholder="Ej: Mariana García"
                        required
                        autocomplete="name"
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="nombre_usuario">Nombre de usuario</label>
                    <input
                        class="campo__entrada"
                        type="text"
                        id="nombre_usuario"
                        name="usuario"
                        placeholder="Ej: mariana_dance"
                        required
                        autocomplete="username"
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="correo_electronico">Correo electrónico</label>
                    <input
                        class="campo__entrada"
                        type="email"
                        id="correo_electronico"
                        name="correo"
                        placeholder="Ej: mariana@email.com"
                        required
                        autocomplete="email"
                    >
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="contrasena">Contraseña</label>
                    <input
                        class="campo__entrada"
                        type="password"
                        id="contrasena"
                        name="contrasena"
                        placeholder="Crea una contraseña segura"
                        required
                        autocomplete="new-password"
                    >
                    <button
                        type="button"
                        class="campo__boton-visibilidad"
                        id="btn-ver-contrasena"
                        aria-label="Mostrar contraseña"
                        aria-pressed="false"
                        onclick="alternarVisibilidadContrasena('contrasena', 'btn-ver-contrasena')"
                    >
                        VER
                    </button>
                </div>

                <div class="campo">
                    <label class="campo__etiqueta" for="repetir_contrasena">Repetir contraseña</label>
                    <input
                        class="campo__entrada"
                        type="password"
                        id="repetir_contrasena"
                        name="confirmar_contrasena"
                        placeholder="Confirma tu contraseña"
                        required
                        autocomplete="new-password"
                    >
                    <button
                        type="button"
                        class="campo__boton-visibilidad"
                        id="btn-ver-contrasena-confirmar"
                        aria-label="Mostrar contraseña de confirmación"
                        aria-pressed="false"
                        onclick="alternarVisibilidadContrasena('repetir_contrasena', 'btn-ver-contrasena-confirmar')"
                    >
                        VER
                    </button>
                </div>

                <label class="campo campo--casilla" for="es_grupo">
                    <input 
                        type="checkbox" 
                        id="es_grupo" 
                        name="es_grupo" 
                        class="campo__casilla-entrada"
                    >
                    <span class="campo__etiqueta campo__etiqueta--casilla">Regístrame como Grupo</span>
                </label>

                <button class="boton-entrar" type="submit">
                    Registrarse
                </button>

                <p class="enlace-registro">
                    ¿Ya tienes una cuenta? <a class="enlace-registro__ancla" href="/login"><strong>Inicia sesión</strong></a>
                </p>

            </form>

        </section>

    </main>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/politicas">Políticas de Privacidad</a></li>
            </ul>
        </nav>
    </footer>

    <script>
        // Función modular reutilizable para mostrar/ocultar texto de las contraseñas de forma accesible
        function alternarVisibilidadContrasena(idEntrada, idBoton) {
            const entrada = document.getElementById(idEntrada);
            const boton = document.getElementById(idBoton);
            if (entrada.type === 'password') {
                entrada.type = 'text';
                boton.setAttribute('aria-pressed', 'true');
                boton.innerText = 'OCULTAR';
                boton.setAttribute('aria-label', 'Ocultar contraseña');
            } else {
                entrada.type = 'password';
                boton.setAttribute('aria-pressed', 'false');
                boton.innerText = 'VER';
                boton.setAttribute('aria-label', 'Mostrar contraseña');
            }
        }
    </script>
</body>
</html>