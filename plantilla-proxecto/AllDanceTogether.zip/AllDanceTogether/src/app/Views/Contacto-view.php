<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto — All Dance Together</title>
    <meta name="description" content="Ponte en contacto con el equipo de All Dance Together.">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/PaginasComunes.css">
    <style>
        /* ── Estilos específicos de Contacto ── */

        .tarjetas-contacto {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 1rem;
            margin-bottom: 3rem;
        }

        .tarjeta-contacto {
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-md);
            padding: 1.5rem 1.25rem;
            text-decoration: none;
            color: var(--color-texto);
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
            transition: border-color 0.2s, transform 0.2s, background-color 0.2s;
            position: relative;
            overflow: hidden;
        }

        .tarjeta-contacto::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: var(--radio-md);
            padding: 1px;
            background: linear-gradient(135deg, rgba(236,72,153,0.3) 0%, rgba(59,130,246,0.3) 100%);
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        }

        .tarjeta-contacto:hover {
            border-color: rgba(236, 72, 153, 0.4);
            transform: translateY(-3px);
            background-color: rgba(20, 21, 44, 0.9);
        }
        .tarjeta-contacto:hover::before { opacity: 1; }
        .tarjeta-contacto:focus-visible {
            outline: 2px solid var(--color-borde-foco);
            outline-offset: 2px;
        }

        .tarjeta-contacto__icono {
            width: 40px;
            height: 40px;
            border-radius: 9px;
            background: rgba(123, 94, 248, 0.12);
            border: 1px solid rgba(123, 94, 248, 0.25);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: background 0.2s;
        }
        .tarjeta-contacto:hover .tarjeta-contacto__icono {
            background: rgba(236, 72, 153, 0.15);
            border-color: rgba(236, 72, 153, 0.35);
        }

        .tarjeta-contacto__icono svg {
            width: 18px;
            height: 18px;
            color: var(--color-principal);
            transition: color 0.2s;
        }
        .tarjeta-contacto:hover .tarjeta-contacto__icono svg { color: #ec4899; }

        .tarjeta-contacto__tipo {
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: var(--color-marcador);
        }

        .tarjeta-contacto__valor {
            font-size: 0.9rem;
            font-weight: 600;
            color: #fff;
            word-break: break-all;
        }

        .tarjeta-contacto__descripcion {
            font-size: 0.78rem;
            color: var(--color-texto-suave);
            line-height: 1.4;
        }

        /* Horario */
        .horario {
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-md);
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .horario__fila {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.875rem;
        }

        .horario__dia { color: var(--color-texto-suave); }

        .horario__hora {
            font-weight: 500;
            color: #fff;
        }

        .horario__separador {
            height: 1px;
            background: var(--color-borde);
            margin: 0.25rem 0;
        }
    </style>
</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <a href="javascript:history.back()" class="cabecera__volver" aria-label="Volver a la página anterior">
            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"/>
            </svg>
            Volver
        </a>
    </header>

    <main class="principal" id="contenido-principal">

        <div class="seccion-cabecera">
            <span class="seccion-cabecera__etiqueta">Soporte</span>
            <h1 class="seccion-cabecera__titulo">
                <span>Contacto</span>
            </h1>
            <p class="bloque__texto">¿Tienes alguna duda, incidencia o sugerencia? Escríbenos o encuéntranos en redes.</p>
        </div>

        <div class="tarjetas-contacto">

            <a href="mailto:hola@alldancetogether.es" class="tarjeta-contacto" aria-label="Enviar correo a hola@alldancetogether.es">
                <span class="tarjeta-contacto__icono" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <polyline points="22,6 12,13 2,6"/>
                    </svg>
                </span>
                <span class="tarjeta-contacto__tipo">Correo electrónico</span>
                <span class="tarjeta-contacto__valor">hola@alldancetogether.es</span>
                <span class="tarjeta-contacto__descripcion">Respondemos en un plazo de 48 h laborables.</span>
            </a>

            <a href="https://instagram.com/alldancetogether_gal" target="_blank" rel="noopener noreferrer" class="tarjeta-contacto" aria-label="Visitar Instagram de All Dance Together (abre en nueva pestaña)">
                <span class="tarjeta-contacto__icono" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                        <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/>
                        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
                    </svg>
                </span>
                <span class="tarjeta-contacto__tipo">Instagram</span>
                <span class="tarjeta-contacto__valor">@alldancetogether_gal</span>
                <span class="tarjeta-contacto__descripcion">DMs abiertos para consultas rápidas.</span>
            </a>

            <a href="tel:+34612345678" class="tarjeta-contacto" aria-label="Llamar al 612 345 678">
                <span class="tarjeta-contacto__icono" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 1h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
                    </svg>
                </span>
                <span class="tarjeta-contacto__tipo">Teléfono</span>
                <span class="tarjeta-contacto__valor">612 345 678</span>
                <span class="tarjeta-contacto__descripcion">Solo en horario de atención indicado abajo.</span>
            </a>

        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">Horario de atención</h2>
            <div class="horario">
                <div class="horario__fila">
                    <span class="horario__dia">Lunes – Viernes</span>
                    <span class="horario__hora">10:00 – 18:00</span>
                </div>
                <div class="horario__separador" aria-hidden="true"></div>
                <div class="horario__fila">
                    <span class="horario__dia">Sábado</span>
                    <span class="horario__hora">11:00 – 14:00</span>
                </div>
                <div class="horario__separador" aria-hidden="true"></div>
                <div class="horario__fila">
                    <span class="horario__dia">Domingo y festivos</span>
                    <span class="horario__hora">Cerrado</span>
                </div>
            </div>
        </div>

    </main>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto" aria-current="page">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

</body>
</html>