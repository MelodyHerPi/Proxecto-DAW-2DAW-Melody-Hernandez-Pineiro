<?php
/**
 * Vista de la Política de Privacidad y Protección de Datos.
 * * Renderiza el documento legal corporativo y académico conforme al RGPD y la LOPDGDD,
 * detallando el tratamiento de datos personales, la política de uso y control de imágenes, 
 * los derechos ARCO de los usuarios y las restricciones de edad de la plataforma.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Política de Privacidad — All Dance Together</title>
    <meta name="description" content="Política de privacidad, protección de datos e imágenes de All Dance Together.">
    
    <link rel="stylesheet" href="/css/PaginasComunes.css">
</head>
<body>

    <header class="cabecera" role="banner">
        <a href="/" class="cabecera__marca" aria-label="Ir al inicio de All Dance Together">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <a href="javascript:history.back()" class="cabecera__volver" aria-label="Volver a la página anterior">
            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"/>
            </svg>
            Volver
        </a>
    </header>

    <main class="principal" id="contenido-principal">

        <div class="seccion-cabecera">
            <span class="seccion-cabecera__etiqueta">Legal</span>
            <h1 class="seccion-cabecera__titulo">
                Política de <span>Privacidad</span>
            </h1>
            <p class="seccion-cabecera__fecha">Última actualización: enero de 2026</p>
        </div>

        <!-- Aviso menores -->
        <div class="aviso-destacado" role="note" aria-label="Aviso sobre acceso de menores">
            <svg class="aviso-destacado__icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            <div class="aviso-destacado__cuerpo">
                <p class="aviso-destacado__titulo">Acceso restringido a mayores de 18 años</p>
                <p class="aviso-destacado__texto">
                    El uso de All Dance Together está dirigido exclusivamente a personas mayores de 18 años. Al registrarte o utilizar la plataforma, declaras tener la edad mínima requerida. Si eres menor de edad, debes abandonar la plataforma. No recopilamos de forma intencionada datos de menores de 18 años; si detectamos que un usuario registrado es menor, su cuenta será eliminada de forma inmediata.
                </p>
            </div>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">1. Responsable del tratamiento</h2>
            <p class="bloque__texto">
                El responsable del tratamiento de los datos personales recogidos a través de esta plataforma es <strong>All Dance Together</strong>, con correo electrónico de contacto <a href="mailto:hola@alldancetogether.es" style="color: var(--color-principal);">hola@alldancetogether.es</a>. Esta plataforma es un proyecto académico sin ánimo de lucro desarrollado como Trabajo de Fin de Ciclo (TFC).
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">2. Datos que recogemos</h2>
            <p class="bloque__texto">Al registrarte y utilizar la plataforma, podemos recoger los siguientes datos:</p>
            <ul class="bloque__lista">
                <li>Nombre de usuario (nick) y dirección de correo electrónico.</li>
                <li>Contraseña almacenada de forma cifrada (hash bcrypt). Nunca guardamos contraseñas en texto plano.</li>
                <li>Imagen de perfil (avatar) que el propio usuario sube voluntariamente.</li>
                <li>Información sobre grupos de baile: nombre, descripción, ubicación y fotografías asociadas.</li>
                <li>Eventos creados o marcados como favoritos.</li>
                <li>Fecha de registro y última conexión, con fines de seguridad y mantenimiento.</li>
            </ul>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">3. Imágenes en la plataforma</h2>
            <p class="bloque__texto">All Dance Together permite a los usuarios subir imágenes de diversa naturaleza. A continuación se detalla cómo se tratan cada tipo:</p>

            <p class="bloque__texto" style="margin-top:1rem; font-weight:600; color:#fff; font-size:0.85rem;">Fotos de perfil y avatares</p>
            <ul class="bloque__lista">
                <li>La imagen de perfil es subida voluntariamente por el usuario. Al subirla, el usuario declara tener los derechos necesarios sobre dicha imagen o haber obtenido el consentimiento de las personas que aparecen en ella.</li>
                <li>Las imágenes de perfil son visibles para otros usuarios registrados de la plataforma.</li>
                <li>Puedes eliminar o cambiar tu foto de perfil en cualquier momento desde los ajustes de tu cuenta.</li>
            </ul>

            <p class="bloque__texto" style="margin-top:1rem; font-weight:600; color:#fff; font-size:0.85rem;">Imágenes en eventos y publicaciones de grupos</p>
            <ul class="bloque__lista">
                <li>Los grupos pueden publicar imágenes relacionadas con sus actividades, ensayos o eventos. Al publicar una imagen, el responsable del grupo declara haber obtenido el consentimiento de todas las personas fotografiadas, especialmente si aparecen menores de edad acompañados de un tutor legal.</li>
                <li>Cualquier imagen que muestre personas sin su consentimiento, o que contenga contenido inapropiado, puede ser reportada y será retirada de forma inmediata.</li>
                <li>All Dance Together no se responsabiliza del contenido de las imágenes subidas por los usuarios, aunque actúa con diligencia ante cualquier reclamación.</li>
            </ul>

            <p class="bloque__texto" style="margin-top:1rem; font-weight:600; color:#fff; font-size:0.85rem;">Contenido de terceros (K-pop, artistas, grupos musicales)</p>
            <ul class="bloque__lista">
                <li>Algunos usuarios pueden hacer referencia a grupos o artistas de K-pop mediante imágenes, logotipos o fotografías. Este contenido pertenece a sus respectivos titulares de derechos.</li>
                <li>All Dance Together no reclama ningún derecho sobre dicho contenido y actuará ante cualquier reclamación de derechos de autor retirando el contenido señalado.</li>
                <li>Si eres titular de derechos y detectas un uso no autorizado, contáctanos en <a href="mailto:hola@alldancetogether.es" style="color: var(--color-principal);">hola@alldancetogether.es</a>.</li>
            </ul>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">4. Finalidad del tratamiento</h2>
            <p class="bloque__texto">Los datos recogidos se utilizan exclusivamente para:</p>
            <ul class="bloque__lista">
                <li>Gestionar el acceso y la cuenta de usuario en la plataforma.</li>
                <li>Mostrar perfiles de grupos y usuarios a otros miembros de la comunidad.</li>
                <li>Enviar comunicaciones relacionadas con la cuenta (restablecimiento de contraseña, etc.).</li>
                <li>Fines académicos y de demostración del proyecto TFC, sin explotación comercial.</li>
            </ul>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">5. Base legal</h2>
            <p class="bloque__texto">
                El tratamiento se basa en el consentimiento del usuario, prestado al aceptar estos términos durante el proceso de registro, de conformidad con el Reglamento General de Protección de Datos (RGPD, UE 2016/679) y la Ley Orgánica 3/2018 de Protección de Datos Personales y garantía de los derechos digitales (LOPDGDD).
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">6. Conservación de datos</h2>
            <p class="bloque__texto">
                Los datos se conservan mientras la cuenta del usuario esté activa. Al eliminar la cuenta, los datos personales y las imágenes asociadas serán borrados en un plazo máximo de 30 días, salvo que exista obligación legal de conservarlos.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">7. Tus derechos</h2>
            <p class="bloque__texto">En virtud del RGPD, tienes derecho a:</p>
            <ul class="bloque__lista">
                <li><strong>Acceso:</strong> solicitar una copia de los datos que tenemos sobre ti.</li>
                <li><strong>Rectificación:</strong> corregir datos inexactos o incompletos.</li>
                <li><strong>Supresión:</strong> solicitar la eliminación de tus datos ("derecho al olvido").</li>
                <li><strong>Oposición y limitación:</strong> oponerte a determinados tratamientos o solicitar su limitación.</li>
                <li><strong>Portabilidad:</strong> recibir tus datos en un formato estructurado y de uso común.</li>
            </ul>
            <p class="bloque__texto" style="margin-top:0.75rem;">
                Para ejercer cualquiera de estos derechos, escríbenos a <a href="mailto:hola@alldancetogether.es" style="color: var(--color-principal);">hola@alldancetogether.es</a>. Si no obtienes respuesta satisfactoria, puedes reclamar ante la Agencia Española de Protección de Datos (AEPD) en <a href="https://www.aepd.es" target="_blank" rel="noopener noreferrer" style="color: var(--color-principal);">www.aepd.es</a>.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">8. Cookies</h2>
            <p class="bloque__texto">
                Esta plataforma utiliza únicamente cookies de sesión estrictamente necesarias para el funcionamiento del sistema de autenticación. No se utilizan cookies de seguimiento, publicidad ni análisis de terceros.
            </p>
        </div>

        <div class="bloque">
            <h2 class="bloque__titulo">9. Modificaciones</h2>
            <p class="bloque__texto">
                Nos reservamos el derecho de actualizar esta política cuando sea necesario. Cualquier cambio relevante será comunicado a los usuarios registrados mediante un aviso visible en la plataforma.
            </p>
        </div>

    </main>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas" aria-current="page">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

</body>
</html>