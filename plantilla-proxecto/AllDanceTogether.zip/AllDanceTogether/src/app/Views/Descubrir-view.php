<?php
/**
 * Vista de Descubrir.
 * * Renderiza el tablón principal de la comunidad, gestionando la búsqueda y filtrado
 * de posts (eventos/noticias), el renderizado del grid de resultados y la ventana modal
 * interactiva para la creación de nuevas publicaciones.
 */

$busqueda_actual = htmlspecialchars($_GET['q'] ?? '', ENT_QUOTES, 'UTF-8');
$tipo_actual     = $_GET['tipo'] ?? 'todos';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Descubrir — All Dance Together</title>
    <link rel="stylesheet" href="/css/Descubrir.css">
    <link rel="stylesheet" href="/css/Global.css">

</head>
<body>

    <h1 class="sr-only">All Dance Together</h1>
    
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

 <?php include_once(__DIR__.'/partials/header.php'); ?>

    <div class="contenedor-principal">
        <?php include_once(__DIR__.'/partials/menu.php'); ?>

        <main class="principal">
            
            <!-- Mensajes de respuesta tras la creación -->
           <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito">
                    <?= htmlspecialchars($_SESSION['msg_exito'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['msg_exito']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error">
                    <?= htmlspecialchars($_SESSION['msg_error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['msg_error']); ?>
                </div>
            <?php endif; ?>

            <section class="encabezado-seccion">
                <div>
                    <h2 class="encabezado-seccion__titulo">Descubrir</h2>
                    <p class="encabezado-seccion__subtitulo">Explora eventos y noticias reales de la comunidad.</p>
                </div>
                <button class="btn-crear" id="btn-abrir-modal">
                     Crear Publicación
                </button>
            </section>

            <div class="barra-busqueda">
                <form action="/descubrir" method="GET" class="formulario-filtros" id="form-filtros">
                    <div class="grupo-input">
                        <label class="grupo-input__etiqueta" for="q">Búsqueda libre</label>
                        <input type="text" id="q" name="q" class="input-control"
                            placeholder="Buscar palabras clave..."
                            value="<?= $busqueda_actual ?>">
                    </div>

                    <div class="grupo-input">
                        <label class="grupo-input__etiqueta" for="tipo">Tipo</label>
                        <select id="tipo" name="tipo" class="input-control select-tipo">
                            <option value="todos"   <?= $tipo_actual === 'todos'   ? 'selected' : '' ?>>Todos</option>
                            <option value="evento"  <?= $tipo_actual === 'evento'  ? 'selected' : '' ?>>Eventos</option>
                            <option value="noticia" <?= $tipo_actual === 'noticia' ? 'selected' : '' ?>>Noticias</option>
                        </select>
                    </div>

                    <div class="grupo-input grupo-input--acciones">
                        <button type="submit" class="btn-buscar">Filtrar</button>
                        <button type="button" class="btn-limpiar" id="btn-limpiar-filtros"
                                aria-label="Limpiar filtros de búsqueda">Limpiar</button>
                    </div>
                </form>
            </div>

            <div class="grid-descubrir">
                <?php if (!empty($resultados)): ?>
                    <?php foreach ($resultados as $item): ?>
                        <section class="card-descubrir">
                            <div class="card-descubrir__imagen-wrapper">
                                <span class="badge-tipo-item badge-tipo-item--<?= $item['tipo_item'] ?>">
                                    <?= htmlspecialchars($item['tipo_item']) ?>
                                </span>
                                
                            <?php if (!empty($item['foto_url'])): ?>
                                <img class="card-descubrir__img"
                                    src="<?= htmlspecialchars($item['foto_url']) ?>"
                                    alt="<?= htmlspecialchars($item['titulo']) ?>">
                            <?php else: ?>
                                <div class="card-descubrir__img card-descubrir__img--placeholder" aria-hidden="true">
                                    <span class="placeholder-inicial">
                                        <?= htmlspecialchars(mb_strtoupper(mb_substr($item['titulo'], 0, 1, 'UTF-8'), 'UTF-8')) ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            </div>

                            <div class="card-descubrir__contenido">
                                <h2 class="card-descubrir__titulo"><?= htmlspecialchars($item['titulo']) ?></h2>
                                
                                <p class="card-descubrir__txt">
                                    <?= mb_strimwidth(htmlspecialchars($item['descripcion']), 0, 120, '...') ?>
                                </p>
                                
                                <?php if (!empty($item['lugar'])): ?>
                                    <small class="card-descubrir__lugar">
                                        <svg class="svg-icon svg-icon--rosa" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                        </svg>
                                        Ubicación: <?= htmlspecialchars($item['lugar']) ?>
                                    </small>
                                <?php endif; ?>

                                <div class="card-descubrir__footer">
                                    <div class="contador-comentarios">
                                        <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
                                        </svg>
                                        <span><?= (int)$item['total_comentarios'] ?></span>
                                    </div>
                                    <a href="/descubrir/ver?id=<?= $item['id'] ?>" class="card-descubrir__link">Ver detalles →</a>
                                </div>
                            </div>
                        </section>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="sin-resultados">
                        <p>No se encontraron resultados en el ecosistema con esos criterios.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- ── VENTANA MODAL PARA CREAR PUBLICACIÓN ── -->
    <div class="modal" id="modal-publicacion">
        <div class="modal__contenido">
            <button class="modal__cerrar" id="btn-cerrar-modal">&times;</button>
            <h2 class="modal__titulo">Nueva Publicación</h2>
            
            <form action="/descubrir/crear" method="POST" enctype="multipart/form-data" class="modal__formulario">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-tipo">¿Qué vas a publicar?</label>
                    <select id="modal-tipo" name="tipo" class="input-control" required>
                        <option value="evento">Evento de baile</option>
                        <option value="noticia">Noticia o Novedad</option>
                    </select>
                </div>

                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-titulo">Título</label>
                    <input type="text" id="modal-titulo" name="titulo" class="input-control" placeholder="Ej: Taller intensivo de Salsa Bachata" required maxlength="255">
                </div>

                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-descripcion">Descripción / Contenido</label>
                    <textarea id="modal-descripcion" name="descripcion" class="input-control" rows="4" placeholder="Escribe todos los detalles de la publicación aquí..." required></textarea>
                </div>

                <!-- Campos dinámicos compartidos (Requeridos obligatoriamente para Eventos, opcionales/ocultables para Noticias si se desea) -->
                <div class="grupo-input" id="contenedor-fecha">
                    <label class="grupo-input__etiqueta" for="modal-fecha">Fecha del Evento</label>
                    <input type="datetime-local" id="modal-fecha" name="fecha" class="input-control">
                </div>

                <div class="grupo-input" id="contenedor-lugar">
                    <label class="grupo-input__etiqueta" for="modal-lugar">Lugar / Ubicación</label>
                    <input type="text" id="modal-lugar" name="lugar" class="input-control" placeholder="Ej: Calle Gran Vía 45, Madrid">
                </div>

                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-foto">Imagen de portada (Opcional)</label>
                    <input type="file" id="modal-foto" name="foto" class="input-control" accept="image/*">
                </div>

                <div class="modal__acciones">
                    <button type="button" class="btn-buscar" id="btn-cancelar-modal" style="height:auto;">Cancelar</button>
                    <button type="submit" class="btn-crear">Guardar Publicación</button>
                </div>
            </form>
        </div>
    </div>

 <?php include_once(__DIR__.'/partials/footer.php'); ?>

<script src="/js/Descubrir.js"></script>
<script>
    // limiar filtros
    const btnLimpiar = document.getElementById('btn-limpiar-filtros');

    if (btnLimpiar) {
        btnLimpiar.addEventListener('click', () => {
            window.location.href = '/descubrir';
        });
    }
</script>
</body>
</html> 