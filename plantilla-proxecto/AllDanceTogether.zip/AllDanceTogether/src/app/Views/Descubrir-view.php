<?php
// Extracción e higienización segura de datos globales de la aplicación
$nombre_usuario = htmlspecialchars($_SESSION['usuario']['nick'] ?? 'Usuario');

// Persistencia visual del estado de los inputs
$busqueda_actual = htmlspecialchars($_GET['q'] ?? '', ENT_QUOTES, 'UTF-8');
$tipo_actual     = $_GET['tipo'] ?? 'todos';

// Sanitización del avatar de cabecera
$foto_perfil_cruda = $_SESSION['usuario']['foto_url'] ?? '';
if (!empty($foto_perfil_cruda)) {
    $avatar_cabecera = (strpos($foto_perfil_cruda, '/public') === 0) ? substr($foto_perfil_cruda, 7) : $foto_perfil_cruda;
} else {
    $avatar_cabecera = '/uploads/avatars/default-avatar.png';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descubrir — All Dance Together</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --color-fondo:        #03030a;
            --color-superficie:   rgba(10, 11, 28, 0.6);
            --color-tarjeta:      rgba(20, 21, 44, 0.7);
            --color-borde:        #1e1e3f;
            --color-borde-foco:   #ec4899;
            --gradiente-neon:     linear-gradient(135deg, #ec4899 0%, #3b82f6 100%);
            --color-texto:        #ffffff;
            --color-texto-suave:  #94a3b8;
            --color-principal:    #7b5ef8;
            
            --radio-md:           14px;
            --fuente-cuerpo:      'Montserrat', sans-serif;
            --fuente-titulo:      'Poppins', sans-serif;
            --ancho-sidebar:      240px;
            --alto-cabecera:      64px;
        }

        .nav-icono {
            width: 18px;
            height: 18px;
            flex-shrink: 0;
            opacity: 0.7;
        }
        body {
            font-family: var(--fuente-cuerpo);
            background-color: var(--color-fondo);
            background-image:
                radial-gradient(circle at 15% 25%, rgba(236, 72, 153, 0.08) 0%, transparent 50%),
                radial-gradient(circle at 85% 75%, rgba(59, 130, 246, 0.08) 0%, transparent 50%);
            color: var(--color-texto);
            min-height: 100dvh;
            display: flex;
            flex-direction: column;
        }

        /* ── Cabecera ── */
        .cabecera {
            height: var(--alto-cabecera);
            padding: 0 clamp(1rem, 3vw, 2rem);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: rgba(3, 3, 10, 0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(30, 30, 63, 0.5);
            position: sticky; top: 0; z-index: 200; gap: 1rem;
        }
        .cabecera__marca { display: flex; align-items: center; text-decoration: none; color: inherit; }
        .cabecera__nombre {
            font-family: var(--fuente-titulo); font-size: clamp(1.1rem, 3vw, 1.5rem); font-weight: 700;
            background: linear-gradient(90deg, #fff 0%, var(--color-principal) 100%);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .cabecera__menu-btn {
            display: none; background: none; border: 1px solid var(--color-borde);
            border-radius: 6px; color: var(--color-texto-suave); cursor: pointer; padding: 0.45rem 0.55rem;
        }
        .cabecera__perfil { display: flex; align-items: center; gap: 0.6rem; background: none; border: none; color: inherit; font-weight: 600; font-size: 0.875rem; cursor: pointer; }
        .cabecera__avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--gradiente-neon); padding: 2px; }
        .cabecera__avatar-imagen { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; display: block; background-color: var(--color-fondo); }

        /* ── Layout Grid Estructura ── */
        .contenedor-principal { flex: 1; display: grid; grid-template-columns: var(--ancho-sidebar) 1fr; }
        .overlay-sidebar { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 150; }
        .overlay-sidebar.activo { display: block; }

        /* ── Sidebar ── */
        .navegacion-lateral {
            background-color: rgba(5, 5, 15, 0.6); border-right: 1px solid rgba(30, 30, 63, 0.4);
            padding: 1.75rem 1rem; display: flex; flex-direction: column; justify-content: space-between;
            position: sticky; top: var(--alto-cabecera); height: calc(100dvh - var(--alto-cabecera)); overflow-y: auto;
        }
        .navegacion-lateral__lista { display: flex; flex-direction: column; gap: 0.35rem; list-style: none; }
        .navegacion-lateral__enlace {
            display: flex; align-items: center; gap: 0.7rem; padding: 0.75rem 1rem; color: var(--color-texto-suave);
            text-decoration: none; border-radius: 10px; font-weight: 500; font-size: 0.9rem; border: 1px solid transparent; transition: all 0.2s;
        }
        .navegacion-lateral__enlace:hover { color: #fff; background-color: rgba(255,255,255,0.04); }
        .navegacion-lateral__enlace--activo { color: #fff; background-color: rgba(123, 94, 248, 0.15); border-color: rgba(123, 94, 248, 0.3); }

        /* ── Área de Trabajo ── */
        .principal { padding: clamp(1.5rem, 4vw, 3rem) clamp(1rem, 4vw, 2.5rem); min-width: 0; }
        
        .encabezado-seccion { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; gap: 1rem; }
        .encabezado-seccion__titulo { font-family: var(--fuente-titulo); font-size: 2rem; font-weight: 700; margin-bottom: 0.4rem; }
        .encabezado-seccion__subtitulo { color: var(--color-texto-suave); font-size: 0.95rem; }

        .btn-crear {
            background: var(--gradiente-neon); color: #fff; border: none; border-radius: 8px;
            padding: 0.75rem 1.5rem; font-family: inherit; font-weight: 600; cursor: pointer; transition: transform 0.2s;
            display: flex; align-items: center; gap: 0.5rem; box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        .btn-crear:hover { transform: scale(1.02); }

        /* Formulario Filtros */
        .barra-busqueda {
            background-color: var(--color-superficie); border: 1px solid var(--color-borde);
            border-radius: var(--radio-md); padding: 1.5rem; margin-bottom: 2.5rem;
            backdrop-filter: blur(20px); box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .formulario-filtros { display: grid; grid-template-columns: 1fr auto auto; gap: 1rem; align-items: flex-end; }
        
        .grupo-input { display: flex; flex-direction: column; gap: 0.5rem; }
        .grupo-input__etiqueta { font-size: 0.75rem; font-weight: 600; color: var(--color-texto-suave); text-transform: uppercase; letter-spacing: 0.5px; }
        
        .input-control {
            background-color: rgba(3, 3, 10, 0.6); border: 1px solid var(--color-borde);
            border-radius: 8px; padding: 0.75rem 1rem; color: #fff; font-family: inherit; font-size: 0.95rem; transition: border-color 0.2s; width: 100%;
        }
        .input-control:focus { outline: none; border-color: var(--color-borde-foco); }

        .btn-buscar {
            background: rgba(255, 255, 255, 0.08); color: #fff; border: 1px solid var(--color-borde); border-radius: 8px;
            padding: 0.75rem 2rem; font-family: inherit; font-weight: 600; cursor: pointer; height: 46px; transition: background 0.2s;
        }
        .btn-buscar:hover { background: rgba(255, 255, 255, 0.15); }

        /* Alertas */
        .alerta { padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.9rem; font-weight: 500; }
        .alerta--exito { background-color: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; color: #10b981; }
        .alerta--error { background-color: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; color: #ef4444; }

        /* Cards Grid */
        .grid-descubrir { display: grid; grid-template-columns: repeat(auto-fill, minmax(310px, 1fr)); gap: 1.75rem; }
        
        .card-descubrir {
            background-color: var(--color-tarjeta); border: 1px solid var(--color-borde);
            border-radius: var(--radio-md); overflow: hidden; display: flex; flex-direction: column;
            transition: transform 0.25s ease, border-color 0.25s ease;
        }
        .card-descubrir:hover { transform: translateY(-4px); border-color: rgba(236, 72, 153, 0.4); }

        .card-descubrir__imagen-wrapper { width: 100%; height: 180px; position: relative; background: #0c0d21; }
        .card-descubrir__img { width: 100%; height: 100%; object-fit: cover; }
        
        .badge-tipo-item {
            position: absolute; top: 12px; left: 12px; font-size: 0.7rem; font-weight: 700;
            text-transform: uppercase; padding: 0.25rem 0.6rem; border-radius: 4px; color: #fff; letter-spacing: 0.5px;
        }
        .badge-tipo-item--evento { background: #7b5ef8; }
        .badge-tipo-item--noticia { background: #ec4899; }

        .card-descubrir__contenido { padding: 1.25rem; display: flex; flex-direction: column; flex: 1; gap: 0.75rem; }
        .card-descubrir__titulo { font-family: var(--fuente-titulo); font-size: 1.2rem; font-weight: 600; line-height: 1.3; color: #fff; }
        .card-descubrir__txt { font-size: 0.85rem; color: var(--color-texto-suave); line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
        
        .card-descubrir__footer { margin-top: auto; padding-top: 1rem; border-top: 1px solid rgba(30, 30, 63, 0.4); }
        .card-descubrir__link { color: #3b82f6; text-decoration: none; font-size: 0.85rem; font-weight: 600; }
        .card-descubrir__link:hover { text-decoration: underline; color: #60a5fa; }

        /* Ajustes específicos para los nuevos iconos SVG en línea */
        .svg-icon { display: inline-block; vertical-align: middle; fill: currentColor; width: 16px; height: 16px; }
        .btn-favorito { background: none; border: none; color: #94a3b8; cursor: pointer; padding: 4px; transition: color 0.2s; }
        .btn-favorito:hover { color: #ec4899; }
        .sin-resultados { grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: var(--color-texto-suave); }
        .pie-pagina { padding: 1.25rem 2rem; background-color: rgba(3, 3, 10, 0.9); border-top: 1px solid rgba(30, 30, 63, 0.3); text-align: center; font-size: 0.75rem; color: var(--color-texto-suave); margin-top: auto; }

        /* ── Ventana Modal Estilos ── */
        .modal {
            position: fixed; inset: 0; background-color: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center;
            z-index: 1000; opacity: 0; pointer-events: none; transition: opacity 0.3s ease; padding: 1rem;
        }
        .modal.activo { opacity: 1; pointer-events: all; }
        .modal__contenido {
            background-color: #0b0c1e; border: 1px solid var(--color-borde); border-radius: var(--radio-md);
            width: 100%; max-width: 550px; padding: 2rem; box-shadow: 0 20px 50px rgba(0,0,0,0.5);
            max-height: 90vh; overflow-y: auto; position: relative;
        }
        .modal__titulo { font-family: var(--fuente-titulo); font-size: 1.5rem; margin-bottom: 1.5rem; }
        .modal__cerrar {
            position: absolute; top: 1.25rem; right: 1.25rem; background: none; border: none;
            color: var(--color-texto-suave); font-size: 1.5rem; cursor: pointer;
        }
        .modal__cerrar:hover { color: #fff; }
        .modal__formulario { display: flex; flex-direction: column; gap: 1.25rem; }
        .modal__acciones { display: flex; justify-content: flex-end; gap: 1rem; margin-top: 0.5rem; }

        @media (max-width: 820px) {
            .contenedor-principal { grid-template-columns: 1fr; }
            .cabecera__menu-btn { display: block; }
            .navegacion-lateral { position: fixed; top: 0; left: 0; bottom: 0; width: var(--ancho-sidebar); transform: translateX(-100%); transition: transform 0.3s; z-index: 300; background: #050512; }
            .navegacion-lateral.abierto { transform: translateX(0); }
            .formulario-filtros { grid-template-columns: 1fr; }
            .encabezado-seccion { flex-direction: column; align-items: flex-start; }
            .btn-crear { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>

    <header class="cabecera">
        <button class="cabecera__menu-btn" id="btn-menu" aria-label="Abrir menú">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><rect y="3" width="20" height="2"/><rect y="9" width="20" height="2"/><rect y="15" width="20" height="2"/></svg>
        </button>
        <a href="/inicio" class="cabecera__marca">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <button class="cabecera__perfil">
            <span><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img class="cabecera__avatar-imagen" src="<?= $avatar_cabecera ?>" alt="Avatar">
            </span>
        </button>
    </header>

    <div class="contenedor-principal">
        <nav class="navegacion-lateral" id="sidebar-nav" aria-label="Navegación principal">
            <ul class="navegacion-lateral__lista">
                <li>
                    <a class="navegacion-lateral__enlace navegacion-lateral__enlace--activo" href="/inicio" aria-current="page">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/eventos">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/usuarios">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/perfil">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/logout"
                    onclick="return confirm('¿Seguro que quieres cerrar sesión?')">
                        <svg class="nav-icono" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                            <polyline points="16 17 21 12 16 7"/>
                            <line x1="21" y1="12" x2="9" y2="12"/>
                        </svg>
                        Cerrar sesión
                    </a>
                </li>
            </ul>
        </nav>

        <div class="overlay-sidebar" id="overlay-sidebar"></div>

        <main class="principal">
            
            <!-- Mensajes de respuesta tras la creación -->
            <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito"><?= $_SESSION['msg_exito']; unset($_SESSION['msg_exito']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error"><?= $_SESSION['msg_error']; unset($_SESSION['msg_error']); ?></div>
            <?php endif; ?>

            <section class="encabezado-seccion">
                <div>
                    <h1 class="encabezado-seccion__titulo">Descubrir</h1>
                    <p class="encabezado-seccion__subtitulo">Explora eventos y noticias reales de la comunidad.</p>
                </div>
                <button class="btn-crear" id="btn-abrir-modal">
                     Crear Publicación
                </button>
            </section>

            <div class="barra-busqueda">
                <form action="/descubrir" method="GET" class="formulario-filtros">
                    <div class="grupo-input">
                        <label class="grupo-input__etiqueta" for="q">Búsqueda libre</label>
                        <input type="text" id="q" name="q" class="input-control" placeholder="Buscar palabras clave..." value="<?= $busqueda_actual ?>">
                    </div>

                    <div class="grupo-input">
                        <label class="grupo-input__etiqueta" for="tipo">Tipo</label>
                        <select id="tipo" name="tipo" class="input-control" style="width: 160px;">
                            <option value="todos" <?= $tipo_actual === 'todos' ? 'selected' : '' ?>>Todos</option>
                            <option value="evento" <?= $tipo_actual === 'evento' ? 'selected' : '' ?>>Eventos</option>
                            <option value="noticia" <?= $tipo_actual === 'noticia' ? 'selected' : '' ?>>Noticias</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-buscar">Filtrar</button>
                </form>
            </div>

            <div class="grid-descubrir">
                <?php if (!empty($resultados)): ?>
                    <?php foreach ($resultados as $item): ?>
                        <section class="card-descubrir">
                            <div class="card-descubrir__imagen-wrapper">
                                <span class="badge-tipo-item badge-tipo-item--<?= $item['tipo_item'] ?>">
                                    <?= htmlspecialchars($item['tipo_item']) ?>
                                </span>
                                
                                <?php if (!empty($item['foto_url'])): ?>
                                    <img class="card-descubrir__img" src="<?= htmlspecialchars($item['foto_url']) ?>" alt="Imagen">
                                <?php else: ?>
                                    <img class="card-descubrir__img" src="/uploads/default-placeholder.jpg" alt="Predeterminada">
                                <?php endif; ?>
                            </div>

                            <div class="card-descubrir__contenido">
                                <h2 class="card-descubrir__titulo"><?= htmlspecialchars($item['titulo']) ?></h2>
                                
                                <p class="card-descubrir__txt">
                                    <?= mb_strimwidth(htmlspecialchars($item['descripcion']), 0, 120, '...') ?>
                                </p>
                                
                                <?php if(!empty($item['lugar'])): ?>
                                    <small style="color: var(--color-texto-suave); display: inline-flex; align-items: center; gap: 4px;">
                                        <svg class="svg-icon" viewBox="0 0 24 24" style="color: #ec4899;"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                                        Ubicación: <?= htmlspecialchars($item['lugar']) ?>
                                    </small>
                                <?php endif; ?>

                                <div class="card-descubrir__footer" style="display:flex; justify-content:space-between; align-items:center;">
                                   
                                    
                                    <div class="contador-comentarios" style="display: inline-flex; align-items: center; gap: 4px; color: var(--color-texto-suave); font-size: 0.85rem;">
                                        <svg class="svg-icon" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
                                        <span><?= (int)$item['total_comentarios'] ?></span>
                                    </div>
                                    
                                    <a href="/descubrir/ver?id=<?= $item['id'] ?>" class="card-descubrir__link">Ver detalles →</a>
                                </div>
                            </div>
                        </section>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="sin-resultados">
                        <p>No se encontraron resultados en el ecosistema con esos criterios.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- ── VENTANA MODAL PARA CREAR PUBLICACIÓN ── -->
    <div class="modal" id="modal-publicacion">
        <div class="modal__contenido">
            <button class="modal__cerrar" id="btn-cerrar-modal">&times;</button>
            <h2 class="modal__titulo">Nueva Publicación</h2>
            
            <form action="/descubrir/crear" method="POST" enctype="multipart/form-data" class="modal__formulario">
                
                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-tipo">¿Qué vas a publicar?</label>
                    <select id="modal-tipo" name="tipo" class="input-control" required>
                        <option value="evento">Evento de baile</option>
                        <option value="noticia">Noticia o Novedad</option>
                    </select>
                </div>

                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-titulo">Título</label>
                    <input type="text" id="modal-titulo" name="titulo" class="input-control" placeholder="Ej: Taller intensivo de Salsa Bachata" required maxlength="255">
                </div>

                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-descripcion">Descripción / Contenido</label>
                    <textarea id="modal-descripcion" name="descripcion" class="input-control" rows="4" placeholder="Escribe todos los detalles de la publicación aquí..." required></textarea>
                </div>

                <!-- Campos dinámicos compartidos (Requeridos obligatoriamente para Eventos, opcionales/ocultables para Noticias si se desea) -->
                <div class="grupo-input" id="contenedor-fecha">
                    <label class="grupo-input__etiqueta" for="modal-fecha">Fecha del Evento</label>
                    <input type="datetime-local" id="modal-fecha" name="fecha" class="input-control">
                </div>

                <div class="grupo-input" id="contenedor-lugar">
                    <label class="grupo-input__etiqueta" for="modal-lugar">Lugar / Ubicación</label>
                    <input type="text" id="modal-lugar" name="lugar" class="input-control" placeholder="Ej: Calle Gran Vía 45, Madrid">
                </div>

                <div class="grupo-input">
                    <label class="grupo-input__etiqueta" for="modal-foto">Imagen de portada (Opcional)</label>
                    <input type="file" id="modal-foto" name="foto" class="input-control" accept="image/*">
                </div>

                <div class="modal__acciones">
                    <button type="button" class="btn-buscar" id="btn-cancelar-modal" style="height:auto;">Cancelar</button>
                    <button type="submit" class="btn-crear">Guardar Publicación</button>
                </div>
            </form>
        </div>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <nav aria-label="Enlaces legales y de ayuda">
            <ul class="pie-pagina__navegacion">
                <li><a class="pie-pagina__enlace" href="/politicas">Política de privacidad</a></li>
                <li><a class="pie-pagina__enlace" href="/terminos">Términos de uso</a></li>
                <li><a class="pie-pagina__enlace" href="/contacto">Contacto</a></li>
                <li><a class="pie-pagina__enlace" href="/ayuda">Ayuda</a></li>
            </ul>
        </nav>
        <p class="pie-pagina__copiar">
            <small>© 2026 All Dance Together. Todos los derechos reservados.</small>
        </p>
    </footer>

<script src="/js/Descubrir.js"></script>
</body>
</html> 