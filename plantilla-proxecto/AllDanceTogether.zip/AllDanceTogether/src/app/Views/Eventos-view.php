<?php
/**
 * Vista del Tablón de Próximos Eventos.
 * * Renderiza la cartelera de la comunidad dividida cronológicamente, organizando 
 * los listados de eventos entre el mes en curso y fechas futuras mediante tarjetas dinámicas.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
    <title>Próximos Eventos — All Dance Together</title>
    <link rel="stylesheet" href="/css/Eventos.css">
    <link rel="stylesheet" href="/css/Global.css">
</head>
<body>

    <h1 class="sr-only">All Dance Together</h1>
    <a class="saltar-contenido" href="#contenido-principal">Saltar al contenido principal</a>
    <div class="overlay-sidebar" id="overlay-sidebar" aria-hidden="true"></div>

    <?php include_once(__DIR__ . '/partials/header.php'); ?>

    <div class="contenedor-principal">

        <?php include_once(__DIR__ . '/partials/menu.php'); ?>

        <main class="principal" id="contenido-principal">

            <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito" role="alert">
                    <?= htmlspecialchars($_SESSION['msg_exito'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['msg_exito']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error" role="alert">
                    <?= htmlspecialchars($_SESSION['msg_error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['msg_error']); ?>
                </div>
            <?php endif; ?>

            <section class="encabezado-seccion" aria-labelledby="titulo-pagina">
                <div>
                    <h2 id="titulo-pagina" class="encabezado-seccion__titulo">Próximos Eventos</h2>
                    <p class="encabezado-seccion__subtitulo">Descubre los eventos de baile que están por venir.</p>
                </div>
            </section>

            <section class="seccion-eventos" aria-labelledby="titulo-este-mes">
                <h3 id="titulo-este-mes" class="seccion-eventos__titulo">
                    <span class="seccion-eventos__titulo-punto" aria-hidden="true"></span>
                    Este mes
                </h3>
                <?php if (!empty($eventos_mes)): ?>
                    <div class="lista-eventos" role="list">
                        <?php foreach ($eventos_mes as $evento): ?>
                            <div role="listitem"><?php renderCardEvento($evento); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="sin-resultados" role="status">
                        <p>No hay eventos programados para este mes.</p>
                    </div>
                <?php endif; ?>
            </section>

            <section class="seccion-eventos" aria-labelledby="titulo-proximos">
                <h3 id="titulo-proximos" class="seccion-eventos__titulo">
                    <span class="seccion-eventos__titulo-punto" aria-hidden="true"></span>
                    Próximos eventos
                </h3>
                <?php if (!empty($proximos_eventos)): ?>
                    <div class="lista-eventos" role="list">
                        <?php foreach ($proximos_eventos as $evento): ?>
                            <div role="listitem"><?php renderCardEvento($evento); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="sin-resultados" role="status">
                        <p>No hay eventos futuros programados por el momento.</p>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </div>

    <?php include_once(__DIR__ . '/partials/footer.php'); ?>

    <script src="/js/Eventos.js"></script>
</body>
</html>