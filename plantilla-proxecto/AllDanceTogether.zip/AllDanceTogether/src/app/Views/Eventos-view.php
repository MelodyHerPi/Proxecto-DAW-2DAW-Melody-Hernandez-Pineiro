<?php
// Preparación de variables globales de cabecera
$nombre_usuario = htmlspecialchars($_SESSION['usuario']['nick'] ?? 'Usuario');

$foto_perfil_cruda = $_SESSION['usuario']['foto_url'] ?? '';
if (!empty($foto_perfil_cruda)) {
    $avatar_cabecera = (strpos($foto_perfil_cruda, '/public') === 0)
        ? substr($foto_perfil_cruda, 7)
        : $foto_perfil_cruda;
} else {
    $avatar_cabecera = '/uploads/avatars/default-avatar.png';
}

/**
 * Renderiza una card de evento de forma inline.
 * $evento debe contener: foto_url, titulo, descripcion, fecha, lugar, id
 */
function renderCardEvento(array $evento): void
{
    $foto_src = !empty($evento['foto_url'])
        ? htmlspecialchars($evento['foto_url'])
        : '/uploads/default-placeholder.jpg';

    $descripcion_truncada = mb_strimwidth(
        htmlspecialchars($evento['descripcion'] ?? ''),
        0, 130, '…'
    );

    $fecha_formateada = '';
    $fecha_hora       = '';
    if (!empty($evento['fecha'])) {
        $dt = new DateTime($evento['fecha']);

        $dias_es  = ['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
        $meses_es = ['enero','febrero','marzo','abril','mayo','junio',
                     'julio','agosto','septiembre','octubre','noviembre','diciembre'];

        $dia_semana = $dias_es[(int)$dt->format('w')];
        $dia_num    = (int)$dt->format('j');
        $mes        = $meses_es[(int)$dt->format('n') - 1];
        $anio       = $dt->format('Y');

        $fecha_formateada = "{$dia_semana}, {$dia_num} de {$mes} de {$anio}";
        $fecha_hora       = $dt->format('H:i');
    }

    $titulo_escapado = htmlspecialchars($evento['titulo'] ?? '');
    $lugar_escapado  = htmlspecialchars($evento['lugar']  ?? '');
    $evento_id       = (int)($evento['id'] ?? 0);
    ?>
    <article class="card-evento" aria-label="Evento: <?= $titulo_escapado ?>">
        <div class="card-evento__imagen-wrapper">
            <img
                class="card-evento__img"
                src="<?= $foto_src ?>"
                alt="Imagen del evento: <?= $titulo_escapado ?>"
                loading="lazy"
                width="220"
                height="160"
            >
            <span class="badge-tipo-item badge-tipo-item--evento" aria-hidden="true">Evento</span>
        </div>
        <div class="card-evento__contenido">
            <h2 class="card-evento__titulo"><?= $titulo_escapado ?></h2>

            <?php if ($fecha_formateada): ?>
                <p class="card-evento__fecha">
                    <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M19 4h-1V2h-2v2H8V2H6v2H5C3.9 4 3 4.9 3 6v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11zM7 11h5v5H7z"/>
                    </svg>
                    <time datetime="<?= htmlspecialchars($evento['fecha']) ?>">
                        <?= ucfirst($fecha_formateada) ?>
                        <?php if ($fecha_hora !== '00:00'): ?>
                            &nbsp;·&nbsp;<?= $fecha_hora ?>h
                        <?php endif; ?>
                    </time>
                </p>
            <?php endif; ?>

            <?php if (!empty($evento['lugar'])): ?>
                <p class="card-evento__lugar">
                    <svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" style="color:#ec4899;">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                    </svg>
                    <?= $lugar_escapado ?>
                </p>
            <?php endif; ?>

            <p class="card-evento__descripcion"><?= $descripcion_truncada ?></p>

            <div class="card-evento__footer">
                <a
                    href="/descubrir/ver?id=<?= $evento_id ?>"
                    class="card-descubrir__link"
                    aria-label="Ver detalles de <?= $titulo_escapado ?>"
                >
                    Ver detalles →
                </a>
            </div>
        </div>
    </article>
    <?php
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Próximos Eventos — All Dance Together</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --color-fondo:        #03030a;
            --color-superficie:   rgba(10, 11, 28, 0.6);
            --color-tarjeta:      rgba(20, 21, 44, 0.7);
            --color-borde:        #1e1e3f;
            --color-borde-foco:   #ec4899;
            --gradiente-neon:     linear-gradient(135deg, #ec4899 0%, #3b82f6 100%);
            --color-texto:        #ffffff;
            --color-texto-suave:  #94a3b8;
            --color-principal:    #7b5ef8;
            --radio-md:           14px;
            --fuente-cuerpo:      'Montserrat', sans-serif;
            --fuente-titulo:      'Poppins', sans-serif;
            --ancho-sidebar:      240px;
            --alto-cabecera:      64px;
        }

        /* ── Accesibilidad ── */
        :focus-visible {
            outline: 2px solid var(--color-borde-foco);
            outline-offset: 3px;
            border-radius: 4px;
        }

        /* Ocultar visualmente pero accesible para lectores de pantalla */
        .sr-only {
            position: absolute; width: 1px; height: 1px;
            padding: 0; margin: -1px; overflow: hidden;
            clip: rect(0,0,0,0); white-space: nowrap; border: 0;
        }

        .nav-icono { width: 18px; height: 18px; flex-shrink: 0; opacity: 0.7; }

        body {
            font-family: var(--fuente-cuerpo);
            background-color: var(--color-fondo);
            background-image:
                radial-gradient(circle at 15% 25%, rgba(236, 72, 153, 0.08) 0%, transparent 50%),
                radial-gradient(circle at 85% 75%, rgba(59, 130, 246, 0.08) 0%, transparent 50%);
            color: var(--color-texto);
            min-height: 100dvh;
            display: flex;
            flex-direction: column;
        }

        /* ── Cabecera ── */
        .cabecera {
            height: var(--alto-cabecera);
            padding: 0 clamp(1rem, 3vw, 2rem);
            display: flex; align-items: center; justify-content: space-between;
            background-color: rgba(3, 3, 10, 0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(30, 30, 63, 0.5);
            position: sticky; top: 0; z-index: 200; gap: 1rem;
        }
        .cabecera__marca {
            display: flex; align-items: center; text-decoration: none; color: inherit;
        }
        .cabecera__nombre {
            font-family: var(--fuente-titulo); font-size: clamp(1.1rem, 3vw, 1.5rem); font-weight: 700;
            background: linear-gradient(90deg, #fff 0%, var(--color-principal) 100%);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .cabecera__menu-btn {
            display: none; background: none; border: 1px solid var(--color-borde);
            border-radius: 6px; color: var(--color-texto-suave); cursor: pointer;
            padding: 0.45rem 0.55rem; min-width: 40px; min-height: 40px;
            align-items: center; justify-content: center;
        }
        .cabecera__perfil {
            display: flex; align-items: center; gap: 0.6rem;
            background: none; border: none; color: inherit;
            font-weight: 600; font-size: 0.875rem; cursor: pointer;
            font-family: var(--fuente-cuerpo);
            min-height: 40px; padding: 0.25rem 0.5rem; border-radius: 8px;
        }
        .cabecera__avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--gradiente-neon); padding: 2px; flex-shrink: 0; }
        .cabecera__avatar-imagen { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; display: block; background-color: var(--color-fondo); }

        /* ── Layout ── */
        .contenedor-principal { flex: 1; display: grid; grid-template-columns: var(--ancho-sidebar) 1fr; }
        .overlay-sidebar {
            display: none; position: fixed; inset: 0;
            background: rgba(0,0,0,0.6); z-index: 150;
        }
        .overlay-sidebar.activo { display: block; }

        /* ── Sidebar ── */
        .navegacion-lateral {
            background-color: rgba(5, 5, 15, 0.6);
            border-right: 1px solid rgba(30, 30, 63, 0.4);
            padding: 1.75rem 1rem;
            display: flex; flex-direction: column; justify-content: space-between;
            position: sticky; top: var(--alto-cabecera);
            height: calc(100dvh - var(--alto-cabecera));
            overflow-y: auto;
        }
        .navegacion-lateral__lista { display: flex; flex-direction: column; gap: 0.35rem; list-style: none; }
        .navegacion-lateral__enlace {
            display: flex; align-items: center; gap: 0.7rem;
            padding: 0.75rem 1rem; color: var(--color-texto-suave);
            text-decoration: none; border-radius: 10px;
            font-weight: 500; font-size: 0.9rem;
            border: 1px solid transparent; transition: all 0.2s;
            min-height: 44px; /* touch target mínimo */
        }
        .navegacion-lateral__enlace:hover { color: #fff; background-color: rgba(255,255,255,0.04); }
        .navegacion-lateral__enlace--activo {
            color: #fff; background-color: rgba(123, 94, 248, 0.15);
            border-color: rgba(123, 94, 248, 0.3);
        }

        /* ── Área principal ── */
        .principal { padding: clamp(1.5rem, 4vw, 3rem) clamp(1rem, 4vw, 2.5rem); min-width: 0; }

        .encabezado-seccion {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 2rem; gap: 1rem;
        }
        .encabezado-seccion__titulo {
            font-family: var(--fuente-titulo); font-size: clamp(1.5rem, 4vw, 2rem);
            font-weight: 700; margin-bottom: 0.4rem;
        }
        .encabezado-seccion__subtitulo { color: var(--color-texto-suave); font-size: 0.95rem; }

        /* Alertas */
        .alerta {
            padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;
            font-size: 0.9rem; font-weight: 500;
        }
        .alerta--exito { background-color: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; color: #10b981; }
        .alerta--error  { background-color: rgba(239, 68, 68, 0.15);  border: 1px solid #ef4444; color: #ef4444; }

        /* ── Secciones temporales ── */
        .seccion-eventos { margin-bottom: 3.5rem; }
        .seccion-eventos__titulo {
            font-family: var(--fuente-titulo);
            font-size: 1.25rem; font-weight: 700;
            margin-bottom: 1.25rem; padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--color-borde);
            display: flex; align-items: center; gap: 0.6rem;
        }
        .seccion-eventos__titulo-punto {
            display: inline-block; width: 10px; height: 10px;
            border-radius: 50%; background: var(--gradiente-neon); flex-shrink: 0;
        }

        /* ── Cards horizontales ── */
        .lista-eventos { display: flex; flex-direction: column; gap: 1.25rem; }

        .card-evento {
            background-color: var(--color-tarjeta);
            border: 1px solid var(--color-borde);
            border-radius: var(--radio-md);
            overflow: hidden;
            display: flex; flex-direction: row;
            transition: transform 0.25s ease, border-color 0.25s ease;
            min-height: 160px;
        }
        .card-evento:hover { transform: translateY(-3px); border-color: rgba(236, 72, 153, 0.4); }

        /* Reduce movimiento si el usuario lo prefiere */
        @media (prefers-reduced-motion: reduce) {
            .card-evento { transition: border-color 0.25s ease; }
            .card-evento:hover { transform: none; }
        }

        /* Imagen lateral izquierda */
        .card-evento__imagen-wrapper {
            width: 220px; min-width: 220px;
            position: relative; background: #0c0d21;
            overflow: hidden; flex-shrink: 0;
        }
        .card-evento__img {
            width: 100%; height: 100%;
            object-fit: cover; display: block;
        }

        .badge-tipo-item {
            position: absolute; top: 12px; left: 12px;
            font-size: 0.7rem; font-weight: 700; text-transform: uppercase;
            padding: 0.25rem 0.6rem; border-radius: 4px;
            color: #fff; letter-spacing: 0.5px;
        }
        .badge-tipo-item--evento { background: #7b5ef8; }

        /* Contenido derecho */
        .card-evento__contenido {
            padding: 1.25rem 1.5rem;
            display: flex; flex-direction: column;
            flex: 1; gap: 0.5rem; min-width: 0;
        }

        .card-evento__titulo {
            font-family: var(--fuente-titulo);
            font-size: 1.1rem; font-weight: 600;
            line-height: 1.35; color: #fff;
            /* Truncado solo en escritorio donde hay una sola línea disponible */
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }

        .card-evento__fecha {
            display: flex; align-items: center; gap: 6px;
            font-size: 0.8rem; font-weight: 600;
            color: #7b5ef8; text-transform: capitalize;
            flex-wrap: wrap;
        }

        .card-evento__lugar {
            display: flex; align-items: center; gap: 6px;
            font-size: 0.8rem; color: var(--color-texto-suave);
        }

        .card-evento__descripcion {
            font-size: 0.85rem; color: var(--color-texto-suave);
            line-height: 1.55;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            flex: 1;
        }

        .card-evento__footer {
            margin-top: auto; padding-top: 0.85rem;
            border-top: 1px solid rgba(30, 30, 63, 0.4);
        }

        .card-descubrir__link {
            color: #3b82f6; text-decoration: none;
            font-size: 0.85rem; font-weight: 600;
            display: inline-block; min-height: 44px;
            line-height: 44px;
        }
        .card-descubrir__link:hover { text-decoration: underline; color: #60a5fa; }

        .svg-icon {
            display: inline-block; vertical-align: middle;
            fill: currentColor; width: 15px; height: 15px; flex-shrink: 0;
        }

        /* Sin resultados */
        .sin-resultados {
            padding: 3rem 2rem; text-align: center;
            color: var(--color-texto-suave); font-size: 0.95rem;
        }

        /* Pie */
        .pie-pagina {
            padding: 1.25rem 2rem;
            background-color: rgba(3, 3, 10, 0.9);
            border-top: 1px solid rgba(30, 30, 63, 0.3);
            text-align: center; font-size: 0.75rem;
            color: var(--color-texto-suave); margin-top: auto;
        }

        /* ── Responsive ── */
        @media (max-width: 820px) {
            .contenedor-principal { grid-template-columns: 1fr; }
            .cabecera__menu-btn { display: flex; }
            .navegacion-lateral {
                position: fixed; top: 0; left: 0; bottom: 0;
                width: var(--ancho-sidebar); transform: translateX(-100%);
                transition: transform 0.3s; z-index: 300; background: #050512;
                height: 100dvh; top: 0;
            }
            .navegacion-lateral.abierto { transform: translateX(0); }
            .encabezado-seccion { flex-direction: column; align-items: flex-start; }
        }

        @media (max-width: 600px) {
            /* Card pasa a vertical */
            .card-evento { flex-direction: column; min-height: unset; }
            .card-evento__imagen-wrapper { width: 100%; min-width: unset; height: 200px; }
            .card-evento__titulo {
                -webkit-line-clamp: 3;
                font-size: 1rem;
            }
            .card-evento__contenido { padding: 1rem; }
        }

        @media (max-width: 380px) {
            .card-evento__imagen-wrapper { height: 160px; }
        }

        /* Alto contraste */
        @media (forced-colors: active) {
            .card-evento { border: 2px solid ButtonText; }
            .badge-tipo-item--evento { background: Highlight; color: HighlightText; }
        }
    </style>
</head>
<body>

    <a href="#contenido-principal" class="sr-only">Saltar al contenido principal</a>

    <header class="cabecera" role="banner">
        <button
            class="cabecera__menu-btn"
            id="btn-menu"
            aria-label="Abrir menú de navegación"
            aria-expanded="false"
            aria-controls="sidebar-nav"
        >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" focusable="false">
                <rect y="3" width="20" height="2"/>
                <rect y="9" width="20" height="2"/>
                <rect y="15" width="20" height="2"/>
            </svg>
        </button>
        <a href="/inicio" class="cabecera__marca" aria-label="All Dance Together — Inicio">
            <span class="cabecera__nombre">All Dance Together</span>
        </a>
        <button class="cabecera__perfil" aria-label="Menú de perfil de <?= $nombre_usuario ?>">
            <span aria-hidden="true"><?= $nombre_usuario ?></span>
            <span class="cabecera__avatar">
                <img
                    class="cabecera__avatar-imagen"
                    src="<?= $avatar_cabecera ?>"
                    alt="Avatar de <?= $nombre_usuario ?>"
                    width="34"
                    height="34"
                >
            </span>
        </button>
    </header>

    <div class="contenedor-principal">

        <nav
            class="navegacion-lateral"
            id="sidebar-nav"
            aria-label="Navegación principal"
        >
            <ul class="navegacion-lateral__lista" role="list">
                <li>
                    <a class="navegacion-lateral__enlace" href="/inicio">
                        <svg class="nav-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/descubrir">
                        <svg class="nav-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
                            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                        Descubrir
                    </a>
                </li>
                <li>
                    <a
                        class="navegacion-lateral__enlace navegacion-lateral__enlace--activo"
                        href="/eventos"
                        aria-current="page"
                    >
                        <svg class="nav-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                            <line x1="16" y1="2" x2="16" y2="6"/>
                            <line x1="8" y1="2" x2="8" y2="6"/>
                            <line x1="3" y1="10" x2="21" y2="10"/>
                        </svg>
                        Próximos eventos
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/usuarios">
                        <svg class="nav-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
                            <circle cx="9" cy="7" r="4"/>
                            <path d="M23 21v-2a4 4 0 00-3-3.87"/>
                            <path d="M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                        Usuarios
                    </a>
                </li>
                <li>
                    <a class="navegacion-lateral__enlace" href="/perfil">
                        <svg class="nav-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        Mi perfil
                    </a>
                </li>
                <li>
                    <a
                        class="navegacion-lateral__enlace"
                        href="/logout"
                        onclick="return confirm('¿Seguro que quieres cerrar sesión?')"
                    >
                        <svg class="nav-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                            <polyline points="16 17 21 12 16 7"/>
                            <line x1="21" y1="12" x2="9" y2="12"/>
                        </svg>
                        Cerrar sesión
                    </a>
                </li>
            </ul>
        </nav>

        <div
            class="overlay-sidebar"
            id="overlay-sidebar"
            aria-hidden="true"
        ></div>

        <main class="principal" id="contenido-principal">

            <?php if (isset($_SESSION['msg_exito'])): ?>
                <div class="alerta alerta--exito" role="alert">
                    <?= htmlspecialchars($_SESSION['msg_exito']); unset($_SESSION['msg_exito']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['msg_error'])): ?>
                <div class="alerta alerta--error" role="alert">
                    <?= htmlspecialchars($_SESSION['msg_error']); unset($_SESSION['msg_error']); ?>
                </div>
            <?php endif; ?>

            <section class="encabezado-seccion" aria-labelledby="titulo-pagina">
                <div>
                    <h1 id="titulo-pagina" class="encabezado-seccion__titulo">Próximos Eventos</h1>
                    <p class="encabezado-seccion__subtitulo">Descubre los eventos de baile que están por venir.</p>
                </div>
            </section>

            <!-- ── ESTE MES ── -->
            <section class="seccion-eventos" aria-labelledby="titulo-este-mes">
                <h2 id="titulo-este-mes" class="seccion-eventos__titulo">
                    <span class="seccion-eventos__titulo-punto" aria-hidden="true"></span>
                    Este mes
                </h2>

                <?php if (!empty($eventos_mes)): ?>
                    <div class="lista-eventos" role="list">
                        <?php foreach ($eventos_mes as $evento): ?>
                            <?php renderCardEvento($evento); ?>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="sin-resultados" role="status">
                        <p>No hay eventos programados para este mes.</p>
                    </div>
                <?php endif; ?>
            </section>

            <!-- ── PRÓXIMOS EVENTOS ── -->
            <section class="seccion-eventos" aria-labelledby="titulo-proximos">
                <h2 id="titulo-proximos" class="seccion-eventos__titulo">
                    <span class="seccion-eventos__titulo-punto" aria-hidden="true"></span>
                    Próximos eventos
                </h2>

                <?php if (!empty($proximos_eventos)): ?>
                    <div class="lista-eventos" role="list">
                        <?php foreach ($proximos_eventos as $evento): ?>
                            <?php renderCardEvento($evento); ?>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="sin-resultados" role="status">
                        <p>No hay eventos futuros programados por el momento.</p>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </div>

    <footer class="pie-pagina" role="contentinfo">
        <p><small>© 2026 All Dance Together. Todos los derechos reservados.</small></p>
    </footer>

    <script>
        const btnMenu = document.getElementById('btn-menu');
        const sidebar = document.getElementById('sidebar-nav');
        const overlay = document.getElementById('overlay-sidebar');

        function abrirSidebar() {
            sidebar.classList.add('abierto');
            overlay.classList.add('activo');
            overlay.removeAttribute('aria-hidden');
            btnMenu.setAttribute('aria-expanded', 'true');
            // Trampa de foco: primer enlace del sidebar
            sidebar.querySelector('a')?.focus();
        }

        function cerrarSidebar() {
            sidebar.classList.remove('abierto');
            overlay.classList.remove('activo');
            overlay.setAttribute('aria-hidden', 'true');
            btnMenu.setAttribute('aria-expanded', 'false');
            btnMenu.focus();
        }

        btnMenu?.addEventListener('click', abrirSidebar);
        overlay?.addEventListener('click', cerrarSidebar);

        // Cerrar con Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && sidebar.classList.contains('abierto')) {
                cerrarSidebar();
            }
        });
    </script>

</body>
</html>