<?php
require_once __DIR__ . '/../../core/Database.php';

/**
 * Modelo de Eventos.
 * * Maneja las consultas a la base de datos relacionadas con la agenda,
 * discriminando los eventos según su fecha de ocurrencia en el calendario.
 */
class EventosModel {
    private $bd;

    /**
     * Constructor del modelo.
     * * Conecta la clase con el motor de la base de datos a través del 
     * singleton del núcleo de la aplicación.
     */
    public function __construct() {
        $this->bd = Database::getConnection();
    }

    /**
     * Recupera los eventos programados para el mes actual.
     * * Extrae las publicaciones de tipo 'evento' cuyas fechas coincidan con el 
     * año y mes en curso del servidor, ordenadas cronológicamente.
     */
    public function obtenerEventosEsteMes(): array {
        try {
            $sql = "SELECT id, titulo, descripcion, foto_url, fecha, lugar
                    FROM publicaciones
                    WHERE tipo = 'evento'
                    AND YEAR(fecha)  = YEAR(CURDATE())
                    AND MONTH(fecha) = MONTH(CURDATE())
                    ORDER BY fecha ASC
                    LIMIT 50";

            $stmt = $this->bd->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerEventosEsteMes: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Obtiene los eventos programados a partir del próximo mes.
     * * Calcula dinámicamente el primer día del mes siguiente y extrae las 
     * publicaciones de tipo 'evento' que ocurran a partir de esa fecha.
     */
    public function obtenerProximosEventos(): array {
        try {
            $inicio_proximo_mes = date('Y-m-01 00:00:00', strtotime('first day of next month'));

            $sql = "SELECT id, titulo, descripcion, foto_url, fecha, lugar
                    FROM publicaciones
                    WHERE tipo  = 'evento'
                    AND fecha  >= :inicio_proximo_mes
                    ORDER BY fecha ASC
                    LIMIT 50";

            $stmt = $this->bd->prepare($sql);
            $stmt->bindValue(':inicio_proximo_mes', $inicio_proximo_mes, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerProximosEventos: " . $e->getMessage());
            return [];
        }
    }
}