<?php
require_once __DIR__ . '/../../core/Database.php';

class EventosModel {
    private $bd;

    public function __construct() {
        $this->bd = Database::getConnection();
    }

    /**
     * Obtiene todos los eventos del mes actual.
     * Filtra: tipo = 'evento', fecha dentro del mes/año actuales.
     */
    public function obtenerEventosEsteMes(): array {
        $sql = "SELECT
                    id,
                    titulo,
                    descripcion,
                    foto_url,
                    fecha,
                    lugar
                FROM publicaciones
                WHERE tipo = 'evento'
                  AND YEAR(fecha)  = YEAR(CURDATE())
                  AND MONTH(fecha) = MONTH(CURDATE())
                ORDER BY fecha ASC";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obtiene eventos posteriores al mes actual.
     * Filtra: tipo = 'evento', fecha > último día del mes actual.
     */
    public function obtenerProximosEventos(): array {
        $sql = "SELECT
                    id,
                    titulo,
                    descripcion,
                    foto_url,
                    fecha,
                    lugar
                FROM publicaciones
                WHERE tipo = 'evento'
                  AND fecha > LAST_DAY(CURDATE())
                ORDER BY fecha ASC";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}