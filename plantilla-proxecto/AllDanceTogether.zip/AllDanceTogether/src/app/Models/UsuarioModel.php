<?php
require_once __DIR__ . '/../../core/Database.php';

class UsuarioModel {

    private $bd;

    public function __construct() {
        $this->bd = Database::getConnection();
    }

    // Crear un nuevo usuario (C del CRUD)
    public function registrar($nombre_real, $nombre_app, $email, $password, $id_tipo) {
        $sql = "INSERT INTO usuarios (nombre_real, nombre_app, correo_electronico, contrasena, id_tipo_usuario) 
                VALUES (:nombre, :usuario, :email, :pass, :tipo)";

        $stmt = $this->bd->prepare($sql);

        // Cifrado de contraseña
        $password_cifrada = password_hash($password, PASSWORD_BCRYPT);

        return $stmt->execute([
            ':nombre'  => $nombre_real,
            ':usuario' => $nombre_app,
            ':email'   => $email,
            ':pass'    => $password_cifrada,
            ':tipo'    => $id_tipo
        ]);
    }

    // Buscar para el inicio de sesión
    public function buscarPorIdentificador($identificador) {
        // Nota: Al usar *, ya incluye la columna 'avatar_url' automáticamente
        $sql = "SELECT * FROM usuarios WHERE correo_electronico = :id OR nombre_app = :id";
        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':id' => $identificador]);
        return $stmt->fetch();
    }

    /**
     * Obtiene el listado de usuarios y grupos aplicando filtros de búsqueda.
     * Conecta con 'usuario_tipos' para el nombre del tipo y con 'perfiles' para la descripción.
     */
    public function obtenerUsuariosFiltrados($busqueda_texto, $filtro_tipo) {
        $sql = "SELECT 
                    u.id, 
                    u.nombre_real, 
                    u.nombre_app, 
                    u.avatar_url, 
                    ut.nombre AS tipo_nombre,
                    p.descripcion
                FROM usuarios u
                INNER JOIN usuario_tipos ut ON u.id_tipo_usuario = ut.id
                LEFT JOIN perfiles p ON u.id = p.id_usuario
                WHERE 1=1";

        $parametros = [];

        // Filtro de texto libre (busca coincidencia en nombres o en la biografía/descripción)
        if ($busqueda_texto !== '') {
            $sql .= " AND (u.nombre_real LIKE :buscar_texto 
                        OR u.nombre_app LIKE :buscar_texto 
                        OR p.descripcion LIKE :buscar_texto)";
            $parametros[':buscar_texto'] = '%' . $busqueda_texto . '%';
        }

        // Filtro por tipo de cuenta (Solista = 1 / Grupo = 2)
        if ($filtro_tipo !== 'todos') {
            $sql .= " AND u.id_tipo_usuario = :id_tipo";
            $parametros[':id_tipo'] = (int)$filtro_tipo;
        }

        // Ordenamos alfabéticamente por el nombre real
        $sql .= " ORDER BY u.nombre_real ASC";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute($parametros);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}