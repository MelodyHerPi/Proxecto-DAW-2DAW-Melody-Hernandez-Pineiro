<?php
require_once __DIR__ . '/../../core/Database.php';

/**
 * Modelo de Gestión de Usuarios.
 * * Controla las operaciones de persistencia en la base de datos para las cuentas de usuario,
 * incluyendo procesos de alta, autenticación, control de duplicados y búsquedas filtradas.
 */
class UsuarioModel {
    private $bd;

    /**
     * Constructor del modelo.
     * * Inicializa el acceso a la base de datos solicitando la instancia de conexión 
     * activa al componente central.
     */
    public function __construct() {
        $this->bd = Database::getConnection();
    }

    /**
     * Registra un nuevo usuario en la plataforma.
     * * Inserta las credenciales y datos básicos en la base de datos, encriptando de 
     * forma segura la contraseña mediante el algoritmo nativo bcrypt.
     */
    public function registrar(string $nombre_real, string $nombre_app, string $email, string $password, int $id_tipo): bool {
        try {
            $sql = "INSERT INTO usuarios (nombre_real, nombre_app, correo_electronico, contrasena, id_tipo_usuario) 
                    VALUES (:nombre, :usuario, :email, :pass, :tipo)";
            $stmt = $this->bd->prepare($sql);
            
            return $stmt->execute([
                ':nombre'  => $nombre_real,
                ':usuario' => $nombre_app,
                ':email'   => $email,
                ':pass'    => password_hash($password, PASSWORD_BCRYPT),
                ':tipo'    => $id_tipo
            ]);
        } catch(PDOException $e) {
            error_log("Error en registrar: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Localiza a un usuario para el inicio de sesión.
     * * Busca un registro que coincida de forma indistinta con el apodo de la aplicación 
     * o con la dirección de correo electrónico introducida.
     */
    public function buscarPorIdentificador(string $identificador): array|false {
        try {
            $sql = "SELECT id, nombre_real, nombre_app, correo_electronico, contrasena, id_tipo_usuario, avatar_url 
                    FROM usuarios WHERE correo_electronico = :id OR nombre_app = :id LIMIT 1";
            $stmt = $this->bd->prepare($sql);
            $stmt->execute([':id' => $identificador]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Error en buscarPorIdentificador: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Verifica la disponibilidad de una dirección de correo electrónico.
     * * Consulta si ya existe algún usuario registrado con el email proporcionado 
     * para evitar cuentas duplicadas.
     */
    public function existeCorreo(string $correo): bool {
        try {
            $stmt = $this->bd->prepare("SELECT COUNT(*) FROM usuarios WHERE correo_electronico = :correo");
            $stmt->execute([':correo' => $correo]);
            return (int) $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            error_log("Error en existeCorreo: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Verifica la disponibilidad de un apodo o nombre de usuario.
     * * Comprueba si el identificador público ya se encuentra asignado en la base de datos 
     * para garantizar que sea único.
     */
    public function existeUsuario(string $nombre_app): bool {
        try {
            $stmt = $this->bd->prepare("SELECT COUNT(*) FROM usuarios WHERE nombre_app = :nombre_app");
            $stmt->execute([':nombre_app' => $nombre_app]);
            return (int) $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            error_log("Error en existeUsuario: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Obtiene una lista segmentada y filtrada de la comunidad.
     * * Construye una consulta dinámica con cruce de perfiles para buscar coincidencias por texto 
     * (en nombres o biografías) y restringe opcionalmente los resultados por el tipo de cuenta.
     */
    public function obtenerUsuariosFiltrados(string $busqueda_texto, ?int $filtro_tipo = null, int $limite = 50): array {
        try {
            $sql = "SELECT u.id, u.nombre_real, u.nombre_app, u.avatar_url,
                           ut.nombre AS tipo_nombre,
                           p.descripcion,
                           p.datos_extra
                FROM usuarios u
                INNER JOIN usuario_tipos ut ON u.id_tipo_usuario = ut.id
                LEFT JOIN perfiles p ON u.id = p.id_usuario
                WHERE 1=1";

            $parametros = [];

            if (!empty($busqueda_texto)) {
                $sql .= " AND (u.nombre_real LIKE :buscar_texto
                          OR u.nombre_app LIKE :buscar_texto
                          OR p.descripcion LIKE :buscar_texto)";
                $parametros[':buscar_texto'] = '%' . $busqueda_texto . '%';
            }

            if ($filtro_tipo !== null && $filtro_tipo > 0) {
                $sql .= " AND u.id_tipo_usuario = :id_tipo";
                $parametros[':id_tipo'] = $filtro_tipo;
            }

            $sql .= " ORDER BY u.nombre_real ASC LIMIT :limite";

            $stmt = $this->bd->prepare($sql);

            foreach ($parametros as $clave => $valor) {
                $stmt->bindValue($clave, $valor);
            }
            $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Error en obtenerUsuariosFiltrados: " . $e->getMessage());
            return [];
        }
    }
}