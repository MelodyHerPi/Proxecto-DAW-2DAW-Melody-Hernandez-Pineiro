<?php
require_once __DIR__ . '/../../core/Database.php';

class PerfilModel {
    private $bd;

    public function __construct() {
        $this->bd = Database::getConnection();
    }

    /**
     * Obtiene los datos completos del usuario y su perfil
     */
    public function obtenerPerfilCompleto($id_usuario) {
        $sql = "SELECT 
                    u.id AS usuario_id, 
                    u.nombre_real, 
                    u.nombre_app, 
                    u.correo_electronico, 
                    u.id_tipo_usuario,
                    ut.nombre AS tipo_usuario_nombre,
                    p.id AS perfil_id,
                    p.descripcion, 
                    p.miembros, 
                    p.foto_url
                FROM usuarios u
                INNER JOIN usuario_tipos ut ON u.id_tipo_usuario = ut.id
                LEFT JOIN perfiles p ON u.id = p.id_usuario
                WHERE u.id = :id_usuario";
        
        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':id_usuario' => $id_usuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Asegura la existencia de una fila en la tabla perfiles para evitar errores si está vacía
     */
    public function garantizarExistenciaPerfil($id_usuario, $id_tipo_usuario) {
        $sql = "INSERT IGNORE INTO perfiles (id_usuario, id_tipo_usuario, descripcion, miembros) 
                VALUES (:id_usuario, :id_tipo, '', '[]')";
        $stmt = $this->bd->prepare($sql);
        $stmt->execute([
            ':id_usuario' => $id_usuario,
            ':id_tipo'    => $id_tipo_usuario
        ]);
    }

    /**
     * Actualiza la descripción del perfil
     */
    public function actualizarDescripcion($id_usuario, $descripcion) {
        $sql = "UPDATE perfiles SET descripcion = :descripcion WHERE id_usuario = :id_usuario";
        $stmt = $this->bd->prepare($sql);
        return $stmt->execute([
            ':descripcion' => $descripcion,
            ':id_usuario'  => $id_usuario
        ]);
    }

    /**
     * Actualiza la URL de la foto de perfil en ambas tablas por consistencia
     */
    public function actualizarFotoPerfil($id_usuario, $foto_url) {
        // Actualizamos en perfiles
        $sql1 = "UPDATE perfiles SET foto_url = :url WHERE id_usuario = :id_usuario";
        $stmt1 = $this->bd->prepare($sql1);
        $stmt1->execute([':url' => $foto_url, ':id_usuario' => $id_usuario]);

        // Actualizamos en usuarios (avatar_url)
        $sql2 = "UPDATE usuarios SET avatar_url = :url WHERE id = :id_usuario";
        $stmt2 = $this->bd->prepare($sql2);
        return $stmt2->execute([':url' => $foto_url, ':id_usuario' => $id_usuario]);
    }

    /**
     * Guarda la lista de miembros codificada en formato JSON
     */
    public function actualizarMiembros($id_usuario, array $miembros) {
        // Almacenamos directamente en formato JSON
        $json_miembros = json_encode($miembros, JSON_UNESCAPED_UNICODE);
        
        $sql = "UPDATE perfiles SET miembros = :miembros WHERE id_usuario = :id_usuario";
        $stmt = $this->bd->prepare($sql);
        return $stmt->execute([
            ':miembros'   => $json_miembros,
            ':id_usuario' => $id_usuario
        ]);
    }
}