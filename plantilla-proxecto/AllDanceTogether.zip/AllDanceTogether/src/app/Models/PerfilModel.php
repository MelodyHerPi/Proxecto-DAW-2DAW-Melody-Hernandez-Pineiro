<?php
require_once __DIR__ . '/../../core/Database.php';

/**
 * Modelo de Gestión de Perfiles.
 * * Controla las operaciones de persistencia relacionadas con las cuentas de usuario,
 * biografías, almacenamiento de estructuras JSON y flujos de seguridad transaccionales.
 */
class PerfilModel {

    private $bd;

    /**
     * Constructor del modelo.
     * * Inicializa la conexión con el motor de la base de datos a través 
     * del componente central de la aplicación.
     */
    public function __construct() {
        $this->bd = Database::getConnection();
    }

    /**
     * Recupera toda la información de un perfil y su usuario.
     * * Realiza un cruce de tablas para obtener los datos de cuenta y extras,
     * parsea los campos JSON dinámicos y normaliza las rutas de la foto de perfil.
     */
    public function obtenerPerfilCompleto(int $id_usuario): array|false {
        try {
            $sql = "SELECT
                        u.id                AS usuario_id,
                        u.nombre_real,
                        u.nombre_app,
                        u.correo_electronico,
                        u.id_tipo_usuario,
                        u.avatar_url        AS foto_url,
                        ut.nombre           AS tipo_usuario_nombre,
                        p.id                AS perfil_id,
                        p.descripcion,
                        p.miembros,
                        p.datos_extra
                    FROM usuarios u
                    INNER JOIN usuario_tipos ut ON u.id_tipo_usuario = ut.id
                    LEFT JOIN perfiles p ON u.id = p.id_usuario
                    WHERE u.id = :id_usuario";

            $stmt = $this->bd->prepare($sql);
            $stmt->execute([':id_usuario' => $id_usuario]);
            $fila = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($fila) {
                $fila['datos_extra'] = !empty($fila['datos_extra'])
                    ? (json_decode($fila['datos_extra'], true) ?? [])
                    : [];
                if (!empty($fila['foto_url'])) {
                    $fila['foto_url'] = normalizarFotoUrl($fila['foto_url']);
                }
            }

            return $fila;
        } catch (PDOException $e) {
            error_log("Error en obtenerPerfilCompleto: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Inicializa un registro de perfil vacío de forma segura.
     * * Utiliza una inserción preventiva con ignorado de errores para asegurar que 
     * el usuario cuente con una fila asociada en la tabla de perfiles.
     */
    public function garantizarExistenciaPerfil(int $id_usuario, int $id_tipo_usuario): bool {
        try {
            $sql = "INSERT IGNORE INTO perfiles (id_usuario, id_tipo_usuario, descripcion, miembros, datos_extra)
                    VALUES (:id_usuario, :id_tipo, '', '[]', '{}')";
            $stmt = $this->bd->prepare($sql);
            return $stmt->execute([
                ':id_usuario' => $id_usuario,
                ':id_tipo'    => $id_tipo_usuario,
            ]);
        } catch (PDOException $e) {
            error_log("Error en garantizarExistenciaPerfil: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Modifica el texto informativo de la biografía.
     * * Actualiza la columna de descripción correspondiente al identificador 
     * de usuario suministrado.
     */
    public function actualizarDescripcion(int $id_usuario, string $descripcion): bool {
        try {
            $sql  = "UPDATE perfiles SET descripcion = :descripcion WHERE id_usuario = :id_usuario";
            $stmt = $this->bd->prepare($sql);
            return $stmt->execute([
                ':descripcion' => $descripcion,
                ':id_usuario'  => $id_usuario,
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarDescripcion: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Modifica la ruta de la imagen de perfil en el sistema.
     * * Ejecuta un bloque transaccional para actualizar de forma simultánea y 
     * atómica las referencias de la imagen tanto en la tabla de usuarios como en la de perfiles.
     */
    public function actualizarFotoPerfil(int $id_usuario, string $foto_url): bool {
        try {
            $this->bd->beginTransaction();

            $stmt1 = $this->bd->prepare(
                "UPDATE usuarios SET avatar_url = :url WHERE id = :id_usuario"
            );
            $stmt1->execute([':url' => $foto_url, ':id_usuario' => $id_usuario]);

            $stmt2 = $this->bd->prepare(
                "UPDATE perfiles SET foto_url = :url WHERE id_usuario = :id_usuario"
            );
            $stmt2->execute([':url' => $foto_url, ':id_usuario' => $id_usuario]);

            $this->bd->commit();
            return true;
        } catch (PDOException $e) {
            $this->bd->rollBack();
            error_log("Error en actualizarFotoPerfil: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Almacena el listado de miembros asociados a un grupo.
     * * Transforma la estructura de datos indexada recibida en una cadena codificada 
     * bajo formato JSON preservando los caracteres Unicode.
     */
    public function actualizarMiembros(int $id_usuario, array $miembros): bool {
        try {
            $sql  = "UPDATE perfiles SET miembros = :miembros WHERE id_usuario = :id_usuario";
            $stmt = $this->bd->prepare($sql);
            return $stmt->execute([
                ':miembros'   => json_encode($miembros, JSON_UNESCAPED_UNICODE),
                ':id_usuario' => $id_usuario,
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarMiembros: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Sincroniza las preferencias de colaboración del perfil.
     * * Extrae el estado actual del campo de datos extendidos, combina las nuevas opciones 
     * sin destruir las llaves existentes y guarda el objeto JSON resultante.
     */
    public function actualizarColaboraciones(int $id_usuario, array $preferencias): bool {
        try {
            $stmt = $this->bd->prepare(
                "SELECT datos_extra FROM perfiles WHERE id_usuario = :id_usuario"
            );
            $stmt->execute([':id_usuario' => $id_usuario]);
            $actual = $stmt->fetchColumn();

            $datos = !empty($actual) ? (json_decode($actual, true) ?? []) : [];
            $datos = array_merge($datos, $preferencias);

            $stmt2 = $this->bd->prepare(
                "UPDATE perfiles SET datos_extra = :datos_extra WHERE id_usuario = :id_usuario"
            );
            return $stmt2->execute([
                ':datos_extra' => json_encode($datos, JSON_UNESCAPED_UNICODE),
                ':id_usuario'  => $id_usuario,
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarColaboraciones: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Recupera el hash criptográfico de la contraseña actual.
     * * Consulta y retorna el string de la clave secreta almacenada para efectuar 
     * comprobaciones de identidad previas a cambios críticos.
     */
    public function obtenerContrasena(int $id_usuario): string|false {
        try {
            $stmt = $this->bd->prepare(
                "SELECT contrasena FROM usuarios WHERE id = :id_usuario"
            );
            $stmt->execute([':id_usuario' => $id_usuario]);
            return $stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error en obtenerContrasena: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Purga de forma completa la cuenta de un usuario.
     * * Borra el registro de la tabla principal de usuarios, delegando la limpieza de las 
     * dependencias de perfiles, comentarios y posts a las reglas de eliminación en cascada.
     */
    public function eliminarCuenta(int $id_usuario): bool {
        try {
            $stmt = $this->bd->prepare(
                "DELETE FROM usuarios WHERE id = :id_usuario"
            );
            return $stmt->execute([':id_usuario' => $id_usuario]);
        } catch (PDOException $e) {
            error_log("Error en eliminarCuenta: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Registra una nueva credencial de acceso para el usuario.
     * * Genera un hash robusto mediante el algoritmo bcrypt a partir del texto plano 
     * recibido y sobrescribe la contraseña en el almacenamiento.
     */
    public function actualizarContrasena(int $id_usuario, string $nueva_contrasena): bool {
        try {
            $sql  = "UPDATE usuarios SET contrasena = :contrasena WHERE id = :id_usuario";
            $stmt = $this->bd->prepare($sql);
            return $stmt->execute([
                ':contrasena' => password_hash($nueva_contrasena, PASSWORD_BCRYPT),
                ':id_usuario' => $id_usuario,
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarContrasena: " . $e->getMessage());
            return false;
        }
    }
}