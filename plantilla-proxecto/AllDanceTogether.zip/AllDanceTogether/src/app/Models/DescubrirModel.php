<?php
require_once __DIR__ . '/../../core/Database.php';

class DescubrirModel {
    private $bd;

    public function __construct() {
        $this->bd = Database::getConnection();
    }

    public function obtenerContenidoGlobalFiltrado($busqueda, $tipo, $limite = 10, $offset = 0) {
        $parametros = [];
        $likeParam = '%' . $busqueda . '%';

        $sql = "SELECT 
                    p.tipo AS tipo_item, 
                    p.id, 
                    p.titulo, 
                    p.descripcion, 
                    p.foto_url, 
                    p.lugar,
                    p.fecha,
                    COUNT(c.id) AS total_comentarios
                FROM publicaciones p
                LEFT JOIN comentarios c ON c.id_publicacion = p.id
                WHERE (p.titulo LIKE :q1 OR p.descripcion LIKE :q2 OR p.lugar LIKE :q3)";

        $parametros[':q1'] = $likeParam;
        $parametros[':q2'] = $likeParam;
        $parametros[':q3'] = $likeParam;

        if ($tipo === 'evento' || $tipo === 'noticia') {
            $sql .= " AND p.tipo = :tipo_filtro";
            $parametros[':tipo_filtro'] = $tipo;
        }
        
        $sql .= " GROUP BY p.id ORDER BY p.fecha DESC LIMIT :limite OFFSET :offset";

        $stmt = $this->bd->prepare($sql);

        foreach ($parametros as $key => $val) {
            $stmt->bindValue($key, $val, PDO::PARAM_STR);
        }
        
        $stmt->bindValue(':limite', (int)$limite, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function guardarNuevaPublicacion($id_creador, $tipo, $titulo, $descripcion, $foto_url, $fecha, $lugar) {
        $sql = "INSERT INTO publicaciones (id_creador, tipo, titulo, descripcion, foto_url, fecha, lugar) 
                VALUES (:id_creador, :tipo, :titulo, :descripcion, :foto_url, :fecha, :lugar)";
                
        $stmt = $this->bd->prepare($sql);
        
        $stmt->bindValue(':id_creador', (int)$id_creador, PDO::PARAM_INT);
        $stmt->bindValue(':tipo', $tipo, PDO::PARAM_STR);
        $stmt->bindValue(':titulo', $titulo, PDO::PARAM_STR);
        $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->bindValue(':foto_url', $foto_url, PDO::PARAM_STR);
        $stmt->bindValue(':fecha', $fecha, $fecha ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->bindValue(':lugar', $lugar, $lugar ? PDO::PARAM_STR : PDO::PARAM_NULL);
        
        return $stmt->execute();
    }

    public function obtenerPublicacionPorId($id) {
        $sql = "SELECT p.*, u.nombre_app AS creador_nombre 
                FROM publicaciones p 
                LEFT JOIN usuarios u ON p.id_creador = u.id 
                WHERE p.id = :id 
                LIMIT 1";
                
        $stmt = $this->bd->prepare($sql);
        $stmt->bindValue(':id', (int)$id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function actualizarPublicacion($id, $titulo, $descripcion, $lugar, $foto_url) {
        $sql = "UPDATE publicaciones 
                SET titulo = :titulo, 
                    descripcion = :descripcion, 
                    lugar = :lugar, 
                    foto_url = :foto_url 
                WHERE id = :id";
                
        // CORREGIDO: cambiado $this->db por $this->bd para ser consistente con el constructor
        $stmt = $this->bd->prepare($sql); 
        
        return $stmt->execute([
            ':titulo'      => $titulo,
            ':descripcion' => $descripcion,
            ':lugar'       => $lugar,
            ':foto_url'    => $foto_url,
            ':id'          => $id
        ]);
    }
    public function insertarComentario($publicacion_id, $usuario_id, $contenido) {
    try {
        // Asegúrate de que $this->db sea tu conexión PDO activa
        $sql = "INSERT INTO comentarios (id_publicacion, id_usuario, contenido, creado_en) 
                VALUES (:publicacion_id, :usuario_id, :contenido, NOW())";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':publicacion_id' => (int)$publicacion_id,
            ':usuario_id'     => (int)$usuario_id,
            ':contenido'      => $contenido
        ]);
    } catch (PDOException $e) {
        // ERROR LOG: Si esto falla, aquí sabrás por qué
        error_log("Error en insertarComentario: " . $e->getMessage());
        return false;
    }
    }
    
}