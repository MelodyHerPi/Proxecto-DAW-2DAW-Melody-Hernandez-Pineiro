<?php
require_once __DIR__ . '/../../core/Database.php';

/**
 * Modelo de la Sección "Descubrir".
 * * Gestiona todas las consultas y operaciones en la base de datos relacionadas 
 * con el feed global, incluyendo publicaciones, filtros y el sistema de comentarios.
 */
class DescubrirModel {
    private $bd;

    /**
     * Constructor del modelo.
     * * Inicializa la propiedad de la clase estableciendo la conexión activa 
     * con la base de datos a través del núcleo del sistema.
     */
    public function __construct() {
        $this->bd = Database::getConnection();
    }

    /**
     * Busca y filtra las publicaciones del feed.
     * * Realiza una consulta con cruce de datos para obtener posts que coincidan con 
     * un texto de búsqueda (título, descripción o lugar), permitiendo discriminar por 
     * tipo y aplicando paginación avanzada.
     */
    public function obtenerContenidoGlobalFiltrado(string $busqueda, string $tipo, int $limite = 10, int $offset = 0): array {
        try {
            $parametros = [];
            $likeParam = '%' . $busqueda . '%';

            $sql = "SELECT 
                        p.tipo AS tipo_item, 
                        p.id, 
                        p.id_creador, 
                        u.nombre_app AS creador_nombre,
                        p.titulo, 
                        p.descripcion, 
                        p.foto_url, 
                        p.lugar,
                        p.fecha,
                        COUNT(c.id) AS total_comentarios
                    FROM publicaciones p
                    LEFT JOIN usuarios u ON p.id_creador = u.id
                    LEFT JOIN comentarios c ON c.id_publicacion = p.id
                    WHERE (p.titulo LIKE :q1 OR p.descripcion LIKE :q2 OR p.lugar LIKE :q3)";

            $parametros[':q1'] = $likeParam;
            $parametros[':q2'] = $likeParam;
            $parametros[':q3'] = $likeParam;

            if ($tipo === 'evento' || $tipo === 'noticia') {
                $sql .= " AND p.tipo = :tipo_filtro";
                $parametros[':tipo_filtro'] = $tipo;
            }
            
            $sql .= " GROUP BY p.id, p.id_creador, u.nombre_app ORDER BY p.fecha DESC LIMIT :limite OFFSET :offset";

            $stmt = $this->bd->prepare($sql);

            foreach ($parametros as $key => $val) {
                $stmt->bindValue($key, $val, PDO::PARAM_STR);
            }
            
            $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            error_log("Error en obtenerContenidoGlobalFiltrado: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Inserta una nueva publicación en el sistema.
     * * Registra en la base de datos el contenido estructurado del nuevo post, 
     * controlando de forma condicional los valores nulos para fecha y ubicación.
     */
    public function guardarNuevaPublicacion(int $id_creador, string $tipo, string $titulo, string $descripcion, string $foto_url, ?string $fecha, ?string $lugar): bool {
        try {
            $sql = "INSERT INTO publicaciones (id_creador, tipo, titulo, descripcion, foto_url, fecha, lugar) 
                    VALUES (:id_creador, :tipo, :titulo, :descripcion, :foto_url, :fecha, :lugar)";
                    
            $stmt = $this->bd->prepare($sql);
            
            $stmt->bindValue(':id_creador', $id_creador, PDO::PARAM_INT);
            $stmt->bindValue(':tipo', $tipo, PDO::PARAM_STR);
            $stmt->bindValue(':titulo', $titulo, PDO::PARAM_STR);
            $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);
            $stmt->bindValue(':foto_url', $foto_url, PDO::PARAM_STR);
            $stmt->bindValue(':fecha', $fecha, $fecha ? PDO::PARAM_STR : PDO::PARAM_NULL);
            $stmt->bindValue(':lugar', $lugar, $lugar ? PDO::PARAM_STR : PDO::PARAM_NULL);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Error en guardarNuevaPublicacion: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Obtiene una publicación específica por su identificador único.
     * * Recupera toda la información del post junto con el nombre público del usuario 
     * que lo creó, devolviendo null si el registro no existe.
     */
    public function obtenerPublicacionPorId(int $id): ?array {
        try {
            $sql = "SELECT p.*, u.nombre_app AS creador_nombre 
                    FROM publicaciones p 
                    LEFT JOIN usuarios u ON p.id_creador = u.id 
                    WHERE p.id = :id 
                    LIMIT 1";
                    
            $stmt = $this->bd->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            return $resultado ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerPublicacionPorId: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Modifica los datos de un post existente.
     * * Actualiza el título, la descripción, el lugar, la fecha y la ruta de la imagen 
     * asociados a la publicación indicada.
     */
    public function actualizarPublicacion(int $id, string $titulo, string $descripcion, ?string $lugar, string $foto_url, ?string $fecha): bool {
        try {
            $sql = "UPDATE publicaciones 
                    SET titulo = :titulo, 
                        descripcion = :descripcion, 
                        lugar = :lugar, 
                        foto_url = :foto_url,
                        fecha = :fecha
                    WHERE id = :id";
                    
            $stmt = $this->bd->prepare($sql);
            
            return $stmt->execute([
                ':titulo'      => $titulo,
                ':descripcion' => $descripcion,
                ':lugar'       => $lugar,
                ':foto_url'    => $foto_url,
                ':fecha'       => $fecha,
                ':id'          => $id
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarPublicacion: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Almacena un comentario en un post.
     * * Guarda la aportación de texto vinculándola con la publicación y el usuario 
     * correspondiente, usando la marca de tiempo actual del servidor.
     */
    public function insertarComentario(int $publicacion_id, int $usuario_id, string $contenido): bool {
        try {
            $sql = "INSERT INTO comentarios (id_publicacion, id_usuario, contenido, creado_en) 
                    VALUES (:publicacion_id, :usuario_id, :contenido, NOW())";
           
            $stmt = $this->bd->prepare($sql);
            
            return $stmt->execute([
                ':publicacion_id' => $publicacion_id,
                ':usuario_id'     => $usuario_id,
                ':contenido'      => $contenido
            ]);
        } catch (PDOException $e) {
            error_log("Error en insertarComentario: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Recupera todos los comentarios de una publicación.
     * * Extrae la lista completa de mensajes asociados al post de forma cronológica, 
     * adjuntando los nombres y fotos de perfil de los respectivos autores.
     */
    public function obtenerComentariosPorPublicacion(int $id): array {
        try {
            $sql = "SELECT c.id, c.contenido, c.creado_en, c.id_usuario,
                           u.nombre_app, u.avatar_url
                    FROM comentarios c
                    LEFT JOIN usuarios u ON c.id_usuario = u.id
                    WHERE c.id_publicacion = :id
                    ORDER BY c.creado_en ASC";

            $stmt = $this->bd->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerComentariosPorPublicacion: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Borra una publicación del sistema.
     * * Elimina de manera permanente el registro de la tabla de publicaciones 
     * filtrando por su clave primaria.
     */
    public function eliminarPublicacion(int $id): bool {
        try {
            $stmt = $this->bd->prepare("DELETE FROM publicaciones WHERE id = :id");
            return $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            error_log("Error en eliminarPublicacion: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Elimina un comentario específico.
     * * Remueve de forma definitiva el registro de la tabla de comentarios basándose 
     * en su identificador único.
     */
    public function eliminarComentario(int $id): bool {
        try {
            $stmt = $this->bd->prepare("DELETE FROM comentarios WHERE id = :id");
            return $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            error_log("Error en eliminarComentario: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Edita el texto de un comentario.
     * * Modifica el contenido textual de una interacción ya existente localizándola 
     * por medio de su identificador.
     */
    public function actualizarComentario(int $id, string $contenido): bool {
        try {
            $stmt = $this->bd->prepare("UPDATE comentarios SET contenido = :contenido WHERE id = :id");
            return $stmt->execute([':contenido' => $contenido, ':id' => $id]);
        } catch (PDOException $e) {
            error_log("Error en actualizarComentario: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Obtiene un comentario aislado.
     * * Busca y extrae los campos crudos de un único comentario según su identificador, 
     * resultando útil para validaciones previas a su edición o borrado.
     */
    public function obtenerComentarioPorId(int $id): ?array {
        try {
            $stmt = $this->bd->prepare("SELECT * FROM comentarios WHERE id = :id LIMIT 1");
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerComentarioPorId: " . $e->getMessage());
            return null;
        }
    }
}