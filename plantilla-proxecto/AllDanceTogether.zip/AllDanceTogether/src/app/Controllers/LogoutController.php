<?php
// LogoutController.php
class LogoutController {
    public function index() {
        // Si no hay ninguna sesión activa, la iniciamos
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Limpiamos el array de sesión
        $_SESSION = array();
        
        // Destruimos la sesión
        session_destroy();
        
        // Redireccionamos
        header('Location: /login');
        exit;
    }
}