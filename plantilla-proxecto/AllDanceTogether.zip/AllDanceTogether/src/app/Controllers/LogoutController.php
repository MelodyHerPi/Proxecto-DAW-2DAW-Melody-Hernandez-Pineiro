<?php
// Controllers/LogoutController.php

require_once __DIR__ . "/Controller.php";

/**
 * Controlador de Cierre de Sesión.
 * * Se encarga de limpiar el entorno del usuario y destruir la sesión 
 * activa para garantizar una salida segura de la plataforma.
 */
class LogoutController extends Controller
{
    /**
     * Procesa el cierre de sesión.
     * * Vacía las variables de sesión en memoria, destruye el archivo de sesión 
     * en el servidor y redirige al usuario de vuelta a la pantalla de login.
     */
    public function index(): void
    {
        $_SESSION = [];
        session_destroy();
        $this->redirect('/login');
    }
}