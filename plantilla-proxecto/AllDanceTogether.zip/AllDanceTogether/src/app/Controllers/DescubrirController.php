<?php

require_once __DIR__ . "/Controller.php";
require_once __DIR__ . "/../Models/DescubrirModel.php";

/**
 * Controlador de la Sección "Descubrir".
 * * Gestiona el feed global de contenido de la comunidad. Permite a los usuarios
 * buscar publicaciones, ver detalles, interactuar mediante comentarios y realizar
 * operaciones CRUD sobre sus propios posts, incluyendo la subida segura de imágenes.
 */
class DescubrirController extends Controller
{
    /**
     * Muestra el feed principal de publicaciones.
     * * Aplica filtros de búsqueda si se reciben parámetros por URL, prepara los
     * datos del usuario (como el avatar sanitizado) para la cabecera y renderiza 
     * la vista principal con el listado de resultados.
     */
    public function index(): void
    {
        $this->requireAuth();

        $foto_cruda = $_SESSION['usuario']['foto_url'] ?? '';
        if (!empty($foto_cruda)) {
            $avatar_cabecera = strpos($foto_cruda, '/public') === 0
                ? substr($foto_cruda, 7)
                : $foto_cruda;
            $avatar_cabecera = htmlspecialchars($avatar_cabecera, ENT_QUOTES, 'UTF-8');
        } else {
            $avatar_cabecera = '/assets/img/avatar-default.svg';
        }

        $nombre_usuario = htmlspecialchars($_SESSION['usuario']['nick'], ENT_QUOTES, 'UTF-8');

        $_SESSION['pagina_actual'] = 'descubrir';

        $modelo     = new DescubrirModel();
        $resultados = $modelo->obtenerContenidoGlobalFiltrado(
            $_GET['q']    ?? '',
            $_GET['tipo'] ?? 'todos'
        );

        require_once __DIR__ . "/../Views/Descubrir-view.php";
    }

    /**
     * Muestra el detalle de una publicación específica.
     * * Recupera la publicación por su ID junto con todos sus comentarios asociados.
     * Si la publicación no existe o el ID no es válido, devuelve al usuario al feed.
     */
    public function ver(): void
    {
        $this->requireAuth();

        $id = (int) ($_GET['id'] ?? 0);
        if ($id === 0) $this->redirect('/descubrir');

        $_SESSION['pagina_actual'] = 'descubrir';

        $foto_cruda = $_SESSION['usuario']['foto_url'] ?? '';
        if (!empty($foto_cruda)) {
            $avatar_cabecera = strpos($foto_cruda, '/public') === 0
                ? substr($foto_cruda, 7)
                : $foto_cruda;
            $avatar_cabecera = htmlspecialchars($avatar_cabecera, ENT_QUOTES, 'UTF-8');
        } else {
            $avatar_cabecera = '/assets/img/avatar-default.svg';
        }

        $nombre_usuario = htmlspecialchars($_SESSION['usuario']['nick'], ENT_QUOTES, 'UTF-8');

        $modelo      = new DescubrirModel();
        $publicacion = $modelo->obtenerPublicacionPorId($id);

        if ($publicacion === null) $this->redirect('/descubrir');

        $comentarios = $modelo->obtenerComentariosPorPublicacion($id);

        require_once __DIR__ . "/../Views/PublicacionDetalle-view.php";
    }

    /**
     * Elimina una publicación del sistema.
     * * Valida la seguridad mediante CSRF y comprueba rigurosamente que el usuario 
     * que intenta borrar la publicación sea el creador original de la misma.
     */
    public function eliminarPublicacion(): void
    {
        $this->requireAuth();

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        $id         = (int) ($_POST['id'] ?? 0);
        $id_usuario = $_SESSION['usuario']['id'];

        if ($id === 0) $this->redirect('/descubrir');

        $modelo      = new DescubrirModel();
        $publicacion = $modelo->obtenerPublicacionPorId($id);

        // Solo el dueño puede eliminar
        if (!$publicacion || (int)$publicacion['id_creador'] !== $id_usuario) {
            $this->redirect('/descubrir');
        }

        $modelo->eliminarPublicacion($id);
        $this->redirect('/descubrir');
    }

    /**
     * Elimina un comentario específico.
     * * Aplica la lógica de moderación: permite la eliminación si el usuario actual 
     * es el autor del comentario O si es el propietario de la publicación donde se comentó.
     */
    public function eliminarComentario(): void
    {
        $this->requireAuth();

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        $id_comentario  = (int) ($_POST['id_comentario'] ?? 0);
        $id_publicacion = (int) ($_POST['id_publicacion'] ?? 0);
        $id_usuario     = $_SESSION['usuario']['id'];

        if ($id_comentario === 0) $this->redirect('/descubrir');

        $modelo      = new DescubrirModel();
        $comentario  = $modelo->obtenerComentarioPorId($id_comentario);
        $publicacion = $modelo->obtenerPublicacionPorId($id_publicacion);

        // Puede eliminar: el autor del comentario O el dueño de la publicación
        $es_autor_comentario  = $comentario && (int)$comentario['id_usuario']       === $id_usuario;
        $es_dueno_publicacion = $publicacion && (int)$publicacion['id_creador']     === $id_usuario;

        if (!$es_autor_comentario && !$es_dueno_publicacion) {
            $this->redirect('/descubrir/ver?id=' . $id_publicacion);
        }

        $modelo->eliminarComentario($id_comentario);
        $this->redirect('/descubrir/ver?id=' . $id_publicacion);
    }

    /**
     * Permite al autor modificar el texto de su comentario.
     * * Comprueba que el comentario pertenezca al usuario en sesión antes de 
     * procesar la actualización en la base de datos.
     */
    public function editarComentario(): void
    {
        $this->requireAuth();

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        $id_comentario  = (int) ($_POST['id_comentario'] ?? 0);
        $id_publicacion = (int) ($_POST['id_publicacion'] ?? 0);
        $contenido      = trim($_POST['contenido'] ?? '');
        $id_usuario     = $_SESSION['usuario']['id'];

        if ($id_comentario === 0 || $contenido === '') {
            $this->redirect('/descubrir/ver?id=' . $id_publicacion);
        }

        $modelo     = new DescubrirModel();
        $comentario = $modelo->obtenerComentarioPorId($id_comentario);

        // Solo el autor puede editar su propio comentario
        if (!$comentario || (int)$comentario['id_usuario'] !== $id_usuario) {
            $this->redirect('/descubrir/ver?id=' . $id_publicacion);
        }

        $modelo->actualizarComentario($id_comentario, $contenido);
        $this->redirect('/descubrir/ver?id=' . $id_publicacion);
    }

    /**
     * Crea una nueva publicación en la comunidad.
     * * Procesa los campos de texto del formulario y, en caso de incluir un archivo multimedia,
     * gestiona la subida de la imagen mediante el método interno de validación.
     */
    public function crear(): void
    {
        $this->requireAuth();

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/descubrir');
        }

        $id_creador  = $_SESSION['usuario']['id'];
        $tipo        = trim($_POST['tipo']        ?? '');
        $titulo      = trim($_POST['titulo']      ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $fecha       = !empty($_POST['fecha'])    ? $_POST['fecha']        : null;
        $lugar       = !empty($_POST['lugar'])    ? trim($_POST['lugar'])  : null;
        $foto_url    = '';

        if (!empty($_FILES['foto']['tmp_name'])) {
            $resultado = $this->procesarImagen($_FILES['foto']);
            if ($resultado === false) {
                $this->redirect('/descubrir?error=imagen');
            }
            $foto_url = $resultado;
        }

        $modelo = new DescubrirModel();
        if ($modelo->guardarNuevaPublicacion($id_creador, $tipo, $titulo, $descripcion, $foto_url, $fecha, $lugar)) {
            $this->redirect('/descubrir');
        }

        $this->redirect('/descubrir?error=db');
    }

    /**
     * Procesa los cambios de una publicación existente.
     * * Actualiza los textos informativos y comprueba si se ha subido una nueva imagen
     * para reemplazar la anterior, manteniendo el flujo seguro mediante tokens.
     */
    public function procesarEditar(): void
    {
        $this->requireAuth();

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/descubrir');
        }

        $id          = (int) ($_POST['id'] ?? 0);
        $titulo      = trim($_POST['titulo']      ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $lugar       = !empty($_POST['lugar'])    ? trim($_POST['lugar']) : null;
        $fecha       = !empty($_POST['fecha'])    ? $_POST['fecha']       : null;

        if ($id === 0) {
            $this->redirect('/descubrir?error=id');
        }

        $modelo   = new DescubrirModel();
        $actual   = $modelo->obtenerPublicacionPorId($id);
        $foto_url = $actual['foto_url'] ?? '';

        if (!empty($_FILES['foto']['tmp_name'])) {
            $resultado = $this->procesarImagen($_FILES['foto']);
            if ($resultado === false) {
                $this->redirect('/descubrir?error=imagen');
            }
            $foto_url = $resultado;
        }

        if ($modelo->actualizarPublicacion($id, $titulo, $descripcion, $lugar, $foto_url, $fecha)) {
            $this->redirect('/descubrir');
        }

        $this->redirect('/descubrir?error=db');
    }

    /**
     * Consulta directa de comentarios por base de datos.
     * * Nota: Este método interactúa directamente con PDO en lugar de usar el modelo.
     * Devuelve una lista indexada con los textos, fechas e información de usuario de los comentarios.
     */
    public function obtenerComentariosPorPublicacion(int $id): array {
        try {
            $sql = "SELECT c.contenido, c.creado_en, u.nombre_app, u.avatar_url
                    FROM comentarios c
                    LEFT JOIN usuarios u ON c.id_usuario = u.id
                    WHERE c.id_publicacion = :id
                    ORDER BY c.creado_en ASC";

            $stmt = $this->bd->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerComentariosPorPublicacion: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Publica un nuevo comentario en un post.
     * * Recibe el texto del formulario, sanea los espacios en blanco e inserta la interacción 
     * vinculándola al usuario logueado. Delega la integridad referencial a las FK de la base de datos.
     */
    public function comentar(): void
    {
        $this->requireAuth();

        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/descubrir');
        }

        $id_publicacion = (int) ($_POST['id_publicacion'] ?? 0);
        $contenido      = trim($_POST['contenido'] ?? '');
        $id_usuario     = $_SESSION['usuario']['id'];

        if ($id_publicacion === 0 || $contenido === '') {
            $this->redirect('/descubrir?error=datos');
        }

        // Verificación de existencia eliminada: la FK de BD lo garantiza
        $modelo = new DescubrirModel();
        if ($modelo->insertarComentario($id_publicacion, $id_usuario, $contenido)) {
            $this->redirect('/descubrir/ver?id=' . $id_publicacion);
        }

        $this->redirect('/descubrir?error=db');
    }

    /**
     * Limpia la ruta de almacenamiento de recursos web.
     * * Quita el prefijo físico de la carpeta pública si está presente para guardar
     * o retornar URLs relativas consistentes para las etiquetas HTML del navegador.
     */
    private function normalizarRutaImagen(string $ruta): string
    {
        return strpos($ruta, '/public') === 0 ? substr($ruta, 7) : $ruta;
    }

    /**
     * Procesa, valida y almacena imágenes subidas por el usuario.
     * * Verifica el tipo MIME real mediante la extensión de PHP 'finfo' para mitigar
     * inyecciones de archivos peligrosos. Renombra el archivo con un ID único, gestiona los 
     * directorios con permisos estrictos (0755) y guarda el elemento de forma segura.
     */
    private function procesarImagen(array $archivo): string|false
    {
        $finfo            = new finfo(FILEINFO_MIME_TYPE);
        $mime             = $finfo->file($archivo['tmp_name']);
        $mimes_permitidos = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

        if (!in_array($mime, $mimes_permitidos, true)) {
            return false;
        }

        $extension  = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        $nombre     = uniqid('img_', true) . '.' . $extension;
        $directorio = __DIR__ . '/../../public/uploads/descubrir/';

        if (!is_dir($directorio)) {
            mkdir($directorio, 0755, true); 
        }

        if (!move_uploaded_file($archivo['tmp_name'], $directorio . $nombre)) {
            return false;
        }

        return $this->normalizarRutaImagen('/uploads/descubrir/' . $nombre);
    }
}