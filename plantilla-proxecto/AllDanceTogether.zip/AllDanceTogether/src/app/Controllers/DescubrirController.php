<?php
require_once __DIR__ . '/../Models/DescubrirModel.php';

class DescubrirController {
    
    public function index() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }

        if (!isset($_SESSION['usuario'])) {
            header('Location: /login');
            exit;
        }

        $busqueda = isset($_GET['q']) ? trim($_GET['q']) : '';
        $tipo     = isset($_GET['tipo']) ? $_GET['tipo'] : 'todos';
        $limite   = 10;
        $offset   = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

        $model = new DescubrirModel();
        $resultados_raw = $model->obtenerContenidoGlobalFiltrado($busqueda, $tipo, $limite, $offset);

        $resultados = [];
        foreach ($resultados_raw as $item) {
            if (!empty($item['foto_url']) && strpos($item['foto_url'], '/public') === 0) {
                $item['foto_url'] = substr($item['foto_url'], 7);
            }
            $resultados[] = $item;
        }

        if (isset($_GET['ajax'])) {
            header('Content-Type: application/json');
            echo json_encode($resultados);
            exit;
        }

        require_once __DIR__ . "/../Views/Descubrir-view.php";
    }

    public function crear() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }

        if (!isset($_SESSION['usuario'])) { header('Location: /login'); exit; }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_creador  = $_SESSION['usuario']['id'];
            $tipo        = $_POST['tipo'] ?? 'evento';
            $titulo      = trim($_POST['titulo'] ?? '');
            $descripcion = trim($_POST['descripcion'] ?? '');
            $fecha       = !empty($_POST['fecha']) ? $_POST['fecha'] : null;
            $lugar       = !empty($_POST['lugar']) ? trim($_POST['lugar']) : null;
            $foto_url    = null;

            if (empty($titulo) || empty($descripcion)) {
                $_SESSION['msg_error'] = "El título y la descripción son campos obligatorios.";
                header('Location: /descubrir');
                exit;
            }

            if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
                $dir_subida = __DIR__ . '/../../public/uploads/publicaciones/';
                if (!is_dir($dir_subida)) { mkdir($dir_subida, 0777, true); }
                $extension = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
                $nombre_archivo = time() . '_' . uniqid() . '.' . $extension;
                $ruta_destino = $dir_subida . $nombre_archivo;

                if (move_uploaded_file($_FILES['foto']['tmp_name'], $ruta_destino)) {
                    $foto_url = '/public/uploads/publicaciones/' . $nombre_archivo;
                }
            }

            $model = new DescubrirModel();
            $exito = $model->guardarNuevaPublicacion($id_creador, $tipo, $titulo, $descripcion, $foto_url, $fecha, $lugar);

            if ($exito) {
                $_SESSION['msg_exito'] = "¡Publicación creada exitosamente en el feed general!";
            } else {
                $_SESSION['msg_error'] = "Ocurrió un error interno en el servidor al intentar guardar la publicación.";
            }
        }

        header('Location: /descubrir');
        exit;
    }

  /**
     * Muestra la pantalla independiente de una publicación (Ver detalle)
     */
    public function ver() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }

        if (!isset($_SESSION['usuario'])) {
            header('Location: /login');
            exit;
        }

        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id) {
            header('Location: /descubrir');
            exit;
        }

        $model = new DescubrirModel();
        $publicacion = $model->obtenerPublicacionPorId($id);

        if (!$publicacion) {
            $_SESSION['msg_error'] = "La publicación solicitada no existe.";
            header('Location: /descubrir');
            exit;
        }

        if (!empty($publicacion['foto_url']) && strpos($publicacion['foto_url'], '/public') === 0) {
            $publicacion['foto_url'] = substr($publicacion['foto_url'], 7);
        }

        // Cargamos la vista única de detalle
        require_once __DIR__ . "/../Views/PublicacionDetalle-view.php";
    }

    /**
     * Procesa el formulario de edición enviado por POST desde la misma vista
     */
    public function procesarEditar() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /descubrir');
            exit;
        }

        if (!isset($_SESSION['usuario']['id'])) {
            header('Location: /login');
            exit;
        }

        $id          = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $titulo      = trim($_POST['titulo'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $lugar       = trim($_POST['lugar'] ?? '');

        if (!$id || empty($titulo) || empty($descripcion)) {
            $_SESSION['msg_error'] = "Los campos Título y Descripción son obligatorios.";
            header("Location: /descubrir/ver?id=" . $id);
            exit;
        }

        $modelo = new DescubrirModel();
        $publicacionActual = $modelo->obtenerPublicacionPorId($id);

        // Seguridad estricta: verificar que eres el dueño antes de modificar
        if (!$publicacionActual || $publicacionActual['id_creador'] != $_SESSION['usuario']['id']) {
            $_SESSION['msg_error'] = "Acción denegada por seguridad.";
            header('Location: /descubrir');
            exit;
        }

        $foto_url = $publicacionActual['foto_url'] ?? null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $folder = __DIR__ . '/../../public/uploads/publicaciones/';
            if (!is_dir($folder)) { mkdir($folder, 0777, true); }
            
            $extension = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $fileName = time() . '_' . uniqid() . '.' . $extension;
            
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $folder . $fileName)) {
                $foto_url = '/public/uploads/publicaciones/' . $fileName;
            }
        }

        $exito = $modelo->actualizarPublicacion($id, $titulo, $descripcion, $lugar, $foto_url);

        if ($exito) {
            $_SESSION['msg_exito'] = "¡Publicación actualizada con éxito!";
        } else {
            $_SESSION['msg_error'] = "Hubo un error o no se detectaron cambios.";
        }

        header("Location: /descubrir/ver?id=" . $id);
        exit;
    }
    /**
     * Procesa la inserción de un nuevo comentario enviado por POST
     */
    public function comentar() {
        // 1. Asegurar sesión iniciada
        if (session_status() === PHP_SESSION_NONE) { session_start(); }

        // 2. Restringir solo a peticiones POST de usuarios autenticados
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /descubrir');
            exit;
        }

        if (!isset($_SESSION['usuario']['id'])) {
            $_SESSION['msg_error'] = "Debes iniciar sesión para comentar.";
            header('Location: /login');
            exit;
        }

        // 3. Sanitizar y validar los datos recibidos del formulario
        $publicacion_id = filter_input(INPUT_POST, 'publicacion_id', FILTER_VALIDATE_INT);
        $contenido      = trim($_POST['comentario'] ?? '');
        $id_usuario     = $_SESSION['usuario']['id'];

        if (!$publicacion_id || empty($contenido)) {
            $_SESSION['msg_error'] = "El comentario no puede estar vacío.";
            header("Location: /descubrir/ver?id=" . ($publicacion_id ?? ''));
            exit;
        }

        // 4. Invocar al modelo para insertar en la Base de Datos
        $modelo = new DescubrirModel();
        
        // Verificación previa opcional: comprobar si la publicación realmente existe
        $publicacion = $modelo->obtenerPublicacionPorId($publicacion_id);
        if (!$publicacion) {
            $_SESSION['msg_error'] = "La publicación a la que intentas comentar no existe.";
            header('Location: /descubrir');
            exit;
        }

        // Insertar el comentario (Crearemos esta función en el modelo en el Paso 2)
        $exito = $modelo->insertarComentario($publicacion_id, $id_usuario, $contenido);

        if ($exito) {
            $_SESSION['msg_exito'] = "¡Comentario publicado con éxito!";
        } else {
            $_SESSION['msg_error'] = "No se pudo guardar tu comentario. Inténtalo de nuevo.";
        }

        // 5. Redireccionar de vuelta a la ficha detallada
        header("Location: /descubrir/ver?id=" . $publicacion_id);
        exit;
    }
    
}