<?php
require_once __DIR__ . "/../Models/UsuarioModel.php";

class UsuariosController {

    /**
     * Renderiza la vista del listado de usuarios aplicando los filtros correspondientes.
     */
    public function index() {
        // Opcional: Si requieres que solo usuarios autenticados vean la comunidad, desenta esto:
        /*
        if (!isset($_SESSION['usuario'])) {
            header("Location: /login");
            exit;
        }
        */

        // 1. Captura y limpia los parámetros de filtrado desde la URL (GET)
        $busqueda_texto = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';
        $filtro_tipo    = isset($_GET['tipo']) ? trim($_GET['tipo']) : 'todos';

        // 2. Instancia el modelo de usuario
        $modelo = new UsuarioModel();

        try {
            // 3. Obtiene los usuarios filtrados desde la base de datos
            $listado_usuarios = $modelo->obtenerUsuariosFiltrados($busqueda_texto, $filtro_tipo);
            $total_resultados = count($listado_usuarios);
        } catch (Exception $e) {
            // En caso de fallo de BD, inicializamos estructuras vacías para no romper la vista
            $listado_usuarios = [];
            $total_resultados = 0;
            $error_bd = true;
        }

        // 4. Nombre de usuario para la cabecera (heredado de la sesión)
        $nombre_usuario = htmlspecialchars($_SESSION['usuario']['nick'] ?? 'Usuario');

        // 5. Carga la vista correspondiente (inyectándole las variables anteriores)
        require_once __DIR__ . "/../Views/Usuarios-view.php";
    }
}