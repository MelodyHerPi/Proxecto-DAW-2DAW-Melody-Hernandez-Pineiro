<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../Models/UsuarioModel.php';

/**
 * Controlador del Directorio de Usuarios.
 * * Maneja la visualización y búsqueda de los perfiles que forman la comunidad,
 * permitiendo filtrar los resultados por texto y por tipo de cuenta.
 */
class UsuariosController extends Controller {

    /**
     * Muestra el listado filtrado de usuarios.
     * * Valida la autenticación, gestiona la seguridad CSRF, captura los parámetros
     * de búsqueda de la URL para pasárselos al modelo y carga el resultado en la vista.
     */
    public function index(): void {
        $this->requireAuth();

        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        $_SESSION['pagina_actual'] = 'usuarios';

        $busqueda_texto = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';
        $filtro_tipo    = isset($_GET['tipo'])   ? trim($_GET['tipo'])   : 'todos';

        $filtro_tipo_int = ($filtro_tipo !== 'todos' && is_numeric($filtro_tipo))
            ? (int) $filtro_tipo
            : null;

        $modelo = new UsuarioModel();

        try {
            $listado_usuarios = $modelo->obtenerUsuariosFiltrados($busqueda_texto, $filtro_tipo_int);
            $total_resultados = count($listado_usuarios);
        } catch (Exception $e) {
            error_log("Error en UsuariosController::index: " . $e->getMessage());
            $listado_usuarios = [];
            $total_resultados = 0;
        }

        require_once __DIR__ . '/../Views/Usuarios-view.php';
    }
}