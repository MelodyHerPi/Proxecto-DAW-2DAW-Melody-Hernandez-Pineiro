<?php

class HomeController {
    
    public function index() {
        // PROTECCIÓN: Si no hay array 'usuario' en la sesión, al login.
        if (!isset($_SESSION['usuario'])) {
            header("Location: /login");
            exit;
        }

        // CARGAMOS TU VISTA DE INICIO
        require_once __DIR__ . "/../Views/Inicio-view.php";
    }
}