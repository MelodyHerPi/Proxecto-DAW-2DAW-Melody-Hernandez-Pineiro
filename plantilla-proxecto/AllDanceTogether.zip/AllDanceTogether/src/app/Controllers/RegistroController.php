<?php
require_once __DIR__ . "/Controller.php";
require_once __DIR__ . "/../Models/UsuarioModel.php";

/**
 * Controlador del Registro de Usuarios.
 * * Gestiona la creación de nuevas cuentas en el sistema, controlando la visualización 
 * del formulario y aplicando filtros estrictos de validación de datos.
 */
class RegistroController extends Controller
{
    /**
     * Muestra el formulario de registro.
     * * Redirige al inicio si el usuario ya está logueado. En caso contrario, 
     * inicializa el token de seguridad CSRF y carga la vista.
     */
    public function index(): void
    {
        if (isset($_SESSION['usuario'])) {
            $this->redirect('/inicio');
        }
                if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        require_once __DIR__ . "/../Views/Registro-view.php";
    }

    /**
     * Procesa la inserción del nuevo usuario.
     * * Valida el token CSRF, verifica los formatos de correo, contraseñas y nicks, 
     * comprueba que no existan datos duplicados y da de alta la cuenta en la base de datos.
     */
    public function guardar(): void
    {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/registro');
        }

        $nombre_real = trim($_POST['nombre_real'] ?? '');
        $usuario     = trim($_POST['usuario'] ?? '');
        $correo      = trim($_POST['correo'] ?? '');
        $contrasena  =      $_POST['contrasena'] ?? '';
        $confirmar   =      $_POST['confirmar_contrasena'] ?? '';
        $es_grupo    = isset($_POST['es_grupo']) ? 2 : 1;

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            $this->redirect('/registro?error=correo');
        }

        if (!preg_match('/^\w{3,30}$/', $usuario)) {
            $this->redirect('/registro?error=usuario');
        }

        if (strlen($contrasena) < 8 || !preg_match('/[A-Z]/', $contrasena) || !preg_match('/\d/', $contrasena)) {
            $this->redirect('/registro?error=contrasena_debil');
        }

        if ($contrasena !== $confirmar) {
            $this->redirect('/registro?error=contrasena');
        }

        $modelo = new UsuarioModel();

        if ($modelo->existeCorreo($correo)) {
            $this->redirect('/registro?error=correo_duplicado');
        }

        if ($modelo->existeUsuario($usuario)) {
            $this->redirect('/registro?error=usuario_duplicado');
        }

        if ($modelo->registrar($nombre_real, $usuario, $correo, $contrasena, $es_grupo)) {
            $this->redirect('/login?registro=ok');
        }

        $this->redirect('/registro?error=db');
    }
}