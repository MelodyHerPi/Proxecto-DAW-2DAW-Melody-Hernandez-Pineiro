<?php
require_once __DIR__ . "/../Models/UsuarioModel.php";

class RegistroController {

    public function index() {
        if (isset($_SESSION['usuario'])) {
            header("Location: /home");
            exit;
        }
        require_once __DIR__ . "/../Views/Registro-view.php";
    }

    public function guardar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $nombre_real        = trim($_POST['nombre_real']         ?? '');
            $usuario            = trim($_POST['usuario']             ?? '');
            $correo             = trim($_POST['correo']              ?? '');
            $contrasena         = $_POST['contrasena']               ?? '';
            $confirmar          = $_POST['confirmar_contrasena']     ?? '';
            $es_grupo           = isset($_POST['es_grupo']) ? 2 : 1; // 1=usuario, 2=grupo (según usuario_tipos)

            if ($contrasena !== $confirmar) {
                header("Location: /registro?error=contrasena");
                exit;
            }

            $modelo = new UsuarioModel();

            if ($modelo->registrar($nombre_real, $usuario, $correo, $contrasena, $es_grupo)) {
                header("Location: /login?registro=ok");
                exit;
            } else {
                header("Location: /registro?error=db");
                exit;
            }
        }
    }
}