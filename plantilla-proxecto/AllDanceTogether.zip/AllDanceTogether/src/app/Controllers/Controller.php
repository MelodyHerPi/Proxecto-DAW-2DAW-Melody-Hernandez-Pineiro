<?php
/**
 * Controlador Base del Sistema.
 * * Clase madre de la que heredan los controladores de la aplicación. 
 * Centraliza la gestión de sesiones del ciclo de vida de la app, 
 * la seguridad básica contra ataques CSRF y provee métodos auxiliares 
 * para el control de flujo y autenticación de usuarios.
 */
class Controller
{
    /**
     * Inicializa el entorno del controlador.
     * * Asegura que exista una sesión activa en el servidor y verifica 
     * la existencia de un token CSRF. Si el token no existe en la sesión 
     * actual, genera uno nuevo de forma segura para proteger los formularios.
     */
    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Genera el token CSRF 
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    /**
     * Filtro de autenticación para rutas protegidas.
     * * Comprueba si el usuario tiene una sesión válida. En caso de no 
     * estar autenticado, corta la ejecución y redirige automáticamente 
     * a la pantalla de login.
     */
    protected function requireAuth(): void
    {
        if (!isset($_SESSION['usuario'])) {
            header("Location: /login");
            exit;
        }
    }

    /**
     * Atajo para redirecciones HTTP.
     * * Envía las cabeceras de redirección al navegador hacia la ruta especificada 
     * y finaliza inmediatamente el script para evitar ejecuciones residuales.
     * * @param string $path Ruta de destino (ej: '/dashboard' o '/login').
     */
    protected function redirect(string $path): never
    {
        header("Location: $path");
        exit;
    }
}