<?php
    class AyudaController {
        public function index(){ 
            require_once __DIR__ . "/../Views/Ayuda-view.php";

        }   
    }