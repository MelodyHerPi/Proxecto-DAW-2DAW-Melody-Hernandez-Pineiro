<?php
/**
 * Controlador de la sección de Ayuda.
 * 
 * Se encarga de gestionar la navegación hacia las vistas de soporte, 
 * preguntas frecuentes o manuales de usuario del sistema. Por ahora
 * actúa como un enrutador estático simple para cargar la interfaz visual.
 */
class AyudaController {
    public function index(){ 
        require_once __DIR__ . "/../Views/Ayuda-view.php";
    }   
}