<?php
/**
 * Controlador de Términos de Uso.
 * * Gestiona la visualización del documento legal que describe las condiciones,
 * derechos y obligaciones que aceptan los usuarios al utilizar la plataforma.
 */
class TerminosController {
    public function index()   { 
        require_once __DIR__ . "/../Views/Terminos-view.php";
    }
}