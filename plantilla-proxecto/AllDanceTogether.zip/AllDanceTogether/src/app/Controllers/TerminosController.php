<?php
    class TerminosController {
            public function index()   { 
        require_once __DIR__ . "/../Views/Terminos-view.php";

    }
    }