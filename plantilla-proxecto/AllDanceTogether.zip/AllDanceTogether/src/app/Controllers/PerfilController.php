<?php
require_once __DIR__ . '/../Models/PerfilModel.php';

class PerfilController {
    
    public function index() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Redirección si no está logueado (Cotejado con tu LoginController)
        if (!isset($_SESSION['usuario'])) {
            header('Location: /login');
            exit;
        }

        $id_usuario = $_SESSION['usuario']['id'];
        $model = new PerfilModel();
        
        // Obtener datos iniciales
        $perfil = $model->obtenerPerfilCompleto($id_usuario);
        
        // Garantizar que tenga fila en la tabla de perfiles para evitar errores
        if (!$perfil || empty($perfil['perfil_id'])) {
            $model->garantizarExistenciaPerfil($id_usuario, $_SESSION['usuario']['tipo']);
            $perfil = $model->obtenerPerfilCompleto($id_usuario);
        }

        // Decodificar la lista de miembros que viene de la base de datos (JSON)
        $miembros = [];
        if (!empty($perfil['miembros'])) {
            $miembros = json_decode($perfil['miembros'], true);
            if (!is_array($miembros)) { $miembros = []; }
        }

        // Guardamos las variables para que estén disponibles en la vista (.php)
        require_once __DIR__ . "/../Views/Perfil-view.php";
    }

    public function guardar() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // CORREGIDO: Ahora valida correctamente usando la estructura de tu Login
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['usuario']['id'])) {
            header('Location: /perfil');
            exit;
        }

        $id_usuario = $_SESSION['usuario']['id'];
        $model = new PerfilModel();
        $perfilActual = $model->obtenerPerfilCompleto($id_usuario);
        
        $estado = "ok";

        // 1. Procesamiento de Texto de Descripción
        if (isset($_POST['descripcion'])) {
            $descripcion = htmlspecialchars(trim($_POST['descripcion']), ENT_QUOTES, 'UTF-8');
            $model->actualizarDescripcion($id_usuario, $descripcion);
        }

        // 2. Procesamiento de la Subida de Imagen de Perfil
        if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['foto_perfil']['tmp_name'];
            $fileName = $_FILES['foto_perfil']['name'];
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            
            $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($fileExtension, $extensionesPermitidas)) {
                // Nombre único para evitar colisiones
                $nuevoNombre = md5(time() . $id_usuario) . '.' . $fileExtension;
                // Ruta física del servidor
                $rutaDestino = __DIR__ . '/../../public/uploads/avatars/' . $nuevoNombre;
                $urlPublica = '/uploads/avatars/' . $nuevoNombre;

                // Crear directorio si no existe
                if (!is_dir(dirname($rutaDestino))) {
                    mkdir(dirname($rutaDestino), 0755, true);
                }

                if (move_uploaded_file($fileTmpPath, $rutaDestino)) {
                    $model->actualizarFotoPerfil($id_usuario, $urlPublica);
                } else {
                    $estado = "error_subida";
                }
            } else {
                $estado = "error_extension";
            }
        }

        // 3. Procesamiento de Miembros (Usando tanto el nombre dinámico como el ID de tipo de la sesión)
        if ($perfilActual['tipo_usuario_nombre'] === 'grupo' || $_SESSION['usuario']['tipo'] == 2) {
            $miembrosProcesados = [];
            if (isset($_POST['miembros_nombres']) && is_array($_POST['miembros_nombres'])) {
                foreach ($_POST['miembros_nombres'] as $nombre_miembro) {
                    $nombre_limpio = htmlspecialchars(trim($nombre_miembro), ENT_QUOTES, 'UTF-8');
                    if ($nombre_limpio !== "") {
                        $miembrosProcesados[] = ["nombre" => $nombre_limpio];
                    }
                }
            }
            $model->actualizarMiembros($id_usuario, $miembrosProcesados);
        }

        // Te redirige de vuelta a la pantalla de perfil con el estado
        header("Location: /perfil?status=" . $estado);
        exit;
    }
}