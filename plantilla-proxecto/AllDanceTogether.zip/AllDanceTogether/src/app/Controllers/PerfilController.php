<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../Models/PerfilModel.php';
require_once __DIR__ . '/../../core/Helper.php';

/**
 * Controlador de Perfil de Usuario.
 * * Administra los datos personales, la configuración de la cuenta, 
 * las preferencias de colaboración y la seguridad del usuario.
 */
class PerfilController extends Controller {

    /**
     * Muestra el panel de perfil.
     * * Recupera o inicializa la información del perfil del usuario, procesa la 
     * lista de integrantes si corresponde, asegura el token CSRF y carga la vista.
     */
    public function index(): void {
        $this->requireAuth();

        $_SESSION['pagina_actual'] = 'perfil';

        $id_usuario = $_SESSION['usuario']['id'];
        $model      = new PerfilModel();

        $perfil = $model->obtenerPerfilCompleto($id_usuario);

        if (!$perfil || empty($perfil['perfil_id'])) {
            $model->garantizarExistenciaPerfil($id_usuario, $_SESSION['usuario']['tipo']);
            $perfil = $model->obtenerPerfilCompleto($id_usuario);
        }

        $miembros = [];
        if (!empty($perfil['miembros'])) {
            $miembros = json_decode($perfil['miembros'], true);
            if (!is_array($miembros)) { $miembros = []; }
        }

        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        require_once __DIR__ . '/../Views/Perfil-view.php';
    }

    /**
     * Actualiza los datos generales del perfil.
     * * Valida la seguridad por CSRF, guarda la descripción textual, procesa la 
     * subida segura del avatar e introduce la lista de miembros si el usuario es un grupo.
     */
    public function guardar(): void {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/perfil');
        }

        if (
            empty($_POST['csrf_token']) ||
            !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])
        ) {
            $this->redirect('/perfil?status=error_csrf');
        }

        $id_usuario = $_SESSION['usuario']['id'];
        $model      = new PerfilModel();
        $perfil     = $model->obtenerPerfilCompleto($id_usuario);
        $estado     = 'ok';

        if (isset($_POST['descripcion'])) {
            $descripcion = trim($_POST['descripcion']);
            $model->actualizarDescripcion($id_usuario, $descripcion);
        }

        if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath   = $_FILES['foto_perfil']['tmp_name'];
            $fileSize      = $_FILES['foto_perfil']['size'];
            $maxBytes      = 5 * 1024 * 1024; 

            if ($fileSize > $maxBytes) {
                $this->redirect('/perfil?status=error_tamano');
            }

            $finfo    = new finfo(FILEINFO_MIME_TYPE);
            $mimeReal = $finfo->file($fileTmpPath);
            $mimesPermitidos = ['image/jpeg', 'image/png', 'image/webp'];

            if (!in_array($mimeReal, $mimesPermitidos, true)) {
                $this->redirect('/perfil?status=error_extension');
            }

            $extensionPorMime = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp',
            ];
            $fileExtension = $extensionPorMime[$mimeReal];
            $nuevoNombre   = md5(time() . $id_usuario) . '.' . $fileExtension;
            $rutaDestino   = __DIR__ . '/../../public/uploads/avatars/' . $nuevoNombre;
            $urlPublica    = '/uploads/avatars/' . $nuevoNombre;

            if (!is_dir(dirname($rutaDestino))) {
                mkdir(dirname($rutaDestino), 0755, true);
            }

            if (move_uploaded_file($fileTmpPath, $rutaDestino)) {
                $model->actualizarFotoPerfil($id_usuario, $urlPublica);
                $_SESSION['usuario']['foto_url'] = $urlPublica;
            } else {
                $estado = 'error_subida';
            }
        }

        if ($perfil['tipo_usuario_nombre'] === 'grupo' || $_SESSION['usuario']['tipo'] == 2) {
            $miembrosProcesados = [];
            if (isset($_POST['miembros_nombres']) && is_array($_POST['miembros_nombres'])) {
                foreach ($_POST['miembros_nombres'] as $nombre_miembro) {
                    $nombre_limpio = trim($nombre_miembro);
                    if ($nombre_limpio !== '') {
                        $miembrosProcesados[] = ['nombre' => $nombre_limpio];
                    }
                }
            }
            $model->actualizarMiembros($id_usuario, $miembrosProcesados);
        }

        $this->redirect('/perfil?status=' . $estado);
    }

    /**
     * Guarda los ajustes de colaboraciones.
     * * Registra las preferencias sobre si se buscan integrantes, staff u otras 
     * colaboraciones de la comunidad mediante filtros lógicos booleanos.
     */
    public function colaboraciones(): void {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/perfil');
        }

        if (
            empty($_POST['csrf_token']) ||
            !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])
        ) {
            $this->redirect('/perfil?status=error_csrf');
        }

        $id_usuario = $_SESSION['usuario']['id'];
        $model      = new PerfilModel();

        $preferencias = [
            'acepta_colaboraciones' => isset($_POST['acepta_colaboraciones'])
                ? (bool)(int)$_POST['acepta_colaboraciones'] : null,
            'busca_integrantes'     => isset($_POST['busca_integrantes'])
                ? (bool)(int)$_POST['busca_integrantes']     : null,
            'busca_staff'           => isset($_POST['busca_staff'])
                ? (bool)(int)$_POST['busca_staff']           : null,
        ];

        $preferencias = array_filter($preferencias, fn($v) => $v !== null);

        $model->actualizarColaboraciones($id_usuario, $preferencias);

        $this->redirect('/perfil?status=ok');
    }

    /**
     * Modifica la clave de acceso del usuario.
     * * Comprueba la longitud mínima requerida de la nueva contraseña, verifica que las 
     * confirmaciones coincidan y valida la contraseña actual antes de actualizar el hash.
     */
    public function cambiarContrasena(): void {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/perfil');
        }

        if (
            empty($_POST['csrf_token']) ||
            !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])
        ) {
            $this->redirect('/perfil?status=error_csrf');
        }

        $id_usuario = $_SESSION['usuario']['id'];
        $actual     = trim($_POST['contrasena_actual']    ?? '');
        $nueva      = trim($_POST['contrasena_nueva']     ?? '');
        $confirmar  = trim($_POST['contrasena_confirmar'] ?? '');

        if (empty($actual) || empty($nueva) || empty($confirmar)) {
            $this->redirect('/perfil?status=error_password_vacio');
        }

        if (strlen($nueva) < 8) {
            $this->redirect('/perfil?status=error_password_corta');
        }

        if ($nueva !== $confirmar) {
            $this->redirect('/perfil?status=error_password_no_coincide');
        }

        $model = new PerfilModel();
        $hash  = $model->obtenerContrasena($id_usuario);

        if (!$hash || !password_verify($actual, $hash)) {
            $this->redirect('/perfil?status=error_password_incorrecta');
        }

        $model->actualizarContrasena($id_usuario, $nueva);

        $this->redirect('/perfil?status=ok_password');
    }

    /**
     * Da de baja y elimina por completo la cuenta.
     * * Valida las credenciales por seguridad y, de confirmarse el borrado en la base de datos, 
     * purga por completo las cookies y la sesión del servidor antes de la salida.
     */
    public function eliminarCuenta(): void {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/perfil');
        }

        if (
            empty($_POST['csrf_token']) ||
            !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])
        ) {
            $this->redirect('/perfil?status=error_csrf');
        }

        $id_usuario  = $_SESSION['usuario']['id'];
        $contrasena  = trim($_POST['contrasena_eliminar'] ?? '');

        if (empty($contrasena)) {
            $this->redirect('/perfil?status=error_eliminar_vacio');
        }

        $model = new PerfilModel();
        $hash  = $model->obtenerContrasena($id_usuario);

        if (!$hash || !password_verify($contrasena, $hash)) {
            $this->redirect('/perfil?status=error_eliminar_incorrecta');
        }

        $eliminado = $model->eliminarCuenta($id_usuario);

        if (!$eliminado) {
            $this->redirect('/perfil?status=error_eliminar_fallo');
        }

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();

        $this->redirect('/?status=cuenta_eliminada');
    }
}