<?php
/** * Controlador del Sistema de Login.
 * * Administra el acceso de usuarios, encargándose de renderizar el formulario,
 * validar las credenciales contra la base de datos y gestionar la sesión segura.
 */ 
require_once __DIR__ . "/../Models/UsuarioModel.php";
require_once __DIR__ . "/Controller.php";

class LoginController extends Controller
{
    /**
     * Muestra la pantalla de login.
     * * Si el usuario ya está autenticado lo desvía al inicio. Si no,
     * asegura el token CSRF y carga la vista de acceso.
     */
    public function index(): void {
        if (isset($_SESSION['usuario'])) {
            $this->redirect('/inicio');
        }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        require_once __DIR__ . "/../Views/Login-view.php";
    }

    /**
     * Procesa el formulario de autenticación.
     * * Valida el token de seguridad, comprueba la contraseña mediante hash y,
     * si todo es correcto, regenera el ID de sesión y guarda los datos del usuario.
     */
    public function inicio(): void {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("Error de seguridad: Token no válido.");
        }

        $identificador = $_POST['usuario'] ?? '';
        $password      = $_POST['password'] ?? '';

        $modelo        = new UsuarioModel();
        $datos_usuario = $modelo->buscarPorIdentificador($identificador);

        if ($datos_usuario && password_verify($password, $datos_usuario['contrasena'])) {
            session_regenerate_id(true);
            $_SESSION['usuario'] = [
                'id'       => $datos_usuario['id'],
                'nick'     => $datos_usuario['nombre_app'],
                'nombre'   => $datos_usuario['nombre_real'],
                'email'    => $datos_usuario['correo_electronico'],
                'tipo'     => $datos_usuario['id_tipo_usuario'],
                'foto_url' => $datos_usuario['avatar_url'],
            ];
            $this->redirect('/inicio');
        }

        $this->redirect('/login?error=auth');
    }
}