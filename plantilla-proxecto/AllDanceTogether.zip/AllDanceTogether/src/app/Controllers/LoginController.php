<?php
require_once __DIR__ . "/../Models/UsuarioModel.php";

class LoginController
{

    public function index()
    {
        // Si ya existe la sesión 'usuario', lo mandamos directamente a la página de inicio
        if (isset($_SESSION['usuario'])) {
            header("Location: /home");
            exit;
        }
        require_once __DIR__ . "/../Views/Login-view.php";
    }

    // RENOMBRADO A 'inicio' para que coincida con el action del formulario
    public function inicio()
    {
        $identificador = $_POST['usuario'] ?? '';
        $password = $_POST['password'] ?? '';

        $modelo = new UsuarioModel();
        $datos_usuario = $modelo->buscarPorIdentificador($identificador);

        if ($datos_usuario && password_verify($password, $datos_usuario['contrasena'])) {

            // CORRECCIÓN: Guardamos los datos incluyendo 'avatar_url' de la base de datos
            $_SESSION['usuario'] = [
                'id'       => $datos_usuario['id'],
                'nick'     => $datos_usuario['nombre_app'],
                'nombre'   => $datos_usuario['nombre_real'],
                'email'    => $datos_usuario['correo_electronico'],
                'tipo'     => $datos_usuario['id_tipo_usuario'],
                'foto_url' => $datos_usuario['avatar_url'] // <-- ¡ESTA LÍNEA FALTABA!
            ];

            // Redirigimos al controlador Home
            header("Location: /inicio");
            exit;
        } else {
            header("Location: /login?error=auth");
            exit;
        }
    }

    public function logout()
    {
        session_destroy();
        header("Location: /login");
        exit;
    }
}