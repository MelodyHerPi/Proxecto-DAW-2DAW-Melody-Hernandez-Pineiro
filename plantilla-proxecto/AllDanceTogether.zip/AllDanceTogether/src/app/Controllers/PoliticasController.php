<?php
/**
 * Controlador de Políticas de Privacidad.
 * * Administra el acceso a la sección legal del sitio, encargándose de mostrar 
 * los textos de privacidad, términos de servicio y condiciones de la plataforma.
 */
class PoliticasController {

    public function index()  { 
        require_once __DIR__ . "/../Views/Politicas-view.php";
    }
}