<?php
class PoliticasController {
    public function index()  { 
        require_once __DIR__ . "/../Views/Politicas-view.php";
    }
}