<?php

class ComodinController {

    /**
     * Muestra una página de error/mantenimiento genérica.
     * Acepta parámetros opcionales para personalizar el mensaje.
     *
     * @param array $params  Puede contener: codigo, titulo, mensaje, icono, btnUrl, btnTexto, btnIcono
     */
    public function index(array $params = []) {
        $codigo    = $params['codigo']    ?? null;
        $titulo    = $params['titulo']    ?? 'En mantenimiento';
        $mensaje   = $params['mensaje']   ?? 'Estamos haciendo mejoras. Volvemos enseguida.';
        $icono     = $params['icono']     ?? 'bi-tools';
        $btnUrl    = $params['btnUrl']    ?? '/';
        $btnTexto  = $params['btnTexto']  ?? 'Volver al inicio';
        $btnIcono  = $params['btnIcono']  ?? 'bi-house';

        require_once __DIR__ . '/../Views/Comodin-view.php';
    }

    /**
     * Ruta: /comodin/proximamente
     * Para secciones aún no implementadas.
     */
    public function proximamente() {
        $this->index([
            'titulo'   => 'Próximamente',
            'mensaje'  => 'Esta sección está en desarrollo. ¡Vuelve pronto!',
            'icono'    => 'bi-hourglass-split',
            'btnUrl'   => isset($_SESSION['usuario']) ? '/inicio' : '/',
            'btnTexto' => isset($_SESSION['usuario']) ? 'Volver al inicio' : 'Ir al inicio',
        ]);
    }

    /**
     * Ruta: /comodin/error
     * Lee el código HTTP desde la query string: /comodin/error?codigo=404
     * El router también puede llamar a este método pasando $codigo directamente.
     */
    public function error(int $codigo = 0) {
        if ($codigo === 0) {
            $codigo = (int)($_GET['codigo'] ?? 500);
        }
        $errores = [
            403 => [
                'titulo'   => 'Acceso denegado',
                'mensaje'  => 'No tienes permiso para ver esta página.',
                'icono'    => 'bi-shield-lock',
            ],
            404 => [
                'titulo'   => 'Página no encontrada',
                'mensaje'  => 'La página que buscas no existe o ha sido eliminada.',
                'icono'    => 'bi-map',
            ],
            500 => [
                'titulo'   => 'Error interno',
                'mensaje'  => 'Algo ha salido mal en el servidor. Inténtalo más tarde.',
                'icono'    => 'bi-exclamation-triangle',
            ],
        ];

        $params = $errores[$codigo] ?? [
            'titulo'  => 'Error inesperado',
            'mensaje' => 'Ha ocurrido un error. Inténtalo de nuevo.',
            'icono'   => 'bi-emoji-dizzy',
        ];

        $params['codigo'] = $codigo;

        // Emitir el código HTTP real
        http_response_code($codigo);

        $this->index($params);
    }
}