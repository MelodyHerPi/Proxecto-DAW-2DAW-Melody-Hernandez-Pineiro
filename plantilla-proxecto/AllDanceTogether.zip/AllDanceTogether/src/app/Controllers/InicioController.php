<?php
/**
 * Controlador de la página principal (Inicio).
 * * Gestiona la sección del panel de bienvenida tras iniciar sesión, 
 * encargándose de preparar los datos de perfil básicos del usuario.
 */
require_once __DIR__ . "/Controller.php";
require_once __DIR__ . "/../Models/UsuarioModel.php";

class InicioController extends Controller
{
    /**
     * Muestra el inicio de la aplicación.
     * * Comprueba la identidad del usuario, procesa y sanea su avatar y nick 
     * para la cabecera, y carga la vista correspondiente.
     */
    public function index(): void
    {
        $this->requireAuth();

        $foto_cruda = $_SESSION['usuario']['foto_url'] ?? '';

        if (!empty($foto_cruda)) {
            $avatar_cabecera = strpos($foto_cruda, '/public') === 0
                ? substr($foto_cruda, 7)
                : $foto_cruda;
            $avatar_cabecera = htmlspecialchars($avatar_cabecera, ENT_QUOTES, 'UTF-8');
        } else {
            $avatar_cabecera = '/assets/img/avatar-default.svg';
        }

        $usuario        = $_SESSION['usuario'];
        $nombre_usuario = htmlspecialchars($usuario['nick'], ENT_QUOTES, 'UTF-8');
        $_SESSION['pagina_actual']  = 'inicio'; 

        require_once __DIR__ . "/../Views/Inicio-view.php";
    }
}