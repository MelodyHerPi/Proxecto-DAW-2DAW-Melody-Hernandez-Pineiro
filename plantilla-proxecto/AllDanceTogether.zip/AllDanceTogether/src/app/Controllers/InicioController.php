<?php

class InicioController {
    
    public function index() {
        // Verificamos que el usuario tenga la sesión activa
        if (!isset($_SESSION['usuario'])) {
            header("Location: /login");
            exit;
        }

        // Cargamos la vista que ya tienes creada
        require_once __DIR__ . "/../Views/Inicio-view.php";
    }
}