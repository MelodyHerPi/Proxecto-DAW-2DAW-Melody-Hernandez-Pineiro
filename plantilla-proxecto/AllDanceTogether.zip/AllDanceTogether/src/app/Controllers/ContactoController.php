<?php
/**
 * Controlador de la sección de Contacto.
 * * Gestiona el acceso a la vista de contacto, permitiendo a los usuarios
 * visualizar la información de correspondencia, formularios o canales
 * de comunicación disponibles en la plataforma.
 */
class ContactoController {
    public function index()   {
        require_once __DIR__ . "/../Views/Contacto-view.php";
    }
}