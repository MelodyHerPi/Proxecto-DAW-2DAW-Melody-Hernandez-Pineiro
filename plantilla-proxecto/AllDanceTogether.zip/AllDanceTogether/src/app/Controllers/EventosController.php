<?php
require_once __DIR__ . '/Controller.php';
require_once __DIR__ . '/../Models/EventosModel.php';
require_once __DIR__ . '/../../core/Helper.php';
require_once __DIR__ . '/../Views/partials/evento.php';

/**
 * Controlador de Eventos.
 * * Maneja la sección de la agenda, organizando y mostrando los eventos 
 * del mes en curso y las próximas fechas programadas.
 */
class EventosController extends Controller {

    /**
     * Carga la agenda de eventos.
     * * Asegura la sesión, genera el token de seguridad, consulta las listas 
     * de eventos al modelo, normaliza las rutas de sus imágenes y abre la vista.
     */
    public function index(): void {
        $this->requireAuth();

        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        $_SESSION['pagina_actual'] = 'eventos';

        $model = new EventosModel();

        $eventos_mes      = normalizarListaFotos($model->obtenerEventosEsteMes());
        $proximos_eventos = normalizarListaFotos($model->obtenerProximosEventos());

        require_once __DIR__ . '/../Views/Eventos-view.php';
    }
}