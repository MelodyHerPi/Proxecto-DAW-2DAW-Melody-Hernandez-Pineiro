<?php
require_once __DIR__ . '/../Models/EventosModel.php';

class EventosController {

    public function index() {
        if (session_status() === PHP_SESSION_NONE) { session_start(); }

        if (!isset($_SESSION['usuario'])) {
            header('Location: /login');
            exit;
        }

        $model = new EventosModel();

        $eventos_mes_raw      = $model->obtenerEventosEsteMes();
        $proximos_eventos_raw = $model->obtenerProximosEventos();

        // Normalizar rutas de foto (mismo patrón que DescubrirController)
        $normalizarFoto = function(array $lista): array {
            return array_map(function($item) {
                if (!empty($item['foto_url']) && strpos($item['foto_url'], '/public') === 0) {
                    $item['foto_url'] = substr($item['foto_url'], 7);
                }
                return $item;
            }, $lista);
        };

        $eventos_mes      = $normalizarFoto($eventos_mes_raw);
        $proximos_eventos = $normalizarFoto($proximos_eventos_raw);

        require_once __DIR__ . '/../Views/Eventos-view.php';
    }
}